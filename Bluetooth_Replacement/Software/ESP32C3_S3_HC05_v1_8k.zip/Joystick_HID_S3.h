#pragma once
#if (USE_ESP32 == ESP32S3)
#include <Arduino.h>

#define VBUS_EN 9 // VBUS power command (add mosfet if needed

// Minimal native USB-host joystick reader for ESP32-S3 builds.
// Uses EspUsbHost to receive raw HID input reports and decodes the common
// "Extreme 3D Pro / T16K style" 8-byte report format.
// Produces up to 16 channels in microseconds (1000..2000).

void JoystickHidBegin();
void JoystickHidTask();

// Optional debug: print decoded channels (microseconds) to Dbg at ~5Hz.
void JoystickHidSetDebugPrint(bool en);

// Returns true only when a NEW report was decoded since last call.
bool JoystickHidGetChannelsUs(uint16_t* outUs, int maxCh);

// Status flags for OLED/debug (set by Joystick_HID_S3.ino)
extern volatile bool     g_usb_host_started;   // true after usbHost.begin()
extern volatile bool     g_usb_dev_mounted;    // true once we received at least one HID report
extern volatile uint32_t g_usb_report_count;   // increments on each HID report

#endif
