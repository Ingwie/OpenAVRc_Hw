/*
 * ESP32C3_HC05_MasterSlave_v1_8c.ino
 * -----------------------------------------------------------------------------
 * MAIN APPLICATION FILE
 *
 * This file is the central orchestration layer of the project.
 *
 * Responsibilities:
 * - Global configuration (roles, modes, preferences, persistence)
 * - Initialization sequencing of all subsystems (HC05, SBUS, PPM, ESPNOW, WiFi)
 * - Runtime task scheduling and mode switching
 * - Routing of data between:
 *     * Radio interfaces (HC05 / SBUS / PPM)
 *     * Internal representation (tf frames or channel arrays)
 *     * ESPNOW transport layer
 *     * Output generators (HC05 / SBUS / PPM)
 *
 * Design philosophy:
 * - Each protocol-specific implementation lives in its own module (.ino tab)
 * - This file only *coordinates* those modules
 * - No protocol-specific timing logic should be implemented here
 *
 * IMPORTANT:
 * - This file is intentionally large but functionally declarative
 * - All time-critical code must remain in dedicated modules
 * - This file must remain backward compatible with existing OpenAVRc logic
 * -----------------------------------------------------------------------------
 */

/*
  OpenAVRc HC-05 subset emulator over UART + ESP-NOW transport (ESP32-C3 core 3.x)
  + OLED status (SSD1306 I2C) on SDA=GPIO5, SCL=GPIO6
  + LED status on GPIO8

  One single firmware: OpenAVRc can configure role with AT+ROLE=0/1.
  USB console (line-based): m/s/i/d/g/w/ssid/pass/creds/h

  IMPORTANT PINS (because OLED uses GPIO5):
    - I2C: SDA=5, SCL=6
    - UART to Mega Serial1: RX=4, TX=7
    - LED: GPIO8 (solid=connected, fast blink=connecting, slow blink=idle)
    - Button scan GPIO10
    For ESP32S3 / Joystick feature
    - DbgS3  Serial1
    - DBG_TX 11
    - DBG_RX 12
    - VBUS_EN 9
*/

#define USE_OTA 1   // 1=enable ArduinoOTA support, 0=compile without OTA

#include <Arduino.h>

#include "Sbus_Mmode.h"       //generate Sbus
#include "Sbus_Smode.h"       //read Sbus
#include "Ppm_Mmode.h"        //generate Cppm
#include "Ppm_Smode.h"        //read Cppm
#include "Ppm_Link.h"
#include <ESP32_PPM.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi_types.h>
#include <Preferences.h>
#include <esp_wifi.h>
#include <elapsedMillis.h>
#include "HelloInfo.h"

#include <Wire.h>
#include <U8g2lib.h>
#include "Wifi_Tabs.h"

#if USE_OTA
#include "Ota_Tabs.h"
#endif

#define ESP32C3 0
#define ESP32S3 1
#if defined(CONFIG_IDF_TARGET_ESP32S3)
  #warning "Compiling for ESP32-S3"
  #define USE_ESP32 ESP32S3
#elif defined(CONFIG_IDF_TARGET_ESP32C3)
  #warning "Compiling for ESP32-C3"
  #define USE_ESP32 ESP32C3
#else
  #error "Unsupported ESP32, select Only C3 or S3 target"
#endif

#if (USE_ESP32 == ESP32S3)
#include "JoystickConfig.h"
#include "RCState.h"
#include "Joystick_HID_S3.h"
#include <FastLED.h>
#define NUM_LEDS 1
CRGB ledRGB[NUM_LEDS];
uint8_t  setRGBBrightness = 40;
#endif

// Commenter pour désactiver complètement le logo
#define USE_LOGO

// -----------------------------------------------------------------------------
// Logo bitmaps (U8g2 drawXBMP)
// - S3: 128x64 "joystick -> radio" logo (existing header)
// - C3: 72x40 "radio+joystick" and "radio+radio" logos
// All symbols are namespaced to avoid collisions between platforms.
// -----------------------------------------------------------------------------
#ifdef USE_LOGO
#if (USE_ESP32 == ESP32S3)
    #include "logoS3.h"
#else//C3
    #include "logoC3_radio_joystick.h"
    #include "logoC3_radio_radio.h"
  #endif
#endif // USE_LOGO

// Uncomment to enable logo overlay mode (logo over text every ~3s)
//#define USE_LOGO_OVERLAY_MODE

#if (USE_ESP32 == ESP32C3)
  #warning "Compiling for ESP32-C3/Training Mode"
  #define Dbg  Serial
#elif (USE_ESP32 == ESP32S3)
  #warning "Compiling for ESP32-S3/Joystick Mode"
  // Use an external TTL/USB interface as a FTDI
  #define Dbg  Serial1
  #define DBG_TX 11
  #define DBG_RX 12
  // Logo bitmap (only when USE_LOGO is enabled)
  #ifdef USE_LOGO
  #include "logoS3.h"
  #endif
  bool showLogo = false;
  uint8_t infoPage = 0;
#else
  #error "Unrecognized ESP."
#endif

// ================== USER CONFIG ==================

float VERSION = 1.8f; // v1.8k

static const char* BUILD_TAG = "1.8k";

#if (USE_ESP32 == ESP32S3)
// ---------------- Joystick (native HID host) globals ----------------
RCState rcs;
static const uint8_t NUM_CHANNELS = 8;
static uint16_t JoystictOut[NUM_CHANNELS];

// Read channel order mapping from PROGMEM (JoystickConfig.h)
static void applyChannelOrderFromProgmem() {
  ChannelOrderSt_t co;
  memcpy_P(&co, &ChannelOrder[channelsOrder], sizeof(co));
  AileronNbChannel  = co.Aileron;
  ElevatorNbChannel = co.Elevator;
  RudderNbChannel   = co.Rudder;
  ThrottleNbChannel = co.Throttle;
}

static void vbusOn(bool on) {
  pinMode(VBUS_EN, OUTPUT);
  digitalWrite(VBUS_EN, on ? HIGH : LOW);
}
#endif

static constexpr int UART_RX    = 4;   // Mega TX1 -> ESP RX (via divider 4.7k/10k on your board)
static constexpr int UART_TX    = 7;   // ESP TX  -> Mega RX1

static constexpr int SDA_PIN    = 5;
static constexpr int SCL_PIN    = 6;

static constexpr int PIN_LED    = 8;

#define SCAN_BTN_PIN 10
#define SCAN_BTN_DEBOUNCE_MS 50
#define SCAN_BTN_LONGPRESS_MS 1200  // long press => OTA window ("ota 1")

static constexpr uint8_t ESPNOW_CHANNEL = 1;

static constexpr uint32_t DEFAULT_BAUD  = 115200;   // OpenAVRc init at 115200 on test board


static constexpr uint8_t  DEFAULT_ROLE = 0;      // 0=Slave by default
static constexpr const char* DEFAULT_NAME = "OAVRC";
static constexpr const char* DEFAULT_PSWD = "1234";

static constexpr uint16_t HELLO_INTERVAL_MS = 800;
static constexpr uint32_t LINK_TIMEOUT_MS = 3000; // v1.7a: consider link lost after no RX
static constexpr uint16_t MAX_PAYLOAD = 220;

// OLED
static constexpr uint8_t OLED_ADDR = 0x3C;
static constexpr int OLED_W = 128;
static constexpr int OLED_H = 64;
// =================================================

#if (USE_ESP32 == ESP32C3)
HardwareSerial BT(1);//Use Serial1
#elif (USE_ESP32 == ESP32S3)
HardwareSerial BT(2);//Use Serial2
#endif
Preferences prefs;

static bool oled_ok = false;
static uint32_t oled_boot_ms = 0; // for startup logo timing
// OLED 0.42" (often 72x40) with U8g2
#if (USE_ESP32 != ESP32S3)
U8G2_SSD1306_72X40_ER_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);//rotation 0 et pas de pin reset
#else
// OLED 0.96" (often 128x64)
U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);//rotation 0 et pas de pin reset
#endif

elapsedMillis oledInfoTimer;
uint8_t oledInfo = 0;

// -----------------------------------------------------------------------------
// MASTER MODE CONFIGURATION (v1.7n)
// -----------------------------------------------------------------------------
enum { CPPM_MASTER = 0, SBUS_MASTER, HC05_MASTER, PPM2PPM_MASTER};
const char * M_Mode_STR[]  = {"CPPM_MASTER", "SBUS_MASTER", "HC05_MASTER", "PPM2PPM_MASTER"};
static constexpr uint8_t  DEFAULT_MASTER_MODE = HC05_MASTER;
// Guard helpers: keep code readable, no functional change in HC05_MASTER
#define BT_ENABLED()   (cfg_Mmode == HC05_MASTER)
#define BT_ONLY(stmt) do { if (BT_ENABLED()) { stmt; } } while(0)

// -----------------------------------------------------------------------------
// SLAVE INPUT MODE CONFIGURATION
// -----------------------------------------------------------------------------
enum { CPPM_SLAVE = 0, SBUS_SLAVE, HC05_SLAVE, PPM2PPM_SLAVE, HC05_JOYSTICK, PPM2PPM_JOYSTICK};
const char * S_Mode_STR[]  = {"CPPM_SLAVE", "SBUS_SLAVE", "HC05_SLAVE", "PPM2PPM_SLAVE", "HC05_JOYSTICK", "PPM2PPM_JOYSTICK"};
static uint8_t cfg_Smode = HC05_SLAVE; // default: legacy OpenAVRc SLAVE over HC05 UART
static uint8_t cfg_Sjoystick = HC05_JOYSTICK;
                                                              /* HC05, P2P */
const char * Mode_STR_Mini[]  = {"CPPM", "SBUS", "HC05", "P2P", "JOY","JOY"};

// Persistent config
static uint8_t  cfg_Mmode = DEFAULT_MASTER_MODE; // default: OpenAVRc HC05-compatible master
static uint32_t cfg_baud  = DEFAULT_BAUD;
static uint8_t  cfg_role  = DEFAULT_ROLE;     // 0 slave, 1 master
static String   cfg_name  = DEFAULT_NAME;
static String   cfg_pswd  = DEFAULT_PSWD;
static uint8_t  cfg_ppm   = CPPM_GEN_POS_MOD;   // CPPM  use positives pulses by default

// Peer management
static uint8_t  bound_peer_mac[6] = {0};
static bool     bound_peer_set = false;

static uint8_t  linked_peer_mac[6] = {0};
static bool     linked_peer_set = false;

static volatile bool link_connected = false;
static uint32_t last_rx_ms = 0;
static uint32_t last_tx_ms = 0;
static int8_t   last_rssi_dbm = 0;
static uint32_t rx_count = 0;
static uint32_t tx_count = 0;
#if (USE_ESP32 == ESP32S3)
static bool joy_started = false;
#endif

static uint32_t stat_boot_ms = 0;
static uint32_t tfMuteUntilMs = 0;   // mute TF until this time (millis)

static bool tfDropLine = false;
static uint8_t tfState = 0; // 0 none, 1 saw 't', 2 saw 'tf'

static bool tfMute = false;          // TFMUTE par défaut
static bool tfAtLineStart = true;

// Trainer line reassembly (handles fragmented ESPNOW payloads)
static char     tfLine[96];
static uint8_t  tfPos = 0;
static bool     tfActive = false;         // currently inside a "tf " line

// ---------------- Helpers ----------------
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static bool isATMode() {
  return false;
}

// Link phase (for OLED/LED)
enum LinkPhase : uint8_t { PH_IDLE=0, PH_CONNECTING=1, PH_CONNECTED=2 };
static volatile LinkPhase link_phase = PH_IDLE;

// ==== Scan table (like OpenAVRc REMOTE_BT_DEV_MAX_NB) ====
static constexpr uint8_t MAX_SCAN_DEV = 3;

struct ScanDev {
  uint8_t mac[6];
  char    name[16];
  bool    used;
};

static volatile bool scanning = false;

// UI latch to show scan activity on OLED even if the real scan/link is very fast
static elapsedMillis uiScanHold;
static bool uiScanActive = false;

static ScanDev scanDev[MAX_SCAN_DEV];
static volatile uint8_t scanCount = 0;

// --- v1.6l: persistent peer name cache for AT+RNAME? ---
static bool saved_peer_set = false;
static uint8_t saved_peer_mac[6] = {0};
static char saved_peer_name[16] = {0};

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void scanClear() {
  for (uint8_t i=0;i<MAX_SCAN_DEV;i++) {
    scanDev[i].used = false;
    scanDev[i].name[0] = 0;
  }
  scanCount = 0;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static int scanFindByMac(const uint8_t mac[6]) {
  for (uint8_t i=0;i<MAX_SCAN_DEV;i++) {
    if (scanDev[i].used && memcmp(scanDev[i].mac, mac, 6) == 0) return i;
  }
  return -1;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void scanAddOrUpdate(const uint8_t mac[6], const char* name) {
  int idx = scanFindByMac(mac);
  if (idx < 0) {
    for (uint8_t i=0;i<MAX_SCAN_DEV;i++) {
      if (!scanDev[i].used) { idx = i; break; }
    }
  }
  if (idx < 0) return; // full

  scanDev[idx].used = true;
  memcpy(scanDev[idx].mac, mac, 6);
  if (name && *name) {
    strncpy(scanDev[idx].name, name, sizeof(scanDev[idx].name)-1);
    scanDev[idx].name[sizeof(scanDev[idx].name)-1] = 0;
  } else {
    scanDev[idx].name[0] = 0;
  }

  uint8_t c = 0;
  for (uint8_t i=0;i<MAX_SCAN_DEV;i++) if (scanDev[i].used) c++;
  scanCount = c;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void loadConfig() {
  prefs.begin("hc05emu", true);
  
  cfg_Mmode = prefs.getUInt("Mmode", cfg_Mmode);
  cfg_Smode = prefs.getUInt("Smode", cfg_Smode);
  cfg_baud = prefs.getUInt("baud", DEFAULT_BAUD);
  cfg_role = prefs.getUChar("role", DEFAULT_ROLE);
  cfg_ppm  = prefs.getUChar("ppmpol", cfg_ppm);											   
  cfg_name = prefs.getString("name", DEFAULT_NAME);
  cfg_pswd = prefs.getString("pswd", DEFAULT_PSWD);
  cfg_Sjoystick = prefs.getUChar("Sjoy", HC05_JOYSTICK);//joyout

  size_t n = prefs.getBytesLength("bind");
  if (n == 6) { prefs.getBytes("bind", bound_peer_mac, 6); bound_peer_set = true; }
  else bound_peer_set = false;

  // v1.6l: load cached peer name/mac
  size_t n2 = prefs.getBytesLength("pmac");
  if (n2 == 6) { prefs.getBytes("pmac", saved_peer_mac, 6); saved_peer_set = true; }
  else saved_peer_set = false;
  String pn = prefs.getString("pnam", "");
  if (pn.length()) {
    strncpy(saved_peer_name, pn.c_str(), sizeof(saved_peer_name)-1);
    saved_peer_name[sizeof(saved_peer_name)-1] = 0;
  }
  prefs.end();
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void saveConfig() {
  prefs.begin("hc05emu", false);
  prefs.putUInt("Mmode", cfg_Mmode);//HC05,SBUS or CPPM mode
  prefs.putUInt("Smode", cfg_Smode);
  prefs.putUInt("baud", cfg_baud);
  prefs.putUChar("role", cfg_role);
  prefs.putUChar("ppmpol", cfg_ppm);									
  prefs.putString("name", cfg_name);
  prefs.putString("pswd", cfg_pswd);
  prefs.putUChar("Sjoy", cfg_Sjoystick);//joyout
  
  if (bound_peer_set) prefs.putBytes("bind", bound_peer_mac, 6);
  // v1.6l: save cached peer name/mac
  if (saved_peer_set) prefs.putBytes("pmac", saved_peer_mac, 6);
  if (saved_peer_name[0]) prefs.putString("pnam", String(saved_peer_name));
  prefs.end();
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void macToStr(const uint8_t mac[6], char* out, size_t outSz) {
  snprintf(out, outSz, "%02X:%02X:%02X:%02X:%02X:%02X",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static String macToNapUapLap(const uint8_t mac[6]) {
  char b[24];
  uint16_t nap = (uint16_t)((mac[0] << 8) | mac[1]);
  uint8_t  uap = mac[2];
  uint32_t lap = ((uint32_t)mac[3] << 16) | ((uint32_t)mac[4] << 8) | mac[5];
  snprintf(b, sizeof(b), "%04X:%02X:%06lX", nap, uap, (unsigned long)lap);
  return String(b);
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static bool parseNapUapLap(const char* s, uint8_t out[6]) {
  // accept "NAP:UAP:LAP" or "NAP,UAP,LAP"
  char tmp[40];
  size_t L = strnlen(s, sizeof(tmp) - 1);
  memcpy(tmp, s, L); tmp[L] = 0;

  for (size_t i=0;i<strlen(tmp);i++) {
    if (tmp[i] == ' ') { tmp[i]=0; break; }
    if (tmp[i] == ',') tmp[i] = ':';
  }

  char *p = tmp;
  char *a = strsep(&p, ":");
  char *b = strsep(&p, ":");
  char *c = strsep(&p, ":");
  if (!a || !b || !c) return false;

  uint32_t nap = strtoul(a, nullptr, 16);
  uint32_t uap = strtoul(b, nullptr, 16);
  uint32_t lap = strtoul(c, nullptr, 16);

  out[0] = (nap >> 8) & 0xFF;
  out[1] = (nap >> 0) & 0xFF;
  out[2] = (uap >> 0) & 0xFF;
  out[3] = (lap >> 16) & 0xFF;
  out[4] = (lap >> 8) & 0xFF;
  out[5] = (lap >> 0) & 0xFF;
  return true;
}

// ---------------- BT debug (USB console) ----------------
static bool dbg_bt = false;

static bool usb_at_mode = false; // v1.7l: echo AT responses to USB when using 'at' command

static bool dbg_tf = false;

// --- TF monitor (MASTER): count dropped tf and compute tf/s ---
static uint32_t tfDroppedCount = 0;
static uint32_t tfDroppedPrev = 0;
static uint32_t tfRate = 0;          // tf per second (approx)
static uint32_t tfRateLastMs = 0;
static uint32_t tfPrintLastMs = 0;   // rate print pacing when dbg is ON

static char btRxLine[160];
static uint16_t btRxLen = 0;

static char btTxLine[160];
static uint16_t btTxLen = 0;

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static int hexNib(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return 10 + (c - 'A');
  if (c >= 'a' && c <= 'f') return 10 + (c - 'a');
  return -1;
}

// Decode OpenAVRc frame: "tf sXXXXsXXXX...:YY"
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static bool decodeTfFrame(const char* line, uint16_t ch[8], bool& chkOk, uint8_t& rxChk, uint8_t& calcChk) {
  chkOk = false;
  rxChk = 0;
  calcChk = 0;

  if (strncmp(line, "tf ", 3) != 0) return false;
  const char* p = line + 3;

  uint8_t chk = 0;

  for (uint8_t i = 0; i < 8; i++) {
    if (*p != 's') return false;
    chk ^= 's';
    p++;

    uint16_t raw = 0;
    for (uint8_t n = 0; n < 4; n++) {
      int v = hexNib(*p);
      if (v < 0) return false;
      chk ^= (uint8_t)(*p);
      raw = (raw << 4) | (uint16_t)v;
      p++;
    }
    ch[i] = raw >> 4;
  }

  if (*p != ':') return false;
  p++;

  int h = hexNib(p[0]);
  int l = hexNib(p[1]);
  if (h < 0 || l < 0) return false;

  rxChk = (uint8_t)((h << 4) | l);
  calcChk = chk;
  chkOk = (rxChk == calcChk);
  return true;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void dbgPrintLine(const char* tag, const char* line) {
  Dbg.print(tag);
  Dbg.print(' ');
  Dbg.println(line);

  uint16_t ch[8];
  bool ok; uint8_t rx, calc;
  if (decodeTfFrame(line, ch, ok, rx, calc)) {
    Dbg.print("    TF ch:");
    for (int i=0;i<8;i++) { Dbg.print(' '); Dbg.print(ch[i]); }
    Dbg.print("  chk ");
    Dbg.println(ok ? "OK" : "ERR");
  }
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void dbgFeedChar(char c, char* buf, uint16_t& len, const char* tag) {
  if (c == '\r') return;
  if (c == '\n') {
    buf[len] = 0;
    if (len > 0) dbgPrintLine(tag, buf);
    len = 0;
    return;
  }
  if (len < 159) buf[len++] = c;
  else len = 0;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void btWriteStr(const char* s) {
  BT_ONLY(BT.print(s));
  if (usb_at_mode) Dbg.print(s);
  if (dbg_bt) {
    for (const char* p=s; *p; ++p) dbgFeedChar(*p, btTxLine, btTxLen, "[TX]");
  }
}


// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void btWriteU32(uint32_t v) {
  char buf[16];
  snprintf(buf, sizeof(buf), "%lu", (unsigned long)v);
  btWriteStr(buf);
}
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void btWriteI32(int32_t v) {
  char buf[16];
  snprintf(buf, sizeof(buf), "%ld", (long)v);
  btWriteStr(buf);
}
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void btWriteStrS(const String& s) {
  btWriteStr(s.c_str());
}

// ================= DATA debug (ESPNOW DATA RX) =================
static char dataLine[200];
static uint16_t dataLen = 0;

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void dataFeedChar(char c) {
  if (c == '\r') return;
  if (c == '\n') {
    dataLine[dataLen] = 0;
    if (dataLen > 0) {
      Dbg.print("[DATA-RX] ");
      Dbg.println(dataLine);

      uint16_t ch[8];
      bool ok; uint8_t rx, calc;
      if (decodeTfFrame(dataLine, ch, ok, rx, calc)) {
        Dbg.print("          CH:");
        for (int i=0;i<8;i++) { Dbg.print(' '); Dbg.print(ch[i]); }
        Dbg.print("  CHK ");
        Dbg.println(ok ? "OK" : "ERR");
      }
    }
    dataLen = 0;
    return;
  }
  if (dataLen < sizeof(dataLine)-1) dataLine[dataLen++] = c;
  else dataLen = 0;
}

// ================= TF generator (simulate student) =================
static bool gen_tf = false;
static bool Master_gen_tf = false;
static uint32_t gen_last_ms = 0;
static uint32_t gen_phase = 0;

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static char hexDigit(uint8_t v) {
  v &= 0xF;
  return (v < 10) ? ('0' + v) : ('A' + (v - 10));
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void buildTfFrame(const uint16_t ch[8], char* out, size_t outSz) {
  uint8_t chk = 0;
  size_t pos = 0;

  auto putc = [&](char c) {
    if (pos + 1 < outSz) out[pos++] = c;
  };
  auto putHexNib = [&](uint8_t nib) {
    char c = hexDigit(nib);
    putc(c);
    chk ^= (uint8_t)c;
  };

  // "tf " prefix (NOT included in checksum in OpenAVRc)
  putc('t'); putc('f'); putc(' ');

  for (int i = 0; i < 8; i++) {
    putc('s');
    chk ^= (uint8_t)'s';

    // OpenAVRc encodes 1500 as "5DC" (not "5DC0")
    // i.e. take (ch << 4) and emit nibbles 12, 8, 4 only => 3 hex digits.
    uint16_t v = (uint16_t)(ch[i] << 4);
    putHexNib((v >> 12) & 0xF);
    putHexNib((v >>  8) & 0xF);
    putHexNib((v >>  4) & 0xF);
  }

  // ':' and checksum digits are NOT included in the XOR (OpenAVRc does XOR on first 32 chars)
  putc(':');
  putc(hexDigit((chk >> 4) & 0xF));
  putc(hexDigit((chk >> 0) & 0xF));

  // End of line: for uCLI, use CR only (avoid empty command on LF)
  putc('\r');

  if (pos < outSz) out[pos] = 0;
  else out[outSz - 1] = 0;
}


// ================= WiFi File Transfer (TCP <-> UART) =================
// (moved to Wifi_Tabs.ino / Wifi_Tabs.h)

// ---------------- LED ----------------
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void ledInit() {
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void ledUpdate() {
  if (wifi_ft) {
    uint32_t now = millis();
    bool on = ((now / 300) & 1) != 0;
    digitalWrite(PIN_LED, on ? HIGH : LOW);
    return;
  }

  if (link_phase == PH_CONNECTED) {
    digitalWrite(PIN_LED, HIGH);
    return;
  }

  uint32_t now = millis();
  uint16_t period = (link_phase == PH_CONNECTING) ? 150 : 700;
  bool on = ((now / period) & 1) != 0;
  digitalWrite(PIN_LED, on ? HIGH : LOW);
}


// ---------------- RGB led ----------------
#if (USE_ESP32 == ESP32S3)
void rgbInit()
{
  FastLED.addLeds<WS2812B, 48, GRB>(ledRGB, NUM_LEDS);
  FastLED.setBrightness(setRGBBrightness);   // à ajuster (0..255)
  ledRGB[0] = CRGB::Black;
  FastLED.show();
}

void rgbSet(const CRGB &c)
{
  static CRGB last = CRGB::Black;
  if (c == last) return;          // pas de show inutile
  last = c;
  ledRGB[0] = c;
  FastLED.show();
}


static bool    remote_info_valid = false;
static uint8_t remote_role  = 0xFF;
static uint8_t remote_mmode = 0xFF;
static uint8_t remote_smode = 0xFF;
static uint8_t remote_flags = 0;

// Remote compatibility status (derived from HELLO/ACK info)
static bool remote_compat_ok = true;
static char remote_compat_msg[18] = ""; // short message for OLED line


void rgbTick()
{
  static uint32_t t = 0;
  static bool blink = false;
  uint32_t now = millis();

  // Exemple d’états (à adapter à tes variables)
  bool connected = (link_phase == PH_CONNECTED);
  bool linking   = (link_phase == PH_CONNECTING);
  bool error     = (!remote_compat_ok); // incompatibility detected via HELLO/ACK
  // If you want "READY but trying" to blink too, add other active phases here (not PH_IDLE by default).

  if (error) { rgbSet(CRGB(80,0,0)); return; }         // rouge
  if (connected) { rgbSet(CRGB(0,80,0)); return; }     // vert

  if (linking) {
    if (now - t >= 300) { t = now; blink = !blink; }
    rgbSet(blink ? CRGB(80,40,0) : CRGB::Black);       // jaune clignotant
    return;
  }

  rgbSet(CRGB::Black);                                 // READY -> éteint
}
#endif

// ---------------- OLED draw (needs wifi_ft/ft_mode) ----------------
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void oledInit() {
  Wire.begin(SDA_PIN, SCL_PIN);
  oled_ok = u8g2.begin();
  if (!oled_ok) {
    Dbg.println("[OLED] init FAILED");
  } else {
    oled_boot_ms = millis();
    Dbg.println("[OLED] init OK (U8g2)");
  }
}

//Version or cfg_Mmode
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================


/* -----------------------------------------------------------------------------
 * ESPNOW: Remote mode discovery (v1.7u)
 *
 * Goal: each ESP32 knows the other side's current role/modes once linked.
 * Mechanism: piggyback a small info payload in PKT_HELLO and PKT_HELLO_ACK.
 *
 * Backward compatible:
 * - If a peer sends HELLO/ACK with len==0, remote_info_valid remains false.
 * -------------------------------------------------------------------------- */


// HelloInfo.flags bits
static const uint8_t HI_FLAG_PPM2PPM = 1 << 0; // indicates PPM<->PPM binary path expected/available


static void buildHelloInfo(HelloInfo &hi) {
  hi.role  = cfg_role;
  hi.mmode = cfg_Mmode;
  // For the ESP32-S3 build, SLAVE mode is driven by the joystick output selector
  // (cfg_Sjoystick). Advertise it via HELLO so the ESP32-C3 can show JOY/P2P and
  // pick the correct receive path.
#if (USE_ESP32 == ESP32S3)
  hi.smode = cfg_Sjoystick;
#else
  hi.smode = cfg_Smode;
#endif
  hi.flags = 0;
  // PPM2PPM capability/active (binary PPM path): when using real PPM in/out modes.
  // If either side advertises this flag, both sides must agree (compat check below).
  if ((cfg_role == 0 && cfg_Smode == PPM2PPM_SLAVE) ||
      (cfg_role == 1 && cfg_Mmode == PPM2PPM_MASTER)) {
    hi.flags |= HI_FLAG_PPM2PPM;
  }

#if (USE_ESP32 == ESP32S3)
  // Joystick can also run in binary PPM2PPM mode.
  if (cfg_Sjoystick == PPM2PPM_JOYSTICK) {
    hi.flags |= HI_FLAG_PPM2PPM;
  }
#endif
  hi.crc8  = crc8_xor4(hi.role, hi.mmode, hi.smode, hi.flags);
}

/* Fonction de dessin (1ère ligne à droite) */
static uint8_t rssiToWifiLevel(int rssi_dbm, bool connected)
{
  if (!connected) return 0;
  if (rssi_dbm == 0 || rssi_dbm == -1 || rssi_dbm == 127 || rssi_dbm == 99) return 0;

  if (rssi_dbm >= -55) return 4;
  if (rssi_dbm >= -65) return 3;
  if (rssi_dbm >= -75) return 2;
  if (rssi_dbm >= -85) return 1;
  return 1; // au moins le point si connecté mais faible
}

// xRight = bord droit (ex: 72-1 ou 128-1), yTop = 0
static void drawWifiIcon(U8G2 &u8g2, int screenW, int yTop, uint8_t level)
{
  if (level == 0) return; // pas connecté → rien

  const int iconW = 18;
  const int iconH = 14;

  int x0 = screenW - iconW - 2;  // petite marge droite
  int y0 = yTop;

  int cx = x0 + iconW / 2;
  int baseY = y0 + iconH - 2;

  u8g2.setDrawColor(1);

  // Point central
  u8g2.drawDisc(cx, baseY, 2, U8G2_DRAW_ALL);

  if (level >= 2)
    u8g2.drawArc(cx, baseY, 5, 200, 340);

  if (level >= 3)
    u8g2.drawArc(cx, baseY, 8, 210, 330);

  if (level >= 4)
    u8g2.drawArc(cx, baseY, 11, 220, 320);
}

static bool parseHelloInfo(const uint8_t *buf, uint16_t len) {
  if (!buf || len != sizeof(HelloInfo)) return false;
  HelloInfo hi{};

  memcpy(&hi, buf, sizeof(hi));
  if (hi.crc8 != crc8_xor4(hi.role, hi.mmode, hi.smode, hi.flags)) return false;

  remote_info_valid = true;
  remote_role  = hi.role;
  remote_mmode = hi.mmode;
  remote_smode = hi.smode;
  remote_flags = hi.flags;
  updateCompatStatus();
  return true;
}

static void updateCompatStatus() {
  // Default: compatible unless proven otherwise
  remote_compat_ok = true;
  remote_compat_msg[0] = 0;

  if (!remote_info_valid) return;

  bool local_p2p = false;
  if (cfg_role == 1) {
    // MASTER side: P2P when master output is PPM2PPM
    local_p2p = (cfg_Mmode == PPM2PPM_MASTER);
  } else {
    // SLAVE side: P2P when slave input is PPM2PPM OR (on S3) joystick output is P2P
  #if (USE_ESP32 == ESP32S3)
    local_p2p = (cfg_Smode == PPM2PPM_SLAVE) || (cfg_Sjoystick == PPM2PPM_JOYSTICK);
  #else
    local_p2p = (cfg_Smode == PPM2PPM_SLAVE);
  #endif
  }

  bool remote_p2p = (remote_flags & HI_FLAG_PPM2PPM) != 0;

  // Symétrique : si un seul est en P2P => incompatible (sur les 2)
  if (local_p2p != remote_p2p) {
    remote_compat_ok = false;
    strncpy(remote_compat_msg, "SET BOTH P2P", sizeof(remote_compat_msg) - 1);
    remote_compat_msg[sizeof(remote_compat_msg) - 1] = 0;
    return;
  }

  // Optional: add additional compatibility rules here later.
}


void oledPrintInfoOnLastLine(U8G2 &u8g2)
{
  u8g2.setCursor(0, 40);

#if USE_OTA
  // If an explicit OTA window is active, show it prominently on the last line
  // so the user knows the module is waiting for an OTA upload.
  if (OtaWindowIsActive()) {
    u8g2.print("OTA Waiting...");
    return;
  }
#endif

  // If FileTransfer (WiFi FT) is active, show ONLY "FT ON"
  if (wifi_ft) {
    u8g2.print("FT ON");
    return;
  }

  // 🔴 PRIORITY: scan UI latch (~3s)
  // Note: we latch UI state at scan start so the OLED can show "Scanning" even if scan/link completes too fast.
  if (uiScanActive) {
    if (uiScanHold < 3000) {
      static const char *spin[] = { "|", "/", "-", "\\" };
      static uint8_t i = 0;

      // If we already discovered at least one responder, show its name (first entry) to confirm detection.
      const ScanDev* sd = nullptr;
      if (scanCount) {
        for (uint8_t k = 0; k < MAX_SCAN_DEV; k++) {
          if (scanDev[k].used) { sd = &scanDev[k]; break; }
        }
      }

      // 1) Pendant 1s, toujours afficher "Scanning"
      if (uiScanHold < 1000) {
        u8g2.print("Scanning ");
      }
      // 2) Après 1s, afficher le nom trouvé si dispo, sinon fallback "Scanning"
      else if (sd && sd->name[0]) {
        // Keep it short: the OLED line is narrow
        for (uint8_t c = 0; c < 10 && sd->name[c]; c++) u8g2.print(sd->name[c]);
        u8g2.print(" ");
      } else {
        u8g2.print("Scanning ");
      }

      u8g2.print(spin[i++ & 3]);
      return;
    } else {
      uiScanActive = false;
    }
  }

  if (remote_info_valid && !remote_compat_ok) {
    static uint8_t ph = 0;
    static elapsedMillis t;
    if (t >= 1000) { t = 0; ph ^= 1; }

    if (ph == 0) u8g2.print("INCOMP");
    else         u8g2.print(remote_compat_msg[0] ? remote_compat_msg : "SET BOTH");
    return;
  }
  
  // Otherwise show local mode + peer mode (peer mode available only when ESPNOW link is up)
  bool linkOk = (linked_peer_set || bound_peer_set);
  bool haveRemote = linkOk && remote_info_valid;

  // Extra hint when the remote SLAVE is an ESP32-S3 joystick
  // (remote_smode is provided by HELLO/HELLO_ACK mode discovery)
  const char* joyHint = "";
  if (haveRemote) {
    if (remote_smode == HC05_JOYSTICK)         joyHint = " HC05";
    else if (remote_smode == PPM2PPM_JOYSTICK) joyHint = " P2P";
  }

  // Alternate display: modes <-> version every ~2s
  static uint8_t showVer = 0;
  static elapsedMillis tAlt;
  if (tAlt >= 2000) { tAlt = 0; showVer ^= 1; }

  if (showVer) {
    // Affiche la version (BUILD_TAG) pendant ~2s
    // (tu peux limiter la longueur si besoin)
    u8g2.print("v");
    u8g2.print(BUILD_TAG);
    u8g2.print(" OAVRc");
    return;
  }

  if (cfg_role == 1) { // local is MASTER
    u8g2.print(Mode_STR_Mini[cfg_Mmode]);
    u8g2.print("/");
    u8g2.print(haveRemote ? Mode_STR_Mini[remote_smode] : "---");
    u8g2.print(joyHint);
  } else {             // local is SLAVE

#if (USE_ESP32 == ESP32S3)
    // Prefix JOY when S3 is acting as joystick
    if (cfg_Sjoystick == HC05_JOYSTICK || cfg_Sjoystick == PPM2PPM_JOYSTICK) {
      u8g2.print("JOY ");
    }
#endif

#if (USE_ESP32 == ESP32S3)
    if (cfg_Sjoystick == HC05_JOYSTICK)      u8g2.print("HC05");
    else if (cfg_Sjoystick == PPM2PPM_JOYSTICK) u8g2.print("P2P");
    else u8g2.print(Mode_STR_Mini[cfg_Smode]);
#else
    u8g2.print(Mode_STR_Mini[cfg_Smode]);
#endif

    u8g2.print("/");

    if (haveRemote)
      u8g2.print(Mode_STR_Mini[remote_mmode]);
    else
      u8g2.print("---");
    }
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void oledDrawStatus() {
  if (!oled_ok) return;

#ifdef USE_LOGO
  // -------------------------------------------------------------------------
  // Logo timing (non-blocking):
  // - Boot: show logo for 3s
  // - Then: show logo every 10s for ~2s
  // - Overlay mode controlled by USE_LOGO_OVERLAY_MODE
  // -------------------------------------------------------------------------
  const uint32_t LOGO_BOOT_MS  = 3000;
  const uint32_t LOGO_EVERY_MS = 10000;
  const uint32_t LOGO_SHOW_MS  = 2000;

  static bool     _sched_init    = false;
  static uint32_t _logo_next_ms  = 0;
  static uint32_t _logo_until_ms = 0;
  static bool     _logo_show     = false;

  const uint32_t now = millis();

  if (!_sched_init) {
    _sched_init = true;
    _logo_show = false;
    _logo_until_ms = 0;
    _logo_next_ms = oled_boot_ms + LOGO_EVERY_MS;
  }

  // 1) Boot logo window
  if ((uint32_t)(now - oled_boot_ms) < LOGO_BOOT_MS) {
    u8g2.clearBuffer();
    u8g2.setDrawColor(1);
    u8g2.setBitmapMode(1); // transparent background
#if (USE_ESP32 == ESP32S3)
    u8g2.drawXBMP(0, 0, LOGO_S3_W, LOGO_S3_H, logo_s3_bits);
#else
    // C3 boot logo: choose based on current mode
    if (cfg_Sjoystick == HC05_JOYSTICK || cfg_Sjoystick == PPM2PPM_JOYSTICK) {
      u8g2.drawXBMP(0, 0, LOGO_C3_RJ_W, LOGO_C3_RJ_H, logo_c3_radio_joystick_bits);
    } else {
      u8g2.drawXBMP(0, 0, LOGO_C3_RR_W, LOGO_C3_RR_H, logo_c3_radio_radio_bits);
    }
#endif
    u8g2.setBitmapMode(0);
    u8g2.sendBuffer();
    return;
  }

  // 2) Periodic logo scheduler (10s / 2s)
  if (!_logo_show) {
    if ((int32_t)(now - _logo_next_ms) >= 0) {
      _logo_show = true;
      _logo_until_ms = now + LOGO_SHOW_MS;
    }
  } else {
    if ((int32_t)(now - _logo_until_ms) >= 0) {
      _logo_show = false;
      _logo_next_ms = now + LOGO_EVERY_MS;
    }
  }
#else
  const bool _logo_show = false;
#endif // USE_LOGO

  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------
  u8g2.clearBuffer();

#ifdef USE_LOGO
#ifndef USE_LOGO_OVERLAY_MODE
  // Non-overlay: show logo OR text, never both
  if (_logo_show) {
    u8g2.setDrawColor(1);
    u8g2.setBitmapMode(1);
#if (USE_ESP32 == ESP32S3)
    u8g2.drawXBMP(0, 0, LOGO_S3_W, LOGO_S3_H, logo_s3_bits);
#else
    if (cfg_Sjoystick == HC05_JOYSTICK || cfg_Sjoystick == PPM2PPM_JOYSTICK) {
      u8g2.drawXBMP(0, 0, LOGO_C3_RJ_W, LOGO_C3_RJ_H, logo_c3_radio_joystick_bits);
    } else {
      u8g2.drawXBMP(0, 0, LOGO_C3_RR_W, LOGO_C3_RR_H, logo_c3_radio_radio_bits);
    }
#endif
    u8g2.setBitmapMode(0);
    u8g2.sendBuffer();
    return;
  }
#endif // !USE_LOGO_OVERLAY_MODE
#endif // USE_LOGO

  // --- TEXT screen (original content) ---
#if (USE_ESP32 != ESP32S3)
  u8g2.setFont(u8g2_font_5x8_tf);   // lisible, compact pour 0.42"
#else
  u8g2.setFont(u8g2_font_7x13B_tf);  // bold lisible, compact pour 0.96"
#endif

  // 72px width => ~12 chars max
  // Line 1 (y=10): name + role letter
  u8g2.setCursor(0, 10);
  // cfg_name doit être une String
  for (int i = 0; i < 11 && i < (int)cfg_name.length(); i++) {
    u8g2.print(cfg_name[i]);
  }
  u8g2.print(cfg_role ? "_M" : "_S");

  // line 1 RSSI logo
  int rssi = last_rssi_dbm; /* RSSI en dBm */
  // RSSI invalid when not connected (READY/CONNECTING) or uninitialized (0/-1/127/99)
  bool connected = (link_phase == PH_CONNECTED);
  if (!connected) rssi = -200;
  if (rssi == 0 || rssi == -1 || rssi == 127 || rssi == 99) rssi = -200;

  uint8_t lvl = rssiToWifiLevel(rssi, connected);
#if (USE_ESP32 != ESP32S3)
  drawWifiIcon(u8g2, 72-1, 0, lvl);
#else
  drawWifiIcon(u8g2, 128-1, 0, lvl);
#endif

// Line 2 (y=20): CONNECTED/CONNECTING/READY
  u8g2.setCursor(0, 20);
  if (link_phase == PH_CONNECTED) u8g2.print("CONNECTED");
  else if (link_phase == PH_CONNECTING) u8g2.print("CONNECTING");
  else u8g2.print("READY");

  // Line 3 (y=30): RSSI
  u8g2.setCursor(0, 30);
  u8g2.print("RSSI=");
  u8g2.print((int32_t)last_rssi_dbm);
  u8g2.print("dBm");

  // Line 4 Version or cfg_Mmode
  oledPrintInfoOnLastLine(u8g2);

  // Line 5 only for S3 as Joystick reader
#if (USE_ESP32 == ESP32S3)
  u8g2.setFont(u8g2_font_5x8_tr);
  u8g2.setCursor(0, 58); // ligne 5 (ajuste à 56 si besoin)
  u8g2.print("OTG:");
  u8g2.print(g_usb_host_started ? "HOST" : "OFF");

  u8g2.print(" DEV:");
  u8g2.print(g_usb_dev_mounted ? "YES" : "NO");

  // VBUS_EN (GPIO9)
  #ifdef VBUS_EN
    u8g2.print(" VBUS:");
    u8g2.print(digitalRead(VBUS_EN) ? "ON" : "OFF");
  #endif
#endif


#ifdef USE_LOGO_OVERLAY_MODE
  // Overlay mode: draw logo on top of text during the periodic window
#if (USE_ESP32 == ESP32S3)
  if (_logo_show) {
    u8g2.setDrawColor(1);
    u8g2.setBitmapMode(1); // transparent
#ifdef USE_LOGO
    u8g2.drawXBMP(0, 0, LOGO_S3_W, LOGO_S3_H, logo_s3_bits);
#endif // USE_LOGO
    u8g2.setBitmapMode(0);
  }
#endif
#elif (USE_ESP32 == ESP32C3)

  if (_logo_show) {
    u8g2.setDrawColor(1);
    u8g2.setBitmapMode(1); // transparent
#ifdef USE_LOGO
    // C3: choose logo based on whether a joystick slave is configured
    if (cfg_Sjoystick == HC05_JOYSTICK || cfg_Sjoystick == PPM2PPM_JOYSTICK) {
      u8g2.drawXBMP(0, 0, LOGO_C3_RJ_W, LOGO_C3_RJ_H, logo_c3_radio_joystick_bits);
    } else {
      u8g2.drawXBMP(0, 0, LOGO_C3_RR_W, LOGO_C3_RR_H, logo_c3_radio_radio_bits);
    }
#endif // USE_LOGO
    u8g2.setBitmapMode(0);
  }
#endif

  
  // --- Overlay logo (optional) ---
// #ifdef USE_LOGO_OVERLAY_MODE
// #ifdef USE_LOGO
//   if (_logo_show) {
//     u8g2.setDrawColor(1);
//     u8g2.setBitmapMode(1);
// #if (USE_ESP32 == ESP32S3)
//     u8g2.drawXBMP(0, 0, LOGO_S3_W, LOGO_S3_H, logo_s3_bits);
// #else
//     if (cfg_Sjoystick == HC05_JOYSTICK || cfg_Sjoystick == PPM2PPM_JOYSTICK) {
//       u8g2.drawXBMP(0, 0, LOGO_C3_RJ_W, LOGO_C3_RJ_H, logo_c3_radio_joystick_bits);
//     } else {
//       u8g2.drawXBMP(0, 0, LOGO_C3_RR_W, LOGO_C3_RR_H, logo_c3_radio_radio_bits);
//     }
// #endif
//     u8g2.setBitmapMode(0);
//   }
// #endif // USE_LOGO
// #endif // USE_LOGO_OVERLAY_MODE

  u8g2.sendBuffer();
}



// ---------------- ESPNOW ----------------
enum : uint8_t { PKT_HELLO=1, PKT_HELLO_ACK=2, PKT_DATA=3, PKT_SCAN_REQ=4, PKT_SCAN_RSP=5, PKT_PPM=6 };

struct __attribute__((packed)) Packet {
  uint8_t type;
  uint8_t flags;
  uint16_t len;
  uint8_t payload[MAX_PAYLOAD];
};


// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static bool ensurePeer(const uint8_t mac[6]) {
  if (esp_now_is_peer_exist(mac)) return true;

  // Use current WiFi home channel (important when STA is connected to an AP)
  uint8_t ch = ESPNOW_CHANNEL;
  wifi_second_chan_t sch = WIFI_SECOND_CHAN_NONE;
  esp_wifi_get_channel(&ch, &sch);

  esp_now_peer_info_t pi{};
  memcpy(pi.peer_addr, mac, 6);
  pi.channel = ch;
  pi.encrypt = false;
  return esp_now_add_peer(&pi) == ESP_OK;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void sendPkt(const uint8_t mac[6], uint8_t type, const void* data, uint16_t len, uint8_t flags=0) {
  if (!ensurePeer(mac)) return;
  Packet p{};
  p.type = type;
  p.flags = flags;
  p.len = (len > MAX_PAYLOAD) ? MAX_PAYLOAD : len;
  if (data && p.len) memcpy(p.payload, data, p.len);
  esp_now_send(mac, (uint8_t*)&p, sizeof(Packet) - MAX_PAYLOAD + p.len);
  last_tx_ms = millis();
  tx_count++;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void broadcastPkt(uint8_t type, const void* data, uint16_t len) {
  uint8_t bcast[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
  ensurePeer(bcast);
  sendPkt(bcast, type, data, len);
}

// Core 3.x callback signature:static void onRecv(const esp_now_recv_info_t* info, const uint8_t* data, int len) {
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void onRecv(const esp_now_recv_info_t* info, const uint8_t* data, int len) {
  
  if (!info || !data || len < 4) return;
  const uint8_t* mac = info->src_addr;
  const Packet* p = (const Packet*)data;

  // If we know peer modes and they are incompatible, ignore data packets.
  // We still accept HELLO/ACK to allow recovery if modes change.
  if (remote_info_valid && !remote_compat_ok) {
    if (p->type == PKT_DATA || p->type == PKT_PPM) return;
  }


  last_rx_ms = millis();
  rx_count++;
  if (info && info->rx_ctrl) last_rssi_dbm = (int8_t)info->rx_ctrl->rssi;


  if (p->type == PKT_HELLO) {
    // v1.7u: latch peer role/modes if provided
    parseHelloInfo(p->payload, p->len);

    memcpy(linked_peer_mac, mac, 6);
    linked_peer_set = true;
    link_connected = true;
    link_phase = PH_CONNECTED;
    //setStatusPin(true);
    { HelloInfo hi; buildHelloInfo(hi); sendPkt(mac, PKT_HELLO_ACK, &hi, sizeof(hi)); }
    return;
  }
  if (p->type == PKT_HELLO_ACK) {
    // v1.7u: latch peer role/modes if provided
    parseHelloInfo(p->payload, p->len);

    memcpy(linked_peer_mac, mac, 6);
    linked_peer_set = true;
    link_connected = true;
    link_phase = PH_CONNECTED;
    //setStatusPin(true);
    return;
  }

  // PPM->PPM binary packet (CRC-protected) OR ASCII "tf ..." relay
  if (p->type == PKT_PPM) {

    // 1) If payload is already an ASCII "tf ..." line, relay it to BT UART directly.
    if (p->len >= 3 && p->payload[0] == 't' && p->payload[1] == 'f' && p->payload[2] == ' ') {
      if (dbg_bt) {
        Dbg.print("[TF MASTER RX] ");
        Dbg.write((const char*)p->payload, p->len);
        Dbg.println();
      }
      BT.write(p->payload, p->len);
      return;
    }

    // 2) Otherwise treat as binary PPM (PPM->PPM direct)
    if (cfg_role == 1 && cfg_Mmode == CPPM_MASTER) {
      if (p->len == sizeof(PpmBinPayload)) {
        PpmBinPayload pb{};
        memcpy(&pb, p->payload, sizeof(pb));
        if (pb.magic == 0xA5) {
          uint16_t calc = ppm_crc16_ccitt((const uint8_t*)&pb, sizeof(pb) - 2);
          if (calc == pb.crc) {
            uint16_t ch_us_aligned[8];
            memcpy(ch_us_aligned, pb.ch_us, sizeof(ch_us_aligned));
            PpmMasterSetChannelsUs(ch_us_aligned, 8);
          } else if (dbg_bt) {
            Dbg.println("[PPM] CRC FAIL");
          }
        }
      }
    }

    return;
  }


  if (p->type == PKT_DATA) {

    // MASTER only: filter Trainer frames unless explicitly unmuted
    if (cfg_role == 1 && (tfMute || (millis() < tfMuteUntilMs))) {
      for (uint16_t i = 0; i < p->len; i++) {
        uint8_t b = p->payload[i];

        // Drop whole "tf ..." line safely, even if fragmented
        if (tfDropLine) {
          if (b == '\n' || b == '\r') {
            tfDropLine = false;
            tfAtLineStart = true;
            tfState = 0;
          }
          continue;
        }

        if (tfAtLineStart) {
          if (tfState == 0 && b == 't') { tfState = 1; continue; }
          if (tfState == 1 && b == 'f') { tfState = 2; continue; }
          if (tfState == 2 && b == ' ') {
            tfDropLine = true;
            tfDroppedCount++;
            tfState = 0;
            continue;
          }

          // Not a tf frame → flush buffered prefix
          if (tfState == 1) BT_ONLY(BT.write('t'));
          if (tfState == 2) { BT_ONLY(BT.write('t')); BT_ONLY(BT.write('f')); }
          tfState = 0;
        }

        if (cfg_role == 1 && cfg_Mmode == SBUS_MASTER) {
          SbusMasterFeed(&b, 1);
        } else if (cfg_role == 1 && cfg_Mmode == CPPM_MASTER) {
          PpmMasterFeed(&b, 1);
        } else {
          BT_ONLY(BT.write(b));
        }
        tfAtLineStart = (b == '\n' || b == '\r');
      }
      return;
    }

    // Default path (tfMute OFF or SLAVE)
    if (cfg_role == 1 && cfg_Mmode == SBUS_MASTER) {
      SbusMasterFeed(p->payload, p->len);
    } else if (cfg_role == 1 && cfg_Mmode == CPPM_MASTER) {
      PpmMasterFeed(p->payload, p->len);
    } else {
      BT_ONLY(BT.write(p->payload, p->len));
    }

    if (dbg_bt && p->len) {
      for (uint16_t i = 0; i < p->len; i++)
        dataFeedChar((char)p->payload[i]);
    }
    return;
  }


  if (p->type == PKT_SCAN_REQ) {
    if (cfg_role == 0) {
      char namebuf[16] = {0};
      strncpy(namebuf, cfg_name.c_str(), sizeof(namebuf)-1);
      sendPkt(mac, PKT_SCAN_RSP, namebuf, (uint16_t)strlen(namebuf));
    }
    return;
  }
  if (p->type == PKT_SCAN_RSP) {
    if (cfg_role == 1 && scanning) {
      char rname[16] = {0};
      uint16_t n = (p->len < sizeof(rname)-1) ? p->len : (sizeof(rname)-1);
      if (n) memcpy(rname, p->payload, n);
      rname[n] = 0;
      scanAddOrUpdate(mac, rname);
      // v1.6l: cache peer name for AT+RNAME? after reboot
      bool changed = (!saved_peer_set) || memcmp(saved_peer_mac, mac, 6) != 0 || strncmp(saved_peer_name, rname, sizeof(saved_peer_name)) != 0;
      if (changed) {
        memcpy(saved_peer_mac, mac, 6);
        saved_peer_set = true;
        strncpy(saved_peer_name, rname, sizeof(saved_peer_name)-1);
        saved_peer_name[sizeof(saved_peer_name)-1] = 0;
        saveConfig();
      }
    }
    return;
  }
}


// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void espnowStart() {
  WiFi.mode(WIFI_STA);

  // If STA is connected, keep the AP's channel (do NOT force ESPNOW_CHANNEL)
  // Otherwise, set a default channel for standalone ESPNOW use.
  if (WiFi.status() != WL_CONNECTED) {
    esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);
  }

  uint8_t ch = ESPNOW_CHANNEL;
  wifi_second_chan_t sch = WIFI_SECOND_CHAN_NONE;
  esp_wifi_get_channel(&ch, &sch);
  Dbg.printf("[ESPNOW] home channel=%u\n", ch);

  esp_now_deinit();
  if (esp_now_init() != ESP_OK) {
    Dbg.println("esp_now_init FAILED");
    return;
  }
  esp_now_register_recv_cb(onRecv);
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void espnowStop() {
  esp_now_deinit();
}

// ---------------- AT subset ----------------
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void btOK()  { btWriteStr("OK\r\n"); }
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void btERR() { btWriteStr("ERROR\r\n"); }

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void btReplyGet(const String& prefix, const String& value) {
  btWriteStr(prefix.c_str());
  BT_ONLY(BT.print(value));
  if (dbg_bt) {
    for (size_t i=0;i<value.length();i++) dbgFeedChar(value[i], btTxLine, btTxLen, "[TX]");
  }
  btWriteStr("\r\nOK\r\n");
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void btReplyPswd() {
  btReplyGet("+PSWD:", String("\"") + cfg_pswd + "\"");
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void handleATLine(const String& line) {
  if (line == "AT") { btOK(); return; }

  if (line.startsWith("AT+UART=")) {
    String arg = line.substring(8);
    uint32_t b = (uint32_t)strtoul(arg.c_str(), nullptr, 10);
    if (b >= 1200 && b <= 921600) {
      cfg_baud = b;
      saveConfig();
      btOK();
      delay(20);
      BT.updateBaudRate(cfg_baud);
    } else btERR();
    return;
  }

  if (line.startsWith("AT+CLASS="))  { btOK(); return; }
  if (line.startsWith("AT+INQM="))   { btOK(); return; }
  if (line.startsWith("AT+IAC="))    { btOK(); return; }
  if (line.startsWith("AT+IPSCAN=")) { btOK(); return; }
  if (line == "AT+INIT")             { btOK(); return; }
  if (line == "AT+DISC" || line=="AT+INQC") { scanning = false; btOK(); return; }
  if (line == "AT+RMAAD")            { scanClear(); scanning = false; btOK(); return; }
  if (line.startsWith("AT+CMODE="))  { btOK(); return; }

  if (line.startsWith("AT+ROLE=")) {
    int v = atoi(line.substring(8).c_str());
    if (v==0 || v==1) { cfg_role = (uint8_t)v; saveConfig(); btOK(); }
    else btERR();
    return;
  }

  if (line.startsWith("AT+NAME=")) {
    cfg_name = line.substring(8);
    if (cfg_name.length() > 10) cfg_name = cfg_name.substring(0,10);
    saveConfig();
    btOK();
    return;
  }

  if (line.startsWith("AT+PSWD=")) {
    String arg = line.substring(8); arg.trim();
    if (arg.startsWith("\"") && arg.endsWith("\"") && arg.length() >= 2) {
      arg = arg.substring(1, arg.length()-1);
    }
    cfg_pswd = arg;
    if (cfg_pswd.length() > 10) cfg_pswd = cfg_pswd.substring(0,10);
    saveConfig();
    btOK();
    return;
  }

  if (line.startsWith("AT+LINK=")) {
    uint8_t mac[6];
    if (!parseNapUapLap(line.substring(8).c_str(), mac)) { btERR(); return; }

    memcpy(linked_peer_mac, mac, 6);
    linked_peer_set = true;
    link_connected = false;
    link_phase = PH_CONNECTING;

    memcpy(bound_peer_mac, mac, 6);
    bound_peer_set = true;
    saveConfig();

    { HelloInfo hi; buildHelloInfo(hi); sendPkt(mac, PKT_HELLO, &hi, sizeof(hi)); }
    btOK();
    return;
  }

  if (line == "AT+STATE?") { btReplyGet("+STATE:", link_connected ? "CONNECTED" : "READY"); return; }
  if (line == "AT+NAME?")  { btReplyGet("+NAME:", cfg_name); return; }
  if (line == "AT+PSWD?")  { btReplyPswd(); return; }


  // --- v1.7: extra info commands (safe, do not change OpenAVRc expectations) ---
  if (line == "AT+ADDR?") {
    uint8_t mymac[6]; WiFi.macAddress(mymac);
    btReplyGet("+ADDR:", macToNapUapLap(mymac));
    return;
  }

  // Extended diagnostic info (multi-line), for manual use (TeraTerm / Desktop debug)
  
  // Link diagnostics (single request)
  if (line == "AT+OAVLINK?") {
    String peera = "NONE";
    if (linked_peer_set) peera = macToNapUapLap(linked_peer_mac);
    else if (bound_peer_set) peera = macToNapUapLap(bound_peer_mac);

    btWriteStr("+OAVLINK:ROLE=");
    btWriteStr(cfg_role ? "MASTER" : "SLAVE");
    btWriteStr("\r\n");

    btWriteStr("+OAVLINK:STATE=");
    btWriteStr(link_connected ? "CONNECTED" : "READY");
    btWriteStr("\r\n");

    btWriteStr("+OAVLINK:PEER=");
    btWriteStrS(peera);
    if (dbg_bt) for (size_t k=0;k<peera.length();k++) dbgFeedChar(peera[k], btTxLine, btTxLen, "[TX]");
    btWriteStr("\r\n");

    btWriteStr("+OAVLINK:BOUND=");
    btWriteStr(bound_peer_set ? "YES" : "NO");
    btWriteStr("\r\n");

    btWriteStr("+OAVLINK:LAST_RX_MS=");
    btWriteU32((uint32_t)(millis() - last_rx_ms));
    btWriteStr("\r\n");

    btWriteStr("+OAVLINK:LAST_TX_MS=");
    btWriteU32((uint32_t)(millis() - last_tx_ms));
    btWriteStr("\r\n");

    btWriteStr("+OAVLINK:RSSI=");
    btWriteI32((int32_t)last_rssi_dbm);
    btWriteStr("\r\n");

    btWriteStr("+OAVLINK:RX=");
    btWriteU32((uint32_t)rx_count);
    btWriteStr(",TX=");
    btWriteU32((uint32_t)tx_count);
    btWriteStr("\r\n");

    btOK();
    return;
  }

  if (line == "AT+OAVINFO?") {
    uint8_t mymac[6]; WiFi.macAddress(mymac);

    String mya = macToNapUapLap(mymac);
    String peera = "NONE";
    if (linked_peer_set) peera = macToNapUapLap(linked_peer_mac);
    else if (bound_peer_set) peera = macToNapUapLap(bound_peer_mac);

    btWriteStr("+OAVINFO:ROLE=");
    btWriteStr(cfg_role ? "MASTER" : "SLAVE");
    btWriteStr("\r\n");

    btWriteStr("+OAVINFO:STATE=");
    btWriteStr(link_connected ? "CONNECTED" : "READY");
    btWriteStr("\r\n");

    btWriteStr("+OAVINFO:ADDR=");
    btWriteStrS(mya);
    if (dbg_bt) for (size_t k=0;k<mya.length();k++) dbgFeedChar(mya[k], btTxLine, btTxLen, "[TX]");
    btWriteStr("\r\n");

    btWriteStr("+OAVINFO:PEER=");
    btWriteStrS(peera);
    if (dbg_bt) for (size_t k=0;k<peera.length();k++) dbgFeedChar(peera[k], btTxLine, btTxLen, "[TX]");
    btWriteStr("\r\n");

    if (saved_peer_set && saved_peer_name[0]) {
      btWriteStr("+OAVINFO:PNAME=");
      btWriteStr(saved_peer_name);
      btWriteStr("\r\n");
    }

    btOK();
    return;
  }

  if (line == "AT+OAVSTAT?") {
    // Compact single-line status for scripts
    const char* roleStr = cfg_role ? "MASTER" : "SLAVE";
    const char* stateStr = link_connected ? "CONNECTED" : "READY";
    btWriteStr("+OAVSTAT:ROLE=");
    btWriteStr(roleStr);
    btWriteStr(",STATE=");
    btWriteStr(stateStr);
    uint32_t up_s = (millis() - stat_boot_ms) / 1000;
    btWriteStr(",UP=");
    btWriteU32(up_s);
    btWriteStr("s");
    btWriteStr(",TFPS=");
    btWriteU32((uint32_t)tfRate);
    btWriteStr(",DROP=");
    btWriteU32((uint32_t)tfDroppedCount);
    btWriteStr(",FT=");
    btWriteStr(wifi_ft ? "ON" : "OFF");
    btWriteStr("\r\nOK\r\n");
    return;
  }

  if (line == "AT+OAVCLR") {
    // Reset diagnostic counters only (does not touch bind/cache)
    tfDroppedCount = 0;
    tfDroppedPrev = 0;
    tfRate = 0;
    tfRateLastMs = millis();
    last_rx_ms = millis();
    rx_count++;

    btOK();
    return;
  }

  if (line == "AT+TFMUTE=ON") {
    tfMute = true;
    btOK();
    return;
  }
  if (line == "AT+TFMUTE=OFF") {
    tfMute = false;
    btOK();
    return;
  }
  if (line == "AT+TFMUTE?") {
    btWriteStr("+TFMUTE:");
    btWriteStr(tfMute ? "ON" : "OFF");
    btWriteStr("\r\n");
    btOK();
    return;
  }
  
  if (line.startsWith("AT+RNAME?")) {
    delay(10);
    uint8_t mac[6];
    if (!parseNapUapLap(line.substring(9).c_str(), mac)) { btERR(); return; }
    int idx = scanFindByMac(mac);
    if (idx >= 0 && scanDev[idx].name[0]) {
      btReplyGet("+RNAME:", scanDev[idx].name);
    }
    else if (saved_peer_set && memcmp(saved_peer_mac, mac, 6) == 0 && saved_peer_name[0]) {
      btReplyGet("+RNAME:", saved_peer_name);
    }
    else {
      btReplyGet("+RNAME:", "UNKNOWN");
    }
    return;
  }

  if (line == "AT+INQ") {
    if (cfg_role == 0) { btOK(); return; }

    if (link_phase != PH_CONNECTED) link_phase = PH_CONNECTING;

    scanClear();
    uiScanHold = 0;
    uiScanActive = true;
    scanning = true;
    broadcastPkt(PKT_SCAN_REQ, nullptr, 0);

    uint32_t t0 = millis();
    while (millis() - t0 < 350) { delay(1); }
    scanning = false;

    for (uint8_t i=0; i<MAX_SCAN_DEV; i++) {
      if (!scanDev[i].used) continue;
      btWriteStr("+INQ:");
      String a = macToNapUapLap(scanDev[i].mac);
      BT_ONLY(BT.print(a));
      if (dbg_bt) for (size_t k=0;k<a.length();k++) dbgFeedChar(a[k], btTxLine, btTxLen, "[TX]");
      btWriteStr(",1C010C,7FFF\r\n");
    }

    btOK();
    return;
  }

  if (line == "AT+RESET") { btOK(); delay(50); ESP.restart(); return; }

  btERR();
}

// ---------------- UART processing ----------------
static String atLine;

static char autoLineBuf[200];
static uint16_t autoLineLen = 0;
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void autoFlushAsData() {
  if (autoLineLen == 0) return;
  if (linked_peer_set) sendPkt(linked_peer_mac, PKT_DATA, autoLineBuf, autoLineLen);
  else if (bound_peer_set) sendPkt(bound_peer_mac, PKT_DATA, autoLineBuf, autoLineLen);
  autoLineLen = 0;
}


// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void processUART() {
  while ((BT_ENABLED() ? BT.available() : 0)) {
    char c = (char)(BT_ENABLED() ? BT.read() : -1);

    if (dbg_bt) dbgFeedChar(c, btRxLine, btRxLen, "[RX]");

    if (c == '\r' || c == '\n') {
      // Detect line type BEFORE we potentially append CR
      bool isAT = (autoLineLen >= 2 && autoLineBuf[0] == 'A' && autoLineBuf[1] == 'T');
      bool isTf = (!isAT && autoLineLen >= 3 && autoLineBuf[0] == 't' && autoLineBuf[1] == 'f' && autoLineBuf[2] == ' ');

      // Re-inject missing CR for tf lines (uCLI expects CR-terminated command)
      if (isTf) {
        if (autoLineLen < sizeof(autoLineBuf) - 1) {
          autoLineBuf[autoLineLen++] = '\r';
        }
      }

      autoLineBuf[autoLineLen] = 0;

      // If radio is doing SD/uCLI operations, mute tf for a short time to avoid UI pollution
      if (!strncmp((char*)autoLineBuf, "cp ", 3) ||
          !strncmp((char*)autoLineBuf, "ls", 2)  ||
          !strncmp((char*)autoLineBuf, "dir", 3) ||
          !strncmp((char*)autoLineBuf, "xmdm", 4)) {
        tfMuteUntilMs = millis() + 4000; // 4s window (adjust if needed)
      }

      if (isAT) {
        handleATLine(String((char*)autoLineBuf));
      } else {
        // Arm TF mute during SD/XMODEM operations (prevents SD screen pollution)
        if (!strncmp((char*)autoLineBuf, "cp ", 3) ||
            !strncmp((char*)autoLineBuf, "ls", 2)  ||
            !strncmp((char*)autoLineBuf, "dir", 3) ||
            !strncmp((char*)autoLineBuf, "xmdm", 4)) {
          tfMuteUntilMs = millis() + 4000;  // 4 seconds window
        }
        autoFlushAsData();
      }

      autoLineLen = 0;
      continue;
    }

    if (autoLineLen < sizeof(autoLineBuf)-1) autoLineBuf[autoLineLen++] = c;
    else autoFlushAsData();

  }
}

// ---------------- USB console (line-based) ----------------
static String usbLine;

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void showCreds() {
  Dbg.print("[STA] ssid='");
  Dbg.print(ft_sta_ssid);
  Dbg.print("' passLen=");
  Dbg.println(ft_sta_pass.length());
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void usbHelp() {
  Dbg.println();
  Dbg.println(F("[USB] Commands:"));
  Dbg.println(F("  h              -> help"));
  Dbg.println(F("  m              -> force ROLE=MASTER (1)"));
  Dbg.println(F("  s              -> force ROLE=SLAVE  (0)"));
  Dbg.println(F("  ssid <name>    -> set/save STA ssid"));
  Dbg.println(F("  pass <pass>    -> set/save STA password"));
  Dbg.println(F("  creds          -> show saved STA creds (ssid + pass length)"));
  Dbg.println(F("  delcreds       -> delete saved STA creds (ssid + pass length)"));
  Dbg.println(F("  moutput  <x>   -> set/save MASTER output: 0=PPM 1=SBUS 2=HC05 3=PPM2PPM (reboot)"));
  Dbg.println(F("  sinput   <x>   -> set/save SLAVE   input: 0=PPM 1=SBUS 2=HC05 3=PPM2PPM (reboot)"));
  Dbg.println(F("  ppmpulse <x>   -> set CPPM pulse mode (0=PPM POS, 1=PPM NEG)")); 
  Dbg.println(F("  scan [ms]      -> MASTER: ESPNOW scan (like AT+INQ) and list responders"));
  Dbg.println(F("  scan link      -> MASTER: ESPNOW scan and link to SLAVE"));
  Dbg.println(F("  i              -> info"));
//**************
  Dbg.println(F("  d              -> toggle BT debug (sniff UART BT, decode tf frames, show DATA-RX)"));
  Dbg.println(F("  dtf            -> toggle BT count tf stream from SLAVE"));
  if (!cfg_role)
    Dbg.println(F("  sg             -> toggle Slave  TF generator (simulate student data)"));
  else
    Dbg.println(F("  mg             -> toggle Master TF generator (simulate student data)"));
//**************
  Dbg.println(F("  w              -> show FT state"));
  Dbg.println(F("  w ap           -> start FT in AP mode (OpenAVRc-FT / openavrc123)"));
  Dbg.println(F("  w sta          -> start FT in STA mode using saved creds"));
  Dbg.println(F("  w sta <s> <p>  -> start FT in STA mode + save creds"));
  Dbg.println(F("  w off          -> stop FT and return normal"));
//**************
  Dbg.println(F("  ota 1          -> enable OTA update window for 60s (uses saved STA creds, pauses ESPNOW/FT bridge)"));
  Dbg.println(F("  ota 0          -> disable OTA window (and stop STA if started by ota)"));
  Dbg.println(F("  at?            -> at Commands help"));
  Dbg.println(F("  diag           -> version and more"));
  Dbg.println(F("  diag tf        -> diagnostic tf stream"));
  Dbg.println(F("  diag link      -> diagnostic link"));
//**************
#if (USE_ESP32 == ESP32S3)
  Dbg.println(F("  joy <x>        -> x=0/1 stop/start USB host polling"));
  Dbg.println(F("  joyout <x>     -> joystick output: tf=HC05 compatible, p2p=binary PPM packet"));
  Dbg.println(F("  joydbg <x>     -> x=0/1 print joystick channels (us) at ~5Hz"));
//**************
#endif
  Dbg.println();
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void atCmdHelp() {
  Dbg.println(F("[USB] AT Commands:"));
  Dbg.println(F("  at <cmd>       -> allows an AT cmommand, Ex: at AT+OAVINFO? etc..."));
  Dbg.println(F("  AT+OAVINFO?    -> compact info line (manual)"));
  Dbg.println(F("  AT+OAVLINK?    -> compact link line (manual)"));
  Dbg.println(F("  AT+OAVSTAT?    -> compact status line (manual)"));
  Dbg.println(F("  AT+OAVCLR      -> reset diagnostic counters (manual)"));
}
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void usbInfo() {
  uint8_t mymac[6]; WiFi.macAddress(mymac);
  char myMacStr[18]; macToStr(mymac, myMacStr, sizeof(myMacStr));

  char peerStr[18] = "NONE";
  if (linked_peer_set) macToStr(linked_peer_mac, peerStr, sizeof(peerStr));
  else if (bound_peer_set) macToStr(bound_peer_mac, peerStr, sizeof(peerStr));

  const char* atStr = "AUTO";

  const char* linkStr =
    (link_phase==PH_CONNECTED) ? "CONNECTED" :
    (link_phase==PH_CONNECTING) ? "CONNECTING" :
    "READY";

  const char* ftStr = wifi_ft ? "ON" : "OFF";
  const char* ftModeStr =
    (ft_mode==FT_AP) ? "AP" :
    (ft_mode==FT_STA) ? "STA" :
    "OFF";

  Dbg.println(F("\r\n=== OpenAVRc HC05-EMU ESPNOW ==="));
  Dbg.printf("Version : v%s\r\n", BUILD_TAG);
  Dbg.printf("Role    : %s | Mode:%s", cfg_role ? "MASTER" : "SLAVE", cfg_role ? 
#if (USE_ESP32 == ESP32C3)  
    M_Mode_STR[cfg_Mmode] : S_Mode_STR[cfg_Smode]);
#elif (USE_ESP32 == ESP32S3)//Joystick generate tf data or p2p
    M_Mode_STR[cfg_Mmode] : S_Mode_STR[cfg_Sjoystick]);
#endif
  if (cfg_Mmode == 0 || cfg_Smode == 0)
  {
    Dbg.printf(" | %s\r\n", cfg_ppm == CPPM_GEN_POS_MOD ? "Positive pulse" : "Negative pulse");
  }
  else
    Dbg.println();

  Dbg.printf("Baud    : %lu\r\n", (unsigned long)cfg_baud);
  Dbg.printf("Name    : %s\r\n", cfg_name.c_str());
  Dbg.printf("AT      : %s\r\n", atStr);
  Dbg.printf("Link    : %s\r\n", linkStr);
  Dbg.printf("My MAC  : %s\r\n", myMacStr);
  Dbg.printf("Peer MAC: %s\r\n", peerStr);
  Dbg.printf("Debug   : %s\r\n", dbg_bt ? "ON" : "OFF");
  Dbg.printf("Gen_S TF: %s\r\n", gen_tf ? "ON" : "OFF");
  Dbg.printf("Gen_M TF: %s\r\n", Master_gen_tf ? "ON" : "OFF");
  Dbg.printf("FT      : %s\r\n", ftStr);
  Dbg.printf("FT Mode : %s\r\n", ftModeStr);
  Dbg.printf("tf Slave: %lu tf/s=%lu\r\n", (unsigned long)tfDroppedCount, (unsigned long)tfRate);																																																								 

  if (wifi_ft) {
    IPAddress ip = (ft_mode == FT_AP) ? WiFi.softAPIP() : WiFi.localIP();
    Dbg.printf("FT IP   : %s\r\n", ip.toString().c_str());
    Dbg.println(F("FT Port : 3333"));
  }

  Dbg.println(F("===============================\r\n"));
}



// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void cmdDiag() {
  Dbg.println(F("[DIAG]"));

  Dbg.print(F("VERSION: "));
  Dbg.print(VERSION, 1);
  Dbg.print(F(" ("));
  Dbg.print(BUILD_TAG);
  Dbg.println(F(")"));

  Dbg.print(F("ROLE: "));
  Dbg.println(cfg_role ? F("MASTER") : F("SLAVE"));

  Dbg.print(F("LINK: "));
  Dbg.println(link_connected ? F("CONNECTED") : F("NOT_CONNECTED"));

  Dbg.print(F("PEER: "));
  if (linked_peer_set) {
    char buf[18];
    snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
             linked_peer_mac[0], linked_peer_mac[1], linked_peer_mac[2],
             linked_peer_mac[3], linked_peer_mac[4], linked_peer_mac[5]);
    Dbg.println(buf);
  } else {
    Dbg.println(F("NONE"));
  }

  Dbg.print(F("BOUND: "));
  Dbg.println(bound_peer_set ? F("YES") : F("NO"));

  Dbg.print(F("WIFI_MODE: "));
  wifi_mode_t m = WiFi.getMode();
  Dbg.println(m == WIFI_STA ? F("STA") : (m == WIFI_AP ? F("AP") : F("OFF")));

  Dbg.print(F("WIFI_CH: "));
  Dbg.println(WiFi.channel());

  Dbg.print(F("UP_MS: "));
  Dbg.println((unsigned long)millis());

  // Optional counters if present
#ifdef TF_MONITOR
  Dbg.print(F("TF_DROPPED: "));
  Dbg.println((unsigned long)tfDroppedCount);
#endif
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void cmdDiagTf() {
  Dbg.println(F("[DTF]"));
  Dbg.print(F("tf/s     : "));
  Dbg.println((unsigned long)tfRate);
  Dbg.print(F("dropped  : "));
  Dbg.println((unsigned long)tfDroppedCount);
  Dbg.print(F("up_ms    : "));
  Dbg.println((unsigned long)millis());
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void cmdDiagLink() {
  Dbg.println(F("[DLINK]"));

  Dbg.print(F("role     : "));
  Dbg.println(cfg_role ? F("MASTER") : F("SLAVE"));

  Dbg.print(F("phase    : "));
  switch (link_phase) {
    case PH_IDLE:       Dbg.println(F("IDLE")); break;
    case PH_CONNECTING: Dbg.println(F("CONNECTING")); break;
    case PH_CONNECTED:  Dbg.println(F("CONNECTED")); break;
    default:            Dbg.println(F("UNKNOWN")); break;
  }

  Dbg.print(F("connected: "));
  Dbg.println(link_connected ? F("YES") : F("NO"));

  Dbg.print(F("linked   : "));
  Dbg.println(linked_peer_set ? F("YES") : F("NO"));

  Dbg.print(F("bound    : "));
  Dbg.println(bound_peer_set ? F("YES") : F("NO"));

  Dbg.print(F("peer_mac : "));
  if (linked_peer_set) {
    char buf[18];
    snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
             linked_peer_mac[0], linked_peer_mac[1], linked_peer_mac[2],
             linked_peer_mac[3], linked_peer_mac[4], linked_peer_mac[5]);
    Dbg.println(buf);
  } else if (bound_peer_set) {
    char buf[18];
    snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
             bound_peer_mac[0], bound_peer_mac[1], bound_peer_mac[2],
             bound_peer_mac[3], bound_peer_mac[4], bound_peer_mac[5]);
    Dbg.println(buf);
  } else {
    Dbg.println(F("NONE"));
  }

  Dbg.print(F("last_rx_ms: "));
  Dbg.println((unsigned long)last_rx_ms);
  Dbg.print(F("now_ms    : "));
  Dbg.println((unsigned long)millis());
}


// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void usbHandleCmd(String cmd) {
  cmd.trim();
  if (!cmd.length()) return;

  // tokenize: op + rest
  int sp = cmd.indexOf(' ');
  String op = (sp<0) ? cmd : cmd.substring(0, sp);
  String rest = (sp<0) ? ""  : cmd.substring(sp+1);
  op.toLowerCase();
  rest.trim();

  if (op == "diag") {
    if (rest == "tf") { cmdDiagTf(); return; }
    if (rest == "link") { cmdDiagLink(); return; }
    cmdDiag();
    return;
  }

#if (USE_ESP32 == ESP32S3)
  // USB Host joystick control (ESP32-S3 only)
  //   joy 1  -> start USB host (requires OTG +5V)
  //   joy 0  -> stop polling
  if (op == "joy") {
    int v = rest.toInt();
    if (v == 1) {
      if (!joy_started) {
        Dbg.println("[JOY] starting USB host...");
        JoystickHidBegin();
        joy_started = true;
        Dbg.println("[JOY] USB host started");
      } else {
        Dbg.println("[JOY] already started");
      }
    } else {
      joy_started = false;
      Dbg.println("[JOY] polling stopped");
    }
    return;
  }

  if (op == "joydbg") {
    int v = rest.toInt();
    JoystickHidSetDebugPrint(v != 0);
    Dbg.printf("[JOY] debug print %s\r\n", (v != 0) ? "ON" : "OFF");
    return;
  }

  // joyout <x> : 0=HC05_JOYSTICK  1=PPM2PPM_JOYSTICK
  if (op == "joyout") {
    String v = rest;
    v.trim();
    v.toLowerCase();

    if (v == "p2p") {
      cfg_Sjoystick = PPM2PPM_JOYSTICK;
    } else if (v == "tf"){
      // défaut = tf
      cfg_Sjoystick = HC05_JOYSTICK;
    }
    else{
      Dbg.println("Usage: joyout tf|p2p");
      return;     
    }

    // Persist immediately (Preferences is not kept open globally)
    prefs.begin("hc05emu", false);
    prefs.putUChar("Sjoy", cfg_Sjoystick);
    prefs.end();

    Dbg.printf("[CFG] joyout=%s (Sjoy=%u)\r\n", v.c_str(), cfg_Sjoystick);
    return;
  }

#endif

  // ---------------------------------------------------------------------------
  // Explicit ESPNOW scan (MASTER only)
  // This triggers the same ESPNOW discovery as the radio master does via AT+INQ,
  // but the command is directly available from the ESP32 console.
  //
  // Usage:
  //   scan          -> broadcast SCAN_REQ and list responders (default ~350ms)
  //   scan <ms>     -> same, with custom listen window in ms (50..2000)
  //   scan <ms> link-> same + save first found as bound peer (auto-reconnect after reboot)
  //   scan link     -> same as default window + bind
  // ---------------------------------------------------------------------------
  if (op == "scan") {
    if (cfg_role == 0) {
      Dbg.println("[SCAN] Only usable by MASTER !");
      return;
    }

    bool doLink = false;
    uint32_t winMs = 350;
    if (rest.length()) {
      String arg = rest;
      arg.trim();

      // Optional keyword: "link" (save first found device as bound peer, auto-reconnect after reboot)
      if (arg.endsWith("link") || arg.endsWith("LINK")) {
        doLink = true;
        arg.remove(arg.length() - 4);
        arg.trim();
      }

      if (arg.length()) {
        int v = arg.toInt();
        if (v < 50) v = 50;
        if (v > 2000) v = 2000;
        winMs = (uint32_t)v;
      }
    }

    if (link_phase != PH_CONNECTED) link_phase = PH_CONNECTING;

    scanClear();
    uiScanHold = 0;
    uiScanActive = true;
    scanning = true;
    broadcastPkt(PKT_SCAN_REQ, nullptr, 0);

    uint32_t t0 = millis();
    while (millis() - t0 < winMs) { delay(1); }
    scanning = false;

    Dbg.print("[SCAN] Found "); Dbg.print((int)scanCount); Dbg.println(" device(s):");
    for (uint8_t i = 0; i < MAX_SCAN_DEV; i++) {
      if (!scanDev[i].used) continue;
      char macs[20];
      macToStr(scanDev[i].mac, macs, sizeof(macs));
      Dbg.print("  ");
      Dbg.print(macs);
      Dbg.print("  ");
      if (scanDev[i].name[0]) Dbg.println(scanDev[i].name);
      else Dbg.println("-");
    }

    // Optional: bind/link to the first found device (persist in NVS as "bind")
    if (doLink) {
      int first = -1;
      for (uint8_t i = 0; i < MAX_SCAN_DEV; i++) {
        if (scanDev[i].used) { first = (int)i; break; }
      }
      if (first < 0) {
        Dbg.println("[SCAN] link: no device to bind.");
      } else {
        memcpy(linked_peer_mac, scanDev[first].mac, 6);
        linked_peer_set = true;
        link_connected = false;
        link_phase = PH_CONNECTING;

        memcpy(bound_peer_mac, scanDev[first].mac, 6);
        bound_peer_set = true;
        saveConfig();

        char macs[20];
        macToStr(bound_peer_mac, macs, sizeof(macs));
        Dbg.print("[SCAN] link: bound peer saved: "); Dbg.println(macs);
        Dbg.println("[SCAN] link: will auto-reconnect after reboot (and attempts now).");
      }
    }
    return;
  }

  if (op == "at?") {
    atCmdHelp();
    return;
  }

  if (op == "at") {
    if (!rest.length()) {
      Dbg.println("Usage: at <AT command>");
      return;
    }
    // Ensure command starts with AT
    if (!rest.startsWith("AT")) rest = "AT" + rest;
    usb_at_mode = true;
    handleATLine(rest);
    usb_at_mode = false;
    return;
  }

  if (op == "m") {
    cfg_role = 1;
    saveConfig();
    Dbg.println("[USB] ROLE forced to MASTER (1) and saved");
    if (link_phase != PH_CONNECTED) link_phase = PH_IDLE;
    oledDrawStatus();
    return;
  }

  if (op == "s") {
    cfg_role = 0;
    saveConfig();
    Dbg.println("[USB] ROLE forced to SLAVE (0) and saved");
    if (link_phase != PH_CONNECTED) link_phase = PH_IDLE;
    oledDrawStatus();
    return;
  }
  
  if (op == "moutput") {
    if (rest.length()) {
      int v = rest.toInt();
      if (v < 0) v = 0; if (v > 3) v = 3;
      cfg_Mmode = (uint8_t)v;
      saveConfig();
      Dbg.print("[CFG] Master output mode saved: "); Dbg.println(cfg_Mmode);
      Dbg.println("[CFG] Rebooting to apply...");
      delay(50);
      ESP.restart();
    } else {
      Dbg.println("[CFG] Usage: moutput x   (0=PPM 1=SBUS 2=HC05 3=PPM2PPM)");
    }
    return;
  }

  if (op == "sinput") {
    if (rest.length()) {
      int v = rest.toInt();
      if (v < 0) v = 0; if (v > 3) v = 3;
      cfg_Smode = (uint8_t)v;
      saveConfig();
      Dbg.print("[CFG] Slave input mode saved: "); Dbg.println(cfg_Smode);
      Dbg.println("[CFG] Rebooting to apply...");
      delay(50);
      ESP.restart();
    } else {
      Dbg.println("[CFG] Usage: sinput x   (0=CPPM 1=SBUS 2=HC05 3=PPM2PPM)");
    }
    return;
  }

	if (op == "ppmpulse") {
	  if (rest.length()) {
		int v = rest.toInt();
		cfg_ppm = (v <= 0) ? CPPM_GEN_POS_MOD : CPPM_GEN_NEG_MOD;
		saveConfig();
		Dbg.print("[CFG] PPM polarity saved: ");
		Dbg.println((cfg_ppm == CPPM_GEN_POS_MOD) ? "POS" : "NEG");
		Dbg.println("[CFG] Rebooting to apply...");
		delay(50);
		ESP.restart();
	  } else {
		Dbg.println("[CFG] Usage: ppmpulse x   (0=PPM POS, 1=PPM NEG)");
	  }
	  return;
	}
  #if USE_OTA
  if (op == "ota") {
    if (rest.length()) {
      int v = rest.toInt();
      if (v <= 0) {
        OtaDisableWindow();
        PpmMasterSuspendForOta(false);
        SbusMasterSuspendForOta(false);
        Dbg.println("[OTA] window disabled");
      } else {
        // Ensure STA is up (we reuse the existing FT STA connector so credentials handling stays identical)
        bool startedFt = false;
        if (!wifi_ft) {
          if (ft_sta_ssid.length() == 0) {
            Dbg.println("[OTA] No STA creds saved. Use: ssid <name> / pass <pass> (or w sta <s> <p>)");
            return;
          }
          bool ok = wifiFtStartSTA(ft_sta_ssid, ft_sta_pass);
          if (!ok) {
            Dbg.println("[OTA] STA start failed");
            return;
          }
          startedFt = true;
        }
        // Keep the OTA window long enough for espota.exe to complete reliably on typical WiFi.
        // Default = 5 minutes.
        OtaEnableWindowMs(300000UL, startedFt);
        Dbg.println("[OTA] window enabled for 300s");
      }
    } else {
      Dbg.println("[OTA] Usage: ota 1   (enable 300s)  /  ota 0 (disable)");
    }
    return;
  }
  #endif


  if (op == "d") {
    dbg_bt = !dbg_bt;
    Dbg.print("[USB] BT debug ");
    Dbg.println(dbg_bt ? "ON" : "OFF");
    return;
  }

  if (op == "dtf") {
    dbg_tf = !dbg_tf;
    tfPrintLastMs = 0;   // force immediate print when enabling debug
    tfDroppedCount = 0;  // remise à zéro du décompte des lignes tf en provenance de l'élève
    Dbg.print("[USB] BT tf debug ");
    Dbg.println(dbg_tf ? "ON" : "OFF");
    return;
  }
  
  if (op == "sg"){
    if (!cfg_role){
      gen_tf = !gen_tf;
      Dbg.print("[USB] SLAVE TF generator ");
      Dbg.println(gen_tf ? "ON" : "OFF");
    }
    else
      Dbg.print("Only usable by SLAVE !");
    return;
  }

  if (op == "mg"){
    if (cfg_role){
      Master_gen_tf = !Master_gen_tf;
      Dbg.print("[USB] MASTER TF generator ");
      Dbg.println(Master_gen_tf ? "ON" : "OFF");
    }
    else
      Dbg.print("Only usable by MASTER !");
    return;
  }

  if (op == "ssid") {
    if (rest.length() == 0) { Dbg.println("[USB] Usage: ssid <name>"); return; }
    ft_sta_ssid = rest;
    ftSaveCreds();
    Dbg.println("[USB] STA SSID saved");
    showCreds();
    return;
  }

  if (op == "pass") {
    if (rest.length() == 0) { Dbg.println("[USB] Usage: pass <password>"); return; }
    ft_sta_pass = rest;
    ftSaveCreds();
    Dbg.println("[USB] STA password saved");
    showCreds();
    return;
  }

  if (op == "delcreds") {
    //if (rest.length() == 0) { Dbg.println("[USB] Usage: pass <password>"); return; }
    ft_sta_ssid = "";
    ft_sta_pass = "";
    ftSaveCreds();
    Dbg.println("[USB] STA name and password deleted");
    showCreds();
    return;
  }

  if (op == "creds") {
    showCreds();
    return;
  }

  if (op == "w") {
    if (rest.length() == 0) {
      Dbg.print("[FT] state: ");
      Dbg.println(wifi_ft ? "ON" : "OFF");
      Dbg.print("[FT] mode : ");
      Dbg.println(ft_mode==FT_AP?"AP":ft_mode==FT_STA?"STA":"OFF");
      if (wifi_ft) ftPrintIp();
      return;
    }

    String sub = rest;
    int sp2 = sub.indexOf(' ');
    String wop = (sp2<0) ? sub : sub.substring(0, sp2);
    String wrest = (sp2<0) ? ""  : sub.substring(sp2+1);
    wop.toLowerCase();
    wrest.trim();

    if (wop == "off") {
      if (wifi_ft) wifiFtStop();
      oledDrawStatus();
      return;
    }

    if (wop == "ap") {
      if (wifi_ft) wifiFtStop();
      wifiFtStartAP();
      oledDrawStatus();
      return;
    }

    if (wop == "sta") {
      // w sta  -> use saved creds
      // w sta <ssid> <pass> -> set+save creds then connect
      String ssid = ft_sta_ssid;
      String pass = ft_sta_pass;

      if (wrest.length() > 0) {
        int sp3 = wrest.indexOf(' ');
        if (sp3 < 0) {
          Dbg.println("[FT] Usage: w sta <ssid> <pass>   (or: w sta to use saved)");
          return;
        }
        ssid = wrest.substring(0, sp3);
        pass = wrest.substring(sp3+1);
        pass.trim();
        ft_sta_ssid = ssid;
        ft_sta_pass = pass;
        ftSaveCreds();
      }

      if (ssid.length() == 0 || pass.length() == 0) {
        Dbg.println("[FT] Missing STA creds. Use: ssid <name> / pass <pwd> then 'w sta'");
        return;
      }

      if (wifi_ft) wifiFtStop();
      bool ok = wifiFtStartSTA(ssid, pass);
      espnowStart();					
      Dbg.println(ok ? "[FT] STA OK" : "[FT] STA FAIL");
      oledDrawStatus();
      return;
    }

    Dbg.println("[FT] Usage: w ap | w sta <ssid> <pass> | w sta | w off | w");
    return;
  }

  if (op == "i") { usbInfo(); return; }
  if (op == "h" || op == "?") { usbHelp(); return; }

  Dbg.println("[USB] Unknown. Type 'h'.");
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void processUsbConsole() {
  while (Dbg.available()) {
    char c = (char)Dbg.read();
    if (c == '\r') continue;
    if (c == '\n') {
      usbHandleCmd(usbLine);
      usbLine = "";
    } else {
      if (usbLine.length() < 120) usbLine += c;
    }
  }
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
void setup() {

  ledInit();

#if (USE_ESP32 == ESP32C3)
  Serial.begin(115200);//Use Serial
  // Timeout USB Serial (ne bloque pas sans USB)
  uint32_t t0 = millis();
  while (!Serial && (millis() - t0 < 1500)) {
    delay(1);
  }
#elif (USE_ESP32 == ESP32S3)
  Serial1.begin(115200, SERIAL_8N1, DBG_RX, DBG_TX);//Use Serial1
  Serial1.println("\nESP32-S3 Joystick Reader (native USB host)");
  delay(50);
  Serial1.printf("\n[DBG] UART1 (Rx:%d Tx:%d) ready\r\n", DBG_RX, DBG_TX);

  // Bring up VBUS if you have external 5V switching hardware (optional)
  vbusOn(true);//On/Off +5v OTG signal

  rcs.init();
  applyChannelOrderFromProgmem();
  Dbg.printf("[RCMODE] order=%u Ail=%u Ele=%u Rud=%u Thr=%u\r\n",
            (unsigned)channelsOrder,
            (unsigned)AileronNbChannel,
            (unsigned)ElevatorNbChannel,
            (unsigned)RudderNbChannel,
            (unsigned)ThrottleNbChannel);

  // (USB HID host init deferred until after WiFi connect)

  rgbInit();

#endif

  Dbg.println("\n--- BOOT ---");
  Dbg.printf("Reset reason: %d\n", (int)esp_reset_reason());


  stat_boot_ms = millis();

  loadConfig();
					
  pinMode(SCAN_BTN_PIN, INPUT_PULLUP);      

  SbusSlaveBegin();
  SbusMasterBegin();

  PpmMasterBegin();ftLoadCreds();

  PpmSlaveBegin();

  Dbg.printf("role=%d Smode=%d\n", cfg_role, cfg_Smode);


  // v1.6j: bring up STA (if creds exist) so CTRL port is reachable without manual 'w sta'
  wifiCtrlBootInit();

#if (USE_ESP32 == ESP32S3)
  // IMPORTANT (ESP32-S3 OTG Host): do NOT auto-start the USB host at boot.
  // If VBUS is not powered (common during tests), usbHost.begin() can block here.
  // Start it manually when your OTG +5V is ready:
  //   joy 1   -> start USB host
  //   joy 0   -> stop polling (host stays installed)
  Dbg.println("[JOY] Type 'joy 1' to start USB host (needs OTG +5V)");
#endif

  oledInit();

  // BT UART is only required in modes that actually use the BT serial link (HC05 or SBUS).
  // Disabling it in pure PPM modes prevents pin/peripheral conflicts and keeps USB CDC responsive.
  bool bt_needed = false;
  if (cfg_role == 1) { // MASTER
    bt_needed = (cfg_Mmode == HC05_MASTER) || (cfg_Mmode == SBUS_MASTER);
  } else {             // SLAVE
    bt_needed = (cfg_Smode == HC05_SLAVE) || (cfg_Smode == SBUS_SLAVE);
  }

  if (bt_needed) {
    BT_ONLY(BT.begin(cfg_baud, SERIAL_8N1, UART_RX, UART_TX));//Use Serial2
  } else {
    // leave BT UART disabled in this mode
  }
  espnowStart();
  // --- v1.6j: force clean link state at boot (MASTER and SLAVE) ---
  link_connected = false;
  link_phase = PH_IDLE;

  if (bound_peer_set) {
    memcpy(linked_peer_mac, bound_peer_mac, 6);
    linked_peer_set = true;
    link_phase = PH_CONNECTING;
    Dbg.print("[LINK] ");Dbg.print(BUILD_TAG);Dbg.println(" boot: peer armed, waiting HELLO/ACK");
  }

  // --- v1.6j auto-reconnect (no scan needed after reboot) ---
  // If we already have a bound peer (saved from previous LINK), arm reconnection at boot.
  if (bound_peer_set) {
    memcpy(linked_peer_mac, bound_peer_mac, 6);
    linked_peer_set = true;
    link_connected = false;
    link_phase = PH_CONNECTING;
    Dbg.println("[LINK] auto-reconnect armed");
  }

  Dbg.println();
  Dbg.print("OpenAVRc HC05-EMU ESPNOW (single firmware)");
  Dbg.printf(" Version v%.1f (%s)\r\n", VERSION, BUILD_TAG);
  Dbg.println("USB console ready. Type 'h' + Enter for help.\r\n");

  link_phase = link_connected ? PH_CONNECTED : PH_IDLE;

  oledDrawStatus();

}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
void loop() {
  
  SbusMasterTask();
  SbusSlaveTask();
  PpmMasterTask();
  PpmSlaveTask();

#if (USE_ESP32 == ESP32S3)
  rgbTick();
  // Native USB HID joystick reader (S3). All mapping and ESPNOW sending is handled inside JoystickHidTask().
  if (joy_started) JoystickHidTask();
#endif

// --- v1.6j: HELLO retry from SLAVE too (fix reconnect after reboot) ---
  static uint32_t tHello_j = 0;
  if (linked_peer_set && !link_connected) {
    if (millis() - tHello_j > HELLO_INTERVAL_MS) {
      tHello_j = millis();
      { HelloInfo hi; buildHelloInfo(hi); sendPkt(linked_peer_mac, PKT_HELLO, &hi, sizeof(hi)); }
    }
  }

  // --- v1.6j: auto HELLO keepalive (MASTER and SLAVE) ---
  static uint32_t tHello_i = 0;
  if (linked_peer_set && !link_connected) {
    if (millis() - tHello_i > HELLO_INTERVAL_MS) {
      tHello_i = millis();
      { HelloInfo hi; buildHelloInfo(hi); sendPkt(linked_peer_mac, PKT_HELLO, &hi, sizeof(hi)); }
    }
  }

  processUsbConsole();
  // v1.7a: link watchdog
  if (link_connected && (millis() - last_rx_ms > LINK_TIMEOUT_MS)) {
    link_connected = false;
    if (linked_peer_set) link_phase = PH_CONNECTING; else link_phase = PH_IDLE;
    //setStatusPin(false);
  }

  // --- TF monitor: compute tf/s once per second ---
  if (millis() - tfRateLastMs >= 1000) {
    tfRateLastMs += 1000;
    tfRate = tfDroppedCount - tfDroppedPrev;
    tfDroppedPrev = tfDroppedCount;
  }

  //Print tf/s periodically when debug is ON (does not affect radio/UART)
  if (dbg_tf && (millis() - tfPrintLastMs >= 500)) {
    tfPrintLastMs = millis();
    Dbg.printf("[TF] tf/s=%lu dropped=%lu\r\n",
      (unsigned long)tfRate,
      (unsigned long)tfDroppedCount
    );
  }
  ctrlTask(); // v1.6j control channel

  // --- OTA window (console: ota 1) ---
  // During an OTA upload, we intentionally pause the FT bridge and the normal ESPNOW data path
  // so ArduinoOTA.handle() remains responsive and espota.exe can complete reliably.
  #if USE_OTA
  if (OtaWindowIsActive()) {
    OtaTask();
    ledUpdate();
    static uint32_t tDispOta = 0;
    if (millis() - tDispOta > 200) { tDispOta = millis(); oledDrawStatus(); }
    delay(1);
    return;
  }
  #endif


  // When FileTransfer is ON: exclusive TCP<->UART bridge
  if (wifi_ft) {
    wifiFtTask(BT);
    // OTA can be enabled only when WiFi (STA) is active (wifi_ft==true).
    // This is intentionally handled here so OTA remains responsive even while the FT bridge is running.
    #if USE_OTA
    OtaTask();
    #endif
    if (xferActive) {
      uint32_t now = millis();
      if (xferForceUntilMs && (int32_t)(now - xferForceUntilMs) < 0) {
        // still within forced XMODEM window
      } else if (now - xferLastMs > 2000) {
        xferActive = false;
      }
    }
    ledUpdate();

    static uint32_t tDispFt = 0;
    if (millis() - tDispFt > 300) { tDispFt = millis(); oledDrawStatus(); }

    delay(1);
    return;
  }

  processUART();

  // generate simulated student frames (tf ...) over ESPNOW
  if (gen_tf) cmdSg();

  if (Master_gen_tf) cmdMg();

  ledUpdate();

  static uint32_t tHello = 0;
  if (!isATMode() && linked_peer_set && !link_connected) {
    link_phase = PH_CONNECTING;
    if (millis() - tHello > HELLO_INTERVAL_MS) {
      tHello = millis();
      { HelloInfo hi; buildHelloInfo(hi); sendPkt(linked_peer_mac, PKT_HELLO, &hi, sizeof(hi)); }
    }
  } else if (!link_connected) {
    if (link_phase != PH_CONNECTED && !linked_peer_set) link_phase = PH_IDLE;
  }

  static uint32_t tDisp = 0;
  if (millis() - tDisp > 100) {
    tDisp = millis();
    oledDrawStatus();
  }

  // OTA is only active when wifi_ft==true, but calling the task here is harmless
  // and ensures quick recovery if the state toggles.
  OtaTask();

  // ---- Push button: MASTER only ->
// Short press  : same as console "scan link"
// Long  press  : enable OTA window (same as console "ota 1")
  static bool     scanBtnPrev = HIGH;
  static uint32_t scanBtnEdgeMs = 0;
  static bool     scanBtnDown = false;
  static uint32_t scanBtnDownMs = 0;
  static bool     scanBtnLongFired = false;

  if (cfg_role == 1) { // MASTER only
    bool now = digitalRead(SCAN_BTN_PIN);
    uint32_t t = millis();

    // Press edge (HIGH->LOW) with debounce
    if (scanBtnPrev == HIGH && now == LOW) {
      if (t - scanBtnEdgeMs > SCAN_BTN_DEBOUNCE_MS) {
        scanBtnEdgeMs = t;
        scanBtnDown = true;
        scanBtnDownMs = t;
        scanBtnLongFired = false;
      }
    }

    // Long press: fire once while still held down
    if (scanBtnDown && !scanBtnLongFired && now == LOW) {
      if (t - scanBtnDownMs >= SCAN_BTN_LONGPRESS_MS) {
        scanBtnLongFired = true;

        // Equivalent of console: ota 1
        usbHandleCmd("ota 1");
      }
    }

    // Release edge (LOW->HIGH): if no long-press action, treat as short press
    if (scanBtnDown && scanBtnPrev == LOW && now == HIGH) {
      scanBtnDown = false;

      if (!scanBtnLongFired) {
        // Avoid relaunch if already scanning (clean)
        if (!scanning) {
          usbHandleCmd("scan link");   // <-- EXACTLY same path as console
        }
      }
    }

    scanBtnPrev = now;
  } else {
    // keep state sane if we ever switch role at runtime
    scanBtnPrev = digitalRead(SCAN_BTN_PIN);
    scanBtnDown = false;
    scanBtnLongFired = false;
  }


  // OTA is only active when wifi_ft==true; in normal modes this call is a cheap no-op.
  OtaTask();

  delay(1);//yield propre + respiration du système
}

// sg: inject a simulated student tf frame by SLAVE directly to radio UART (BT Serial1)
// ckeck if SLAVE send well the good frame over the ESPNOW link to the MASTER
static void cmdSg()
{
  if (linked_peer_set || bound_peer_set) {
    tfMute = false;

    uint32_t now = millis();
    if (now - gen_last_ms >= 20) {
      gen_last_ms = now;
      gen_phase++;

      uint16_t ch[8] = {1500,1500,1500,1500,1500,1500,1500,1500};

      // CH1..CH4 visible movement (trainer uses first 4 channels)
      uint16_t tri1 = (uint16_t)((gen_phase % 200) < 100 ? (gen_phase % 100) : (100 - (gen_phase % 100)));
      ch[0] = 1000 + (tri1 * 10); // CH1: triangle slow 1000..2000

      uint16_t tri2 = (uint16_t)(((gen_phase * 2) % 200) < 100 ? ((gen_phase * 2) % 100) : (100 - ((gen_phase * 2) % 100)));
      ch[1] = 1000 + (tri2 * 10); // CH2: faster triangle

      ch[2] = 2000 - (tri1 * 10); // CH3: inverse triangle

      ch[3] = ((gen_phase / 50) % 2) ? 1700 : 1300; // CH4: step pattern (~1Hz at 50Hz loop)

      char frame[80];
      buildTfFrame(ch, frame, sizeof(frame));

      const uint8_t* dst = linked_peer_set ? linked_peer_mac : bound_peer_mac;
      sendPkt(dst, PKT_DATA, frame, (uint16_t)strlen(frame));

      if (dbg_bt) {
        Dbg.print("[DATA-TX] ");
        Dbg.println(frame);
      }
    }
  }
}

// mg: inject a simulated student tf frame by MASTER directly to radio UART (BT Serial1)
// This is for testing the BT trainer icon in OpenAVRc (uCli_Cmd_tf).
// ckeck if MASTER send well the good frame without need to SLAVE connection
static void cmdMg()
{
  tfMute = false;

  uint16_t ch[8] = {1500,1500,1500,1500,1500,1500,1500,1500};

  static uint32_t phase = 0;
  phase++;

  // CH1: triangle slow 1000..2000
  uint16_t tri1 = (uint16_t)((phase % 200) < 100 ? (phase % 100) : (100 - (phase % 100)));
  ch[0] = 1000 + (tri1 * 10);

  // CH2: triangle faster
  uint16_t tri2 = (uint16_t)(((phase * 2) % 200) < 100 ? ((phase * 2) % 100) : (100 - ((phase * 2) % 100)));
  ch[1] = 1000 + (tri2 * 10);

  // CH3: inverse triangle (so it moves opposite direction)
  ch[2] = 2000 - (tri1 * 10);

  // CH4: step pattern (toggles every ~1s if mg runs at 50Hz)
  ch[3] = ((phase / 50) % 2) ? 1700 : 1300;

  char frame[96];
  buildTfFrame(ch, frame, sizeof(frame));

  BT_ONLY(BT.write((const uint8_t*)frame, strlen(frame))); // already ends with '\r'

  if (dbg_bt) {
    Dbg.print("[MG->UART] ");
    Dbg.print(frame);
  }

}