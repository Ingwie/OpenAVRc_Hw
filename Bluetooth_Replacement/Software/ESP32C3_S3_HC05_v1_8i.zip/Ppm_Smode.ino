/*
 * Ppm_Smode.ino
 * ------------------------------------------------------------
 * SLAVE MODE - PPM INPUT READER
 *
 * This module captures a real PPM (CPPM) signal coming from a
 * radio transmitter acting as the SLAVE (trainer/student radio).
 *
 * Functional role in the project:
 * - Listens to a PPM input pin using an interrupt on rising edges.
 * - Measures pulse intervals to reconstruct channel values.
 * - Detects frame synchronization gaps.
 * - Makes decoded channel data available to higher layers
 *   (typically for conversion and forwarding via ESPNOW).
 *
 * This file DOES NOT:
 * - Generate PPM output
 * - Perform SBUS decoding
 * - Handle UART / HC05 communication
 *
 * Timing critical code runs in ISR context.
 * ------------------------------------------------------------
 */

#include "Ppm_Smode.h"
#include "Ppm_Link.h"
#include <ESP32_PPM.h>

static inline void tf_append_shex3(char* &w, uint16_t us) {
  // "s" + 3 hex digits (uppercase), ex 1500 -> s5DC
  static const char* H = "0123456789ABCDEF";
  uint16_t v = us; // already in microseconds
  *w++ = 's';
  *w++ = H[(v >> 8) & 0xF];
  *w++ = H[(v >> 4) & 0xF];
  *w++ = H[(v >> 0) & 0xF];
}

static inline uint8_t tf_crc_xor(const char* s, size_t n) {
  uint8_t c = 0;
  for (size_t i = 0; i < n; i++) c ^= (uint8_t)s[i];
  return c;
}

// Internal state (PPM SLAVE)
static bool ppmS_inited = false;
static uint8_t ppmS_seq = 0;

// Uses existing globals/functions from main sketch (same translation unit, Arduino concatenates .ino)
extern const int UART_RX; // GPIO4 in your design
extern uint8_t cfg_ppm;      // true=normal (RISING), false=inverted (FALLING) (as you described)



  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmSlaveBegin() {
  if (cfg_role != 0) return;           // SLAVE only
  if (cfg_Smode != CPPM_SLAVE) return; // PPM input mode only

  if (ppmS_inited) return;

  // GPIO4 used for PPM/SBUS input in your wiring
  pinMode(UART_RX, INPUT); // avoid pullups if Tx16S trainer is push-pull
  Dbg.println("PPM beginRx called");

  const bool rising = cfg_ppm; // true=PPM normal, false=PPM inverted
  // IMPORTANT: syncMinUs must match real trainer gap; 3500 is a safe starting point for 8ch
  Cppm32.beginRx((uint8_t)UART_RX, 8, rising, 3500, 800, 2200);

  ppmS_inited = true;
  ppmSuspendedByOta = false;

  if (dbg_bt) {
    Dbg.printf("[PPM-S] beginRx pin=%d ch=8 edge=%s syncMinUs=%d",
                  UART_RX, rising ? "RISING" : "FALLING", 3500);
  }
}


  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmSlaveTask() {
  if (!ppmS_inited) return;

  //debug channel in µS
  // Dbg.print("[PPM RAW] ");
  // for (int i = 1; i <= 8; i++) {
  //   Dbg.print(Cppm32.rxRead(i));
  //   Dbg.print(" ");
  // }
  // Dbg.println();

  // Debug at ~5Hz: show whether ISR is firing and last edge dt
  // static uint32_t lastDbg = 0;
  // const uint32_t now = millis();
  // if (now - lastDbg >= 200) {
  //   lastDbg = now;
  //   Dbg.printf("[PPM-S] isr=%lu lastdt=%lu avail=%u ch1=%u ch2=%u\r\n",
  //                 (unsigned long)Cppm32.rxIsrCount(),
  //                 (unsigned long)Cppm32.rxLastDtUs(),
  //                 (unsigned)Cppm32.rxAvailable(),
  //                 (unsigned)Cppm32.rxRead(1),
  //                 (unsigned)Cppm32.rxRead(2));
  // }

  if (!Cppm32.rxAvailable()) return;

  if (remote_mmode == HC05_MASTER) {// === ASCII tf ===

    // Convert CH1..CH8 to microseconds and build tf frame (same as SBUS slave)
    uint16_t chUs[8];
    for (int i = 0; i < 8; i++) chUs[i] = (uint16_t)Cppm32.rxRead((uint8_t)(i + 1));

    char tf[64];
    buildTfFrame(chUs, tf, sizeof(tf));

    // Send via ESPNOW to peer (same routing as SBUS slave)
    uint16_t n = (uint16_t)strnlen(tf, sizeof(tf));
    if (n) {
      if (linked_peer_set) sendPkt(linked_peer_mac, PKT_DATA, tf, n);
      else if (bound_peer_set) sendPkt(bound_peer_mac, PKT_DATA, tf, n);
    }

    if (dbg_bt) {
      Dbg.print("[PPM-S->ESPNOW] ");
      Dbg.write((const uint8_t*)tf, n);
      Dbg.println();
    }

  }
  else if (remote_mmode == CPPM_MASTER) {// === binaire PPM ===

#if 0// version binary
    // Build PKT_PPM payload
    PpmBinPayload pb{};
    pb.magic = 0xA5;
    pb.seq   = ppmS_seq++;

    for (int i = 0; i < 8; i++) {
      pb.ch_us[i] = (uint16_t)Cppm32.rxRead((uint8_t)(i + 1));
    }

    pb.crc = ppm_crc16_ccitt((const uint8_t*)&pb, sizeof(PpmBinPayload) - 2);

    const uint8_t* mac = linked_peer_set ? linked_peer_mac : bound_peer_mac;
    sendPkt(mac, PKT_PPM, &pb, sizeof(PpmBinPayload));

    if (dbg_bt) {
      Dbg.printf("[PPM-S->ESPNOW BIN] seq=%u ch1=%u ch2=%u\r\n",
                    pb.seq, pb.ch_us[0], pb.ch_us[1]);
    }
#endif

  }

}


// ------------------------------------------------------------
// Suspend/resume PPM SLAVE input decoding (used for OTA window)
// - We detach the interrupt to stop sampling PPM edges.
// - On resume we re-enable if we are still in CPPM_SLAVE mode.
// ------------------------------------------------------------
void PpmSlaveSuspendForOta(bool suspend) {
  if (!ppmS_inited) return;
  if (suspend) {
    if (!ppmSuspendedByOta) {
      Cppm32.endRx();
      ppmSuspendedByOta = true;
      if (dbg_bt) Dbg.println("[PPM-S] suspended for OTA");
    }
  } else {
    if (ppmSuspendedByOta) {
      // restart RX with current polarity setting
      const bool rising = cfg_ppm;
      Cppm32.beginRx((uint8_t)UART_RX, 8, rising, 3500, 800, 2200);
      ppmSuspendedByOta = false;
      if (dbg_bt) Dbg.println("[PPM-S] resumed after OTA");
    }
  }
}
