#if USE_LUA

#include "Lua_Serial_Tabs.h"
#include "Wifi_Tabs.h"
#include <WiFi.h>

// -----------------------------------------------------------------------------
// Dedicated line-based serial protocol for the future EdgeTX Lua/AUX link.
// For now the transport defaults to the existing debug/USB stream so the
// protocol can be validated without changing the rest of the firmware.
// -----------------------------------------------------------------------------

static String luaRxLine;
static uint32_t luaLastStatMs = 0;

void luaSerialSendLine(const String& s)
{
  Serial1.print(s);
  Serial1.print("\r\n");
}

const char* luaSerialLinkName()
{
  if (link_connected) return "CONNECTED";
  if (scanning)       return "CONNECTING";
  return "IDLE";
}

const char* luaSerialRoleName()
{
  switch (cfg_role) {
    case 0: return "MASTER";
    case 1: return "SLAVE";
    default: return "UNK";
  }
}

const char* luaSerialJoyModeName()
{
  return cfg_Sjoystick ? "ON" : "OFF";
}

void luaSerialForwardCommand(const String& cmd)
{
  // Minimal local handling for Lua serial commands.
  // Extend later if needed.
  String s = cmd;
  s.trim();
  if (!s.length()) return;

  if (s.equalsIgnoreCase("PING")) {
    luaSerialSendLine("PONG");
    return;
  }

  if (s.equalsIgnoreCase("GET")) {
    luaSerialSendLine(luaSerialStatusLine());
    return;
  }

  // Unknown command: keep protocol explicit
  luaSerialSendLine(String("ERR,UNKNOWN=") + s);
}

const char* luaSerialMasterModeName()
{
  switch (cfg_Mmode) {
    case 0: return "NONE";
    case 1: return "PPM";
    case 2: return "SBUS";
    case 3: return "BT";
    default: return "UNK";
  }
}

const char* luaSerialSlaveModeName()
{
  switch (cfg_Smode) {
    case 0: return "NONE";
    case 1: return "PPM";
    case 2: return "SBUS";
    case 3: return "BT";
    default: return "UNK";
  }
}

static int luaSerialWifiChannel()
{
  if (WiFi.getMode() == WIFI_OFF) return 0;
  return (int)WiFi.channel();
}

String luaSerialStatusLine()
{
  const char* link = luaSerialLinkName();

  String s = "STAT";
  s += ",ROLE=" + String(luaSerialRoleName());
  s += ",MMODE=" + String(luaSerialMasterModeName());
  s += ",SMODE=" + String(luaSerialSlaveModeName());
  s += ",JOY=" + String(luaSerialJoyModeName());
  s += ",LINK=" + String(link);

  if (strcmp(link, "CONNECTED") == 0) {
    s += ",RSSI=" + String((int)last_rssi_dbm);
  } else {
    s += ",RSSI=NA";
  }

  return s;
}

static String luaMapCmd(String line)
{
  line.trim();
  String u = line;
  u.toUpperCase();

  if (u == "GET") return "";
  if (u == "PING") return "";

  if (u == "ROLE,MASTER" || u == "SETROLE,MASTER") return "m";
  if (u == "ROLE,SLAVE"  || u == "SETROLE,SLAVE")  return "s";

  if (u.startsWith("MOUTPUT,")) {
    String v = line.substring(line.indexOf(',') + 1);
    v.trim();
    return String("moutput ") + v;
  }
  if (u.startsWith("SINPUT,")) {
    String v = line.substring(line.indexOf(',') + 1);
    v.trim();
    return String("sinput ") + v;
  }
  if (u.startsWith("PPMPULSE,")) {
    String v = line.substring(line.indexOf(',') + 1);
    v.trim();
    return String("ppmpulse ") + v;
  }
  if (u == "SCAN") return "scan";
  if (u == "SCAN,LINK") return "scan link";
  if (u == "DELLINK") return "dellink";
  if (u == "WIFI,AP") return "w ap";
  if (u == "WIFI,STA") return "w sta";
  if (u == "WIFI,OFF") return "w off";
  if (u == "CREDS") return "creds";
  if (u == "INFO") return "i";
  if (u == "DIAG") return "diag";
  if (u == "REBOOT") return "reboot";

  // CMD,<native console command>
  if (u.startsWith("CMD,")) {
    return line.substring(line.indexOf(',') + 1);
  }

  // Fallback: allow sending a native console command directly.
  return line;
}

static void luaHandleLine(String line)
{
  line.trim();
  if (!line.length()) return;

  String u = line;
  u.toUpperCase();

  if (u == "PING") {
    luaSerialSendLine("PONG");
    return;
  }

  if (u == "GET") {
    luaSerialSendLine(luaSerialStatusLine());
    return;
  }

  String mapped = luaMapCmd(line);
  if (mapped.length()) {
    luaSerialForwardCommand(mapped);
    luaSerialSendLine(String("ACK,CMD=") + mapped);
  }

  luaSerialSendLine(luaSerialStatusLine());
}

void luaSerialBegin()
{
  Serial1.begin(115200, SERIAL_8N1, LUA_RX, LUA_TX); // Use Serial1
  luaLastStatMs = millis();
}

void luaSerialTask()
{
  while (Serial1.available()) {
    char c = (char)Serial1.read();
    if (c == '\r') continue;
    if (c == '\n') {
      luaHandleLine(luaRxLine);
      luaRxLine = "";
      continue;
    }
    if (luaRxLine.length() < 160) luaRxLine += c;
  }

  if (millis() - luaLastStatMs >= 500) {
    luaLastStatMs = millis();
    luaSerialSendLine(luaSerialStatusLine());
  }
}
#endif