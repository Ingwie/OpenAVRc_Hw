#if USE_LUA
#pragma once
#include <Arduino.h>

// Simple line-based serial bridge intended for an EdgeTX Lua script.
// Current default transport uses the existing debug/USB stream so the protocol
// can be tested immediately. If you later move it to a dedicated AUX UART, only
// this module should need changes.

static constexpr int LUA_RX = 2;
static constexpr int LUA_TX = 3;

void luaSerialBegin();
void luaSerialTask();

// Implemented in the main sketch and reused here to avoid duplicating command logic.
void luaSerialForwardCommand(const String& cmd);
const char* luaSerialRoleName();
const char* luaSerialMasterModeName();
const char* luaSerialSlaveModeName();
const char* luaSerialJoyModeName();
const char* luaSerialLinkName();

#endif