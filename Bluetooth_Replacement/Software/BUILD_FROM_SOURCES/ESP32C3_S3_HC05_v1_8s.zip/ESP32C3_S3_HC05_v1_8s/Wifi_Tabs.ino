#include "Wifi_Tabs.h"

// XMODEM handshake translation (ATmega quirks)
// - RX mode (PC -> SD): ATmega polls with NAK but expects CRC packets -> translate NAK -> 'C' toward PC until SOH seen.
// - TX mode (SD -> PC): PC often polls with 'C' but ATmega expects NAK -> translate 'C' -> NAK toward ATmega until SOH seen.
static bool xmdm_wait_soh_from_pc = false;
static bool xmdm_wait_soh_from_at = false;
static uint32_t xmdm_arm_ms = 0;

static inline void xmdmArm(uint32_t now_ms) {
  xmdm_arm_ms = now_ms;
  xmdm_wait_soh_from_pc = true;   // assume next transfer could be PC->SD
  xmdm_wait_soh_from_at = true;   // or SD->PC, we allow both and stop when we see SOH
}
static inline bool xmdmArmed(uint32_t now_ms) {
  return (now_ms - xmdm_arm_ms) < 15000; // 15s window is enough for handshake
}

// ================= WiFi File Transfer (TCP <-> UART) =================
FtMode ft_mode = FT_OFF;
bool wifi_ft = false;

// ===== v1.6j: XMODEM detection + TF mute during FT =====
bool xferActive = false;
uint32_t xferLastMs = 0;
uint32_t xferForceUntilMs = 0; // force XMODEM active window after "cp xmdm"
uint32_t ftTcp2Uart = 0;
uint32_t ftUart2Tcp = 0;
uint32_t ftLastPrintMs = 0;
static uint32_t ftLastMasterPrintMs __attribute__((unused)) = 0;

static WiFiServer ftServer(3333);
static WiFiServer ctrlServer(3334);
static bool ctrl_enabled = false; // CTRL TCP server is only safe when WiFi/tcpip is initialized

static WiFiClient ctrlClient;

static WiFiClient ftClient;

String ft_sta_ssid;
String ft_sta_pass;

bool ftGetEsp32Ip(char* out, size_t outLen) {
  if (out == nullptr || outLen == 0) return false;
  out[0] = 0;
  if (WiFi.getMode() == WIFI_OFF) return false;

  IPAddress ip = (ft_mode == FT_AP) ? WiFi.softAPIP() : WiFi.localIP();
  if ((uint32_t)ip == 0) return false;

  snprintf(out, outLen, "%u.%u.%u.%u", ip[0], ip[1], ip[2], ip[3]);
  return true;
}

static const char* FT_AP_SSID = "OpenAVRc-FT";
static const char* FT_AP_PASS = "openavrc123";   // >= 8 chars

#if defined (USE_ESPNOW_WIDGET)
// ======================================================
// CH8 = link state + RSSI
// 1100us           : CONNECTING
// 1300us..2000us   : CONNECTED + RSSI
//   1300us -> -95 dBm
//   2000us -> -45 dBm
// Stored in sbusCh[] as raw SBUS 0..2047 values.
// ======================================================

static int getLinkStateCh8()
{
  return link_connected ? LINK_STATE_CONNECTED : LINK_STATE_CONNECTING;
}

static uint16_t usToSbusRaw(uint16_t us)
{
  if (us < 1000) us = 1000;
  if (us > 2000) us = 2000;

  uint32_t raw = ((uint32_t)(us - 1000) * 2048UL) / 1000UL;
  if (raw > 2047) raw = 2047;
  return (uint16_t)raw;
}

static uint16_t linkStateRssiToUs(uint8_t state, int rssi)
{
  if (state != LINK_STATE_CONNECTED) {
    return 1100;   // CONNECTING
  }

  if (rssi < -95) rssi = -95;
  if (rssi > -45) rssi = -45;

  // CONNECTED + RSSI in 1300..2000us
  return (uint16_t)(1300 + ((rssi + 95) * 700) / 50);
}

static uint16_t linkStateRssiToSbus(uint8_t state, int rssi)
{
  return usToSbusRaw(linkStateRssiToUs(state, rssi));
}
#endif

static void espnowStart();
static void espnowStop();

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void ftLoadCreds() {
  prefs.begin("hc05emu", true);
  ft_sta_ssid = prefs.getString("ft_ssid", "");
  ft_sta_pass = prefs.getString("ft_pass", "");
  prefs.end();
}
// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static void ftSaveCreds() {
  prefs.begin("hc05emu", false);
  prefs.putString("ft_ssid", ft_sta_ssid);
  prefs.putString("ft_pass", ft_sta_pass);
  prefs.end();
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
void ftPrintIp() {
  IPAddress ip = (ft_mode == FT_AP) ? WiFi.softAPIP() : WiFi.localIP();
  Dbg.print("[FT] IP: ");
  Dbg.println(ip);
  Dbg.println("[FT] TCP port: 3333");
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static bool wifiFtStartAP() {
  espnowStop();
  wifi_ft = true;

  WiFi.mode(WIFI_AP);
  WiFi.softAP(FT_AP_SSID, FT_AP_PASS);

  // Ensure CTRL server is available when WiFi is active (prevents lwIP/tcpip Invalid mbox asserts)
  if (!ctrl_enabled) {
    ctrlServer.begin();
    ctrlServer.setNoDelay(true);
    ctrl_enabled = true;
    Dbg.println("[CTRL] listening on port 3334");
  }

  ftServer.begin();
  ftServer.setNoDelay(true);

  ft_mode = FT_AP;
  Dbg.print("[FT] Mode: AP  SSID: ");
  Dbg.println(FT_AP_SSID);
  ftPrintIp();
  return true;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
bool wifiFtStartSTA(const String& ssid, const String& pass) {
  espnowStop();
  wifi_ft = true;

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid.c_str(), pass.c_str());

  Dbg.print("[FT] Mode: STA  joining SSID: ");
  Dbg.println(ssid);

  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 12000) {
    delay(250);
    Dbg.print('.');
  }
  Dbg.println();

  if (WiFi.status() != WL_CONNECTED) {
    Dbg.println("[FT] STA connect FAILED");
    wifi_ft = false;
    ft_mode = FT_OFF;
    WiFi.mode(WIFI_OFF);
    espnowStart();
    return false;
  }

  // Ensure CTRL server is available when WiFi is active (prevents lwIP/tcpip Invalid mbox asserts)
  if (!ctrl_enabled) {
    ctrlServer.begin();
    ctrlServer.setNoDelay(true);
    ctrl_enabled = true;
    Dbg.println("[CTRL] listening on port 3334");
  }

  ftServer.begin();
  ftServer.setNoDelay(true);

  ft_mode = FT_STA;
  ftPrintIp();
  return true;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
void wifiFtStop() {
  if (ftClient) ftClient.stop();
  ftServer.end();

  // Keep CTRL server always on
  // (It will keep running as long as WiFi interface stays up)

  if (ft_mode == FT_AP) {
    // Stop AP completely
    WiFi.softAPdisconnect(true);
    WiFi.mode(WIFI_OFF);
    wifi_ft = false;
    ft_mode = FT_OFF;
    espnowStart();
    Dbg.println("[FT] stopped");
    return;
  }

  if (ft_mode == FT_STA) {
    // Stop DATA but keep STA connected so CTRL remains reachable
    wifi_ft = false;
    ft_mode = FT_OFF;
    // Do NOT WiFi.mode(WIFI_OFF) here
    espnowStart(); // re-enable ESPNOW on current STA channel
    Dbg.println("[FT] stopped (STA kept for CTRL)");
    return;
  }

  // default
  WiFi.mode(WIFI_OFF);
  wifi_ft = false;
  ft_mode = FT_OFF;
  espnowStart();
  Dbg.println("[FT] stopped");
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static inline bool isXmodemByte(uint8_t b) {
  return (b==0x01 || b==0x02 || b==0x04 || b==0x06 || b==0x15 || b==(uint8_t)'C');
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
static inline void xferTouch(uint8_t b) {
  if (isXmodemByte(b)) { xferActive = true; xferLastMs = millis(); }
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
void wifiFtTask(HardwareSerial& uart) {
  if (!wifi_ft) return;

  if (!ftClient || !ftClient.connected()) {
    ftClient = ftServer.accept(); // deprecated warning ok
    if (ftClient) {
      ftClient.setNoDelay(true);
      // Dbg.println("[FT] client connected"); // disabled for raw bridge test
      // reset states per new connection
      ftTcp2Uart = 0; ftUart2Tcp = 0; ftLastPrintMs = millis();
      xferActive = false;
      tfDropLine = false;
      tfAtLineStart = true;
      tfState = 0;
    }
  }
  if (!ftClient || !ftClient.connected()) return;

// TCP -> UART
// Also sniff ASCII command lines to arm XMODEM right after "cp xmdm ..." (Desktop copy PC->SD).
static char ftCmdBuf[96];
static uint8_t ftCmdLen = 0;

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
while (ftClient.available()) {
  uint8_t b = (uint8_t)ftClient.read();
  uint32_t now_ms = millis();
  uint8_t out_b = b;
  // IMPORTANT:
  // Keep tcp->uart raw while forwarding textual uCli commands.
  // A literal 'C' may appear inside normal paths such as "VOICE"; converting it to 0x15
  // corrupts the command before the radio receives it.
  // So no 'C' -> NAK translation is done here.
  (void)now_ms;
  // If PC starts sending blocks, stop waiting for SOH from PC (upload in progress)
  if (b == 0x01 || b == 0x02) {
    xmdm_wait_soh_from_pc = false;
  }

  // Arm XMODEM window on command line (does NOT change forwarded bytes)
  if (!xferActive) {
    if (b == '\r' || b == '\n') {
      if (ftCmdLen > 0) {
        ftCmdBuf[ftCmdLen] = 0;
        // case-insensitive search for "cp xmdm", "xrecv " or "xsend "
        for (uint8_t i = 0; i + 5 < ftCmdLen; i++) {
          char c0 = ftCmdBuf[i+0] | 0x20;
          char c1 = ftCmdBuf[i+1] | 0x20;
          char c2 = ftCmdBuf[i+2] | 0x20;
          char c3 = ftCmdBuf[i+3] | 0x20;
          char c4 = ftCmdBuf[i+4] | 0x20;
          char c5 = ftCmdBuf[i+5] | 0x20;
          char c6 = (i + 6 < ftCmdLen) ? (ftCmdBuf[i+6] | 0x20) : 0;

          bool arm = false;
          const char* why = "";

          if (i + 6 < ftCmdLen && c0=='c' && c1=='p' && c2==' ' && c3=='x' && c4=='m' && c5=='d' && c6=='m') {
            arm = true;
            why = "cp xmdm";
          }
          else if (c0=='x' && c1=='r' && c2=='e' && c3=='c' && c4=='v' && c5==' ') {
            arm = true;
            why = "xrecv";
          }
          else if (c0=='x' && c1=='s' && c2=='e' && c3=='n' && c4=='d' && c5==' ') {
            arm = true;
            why = "xsend";
          }

          if (arm) {
            xferActive = true;
            xferLastMs = millis();
            xferForceUntilMs = xferLastMs + 15000; // keep filter disabled while XMODEM handshake starts
            // Dbg.printf("[FT] XMODEM armed (%s)\r\n", why); // disabled for raw bridge test
            xmdmArm(xferLastMs);
            break;
          }
        }
        ftCmdLen = 0;
      }
    } else if (ftCmdLen < sizeof(ftCmdBuf)-1) {
      // record only printable-ish bytes to avoid binary pollution
      if (b >= 0x20 && b <= 0x7E) ftCmdBuf[ftCmdLen++] = (char)b;
      else ftCmdLen = 0; // reset on other controls
    }
  }

  xferTouch(out_b);
  uart.write(out_b);
  ftTcp2Uart++;
}

  // UART -> TCP (mute 'tf ' lines when SLAVE and not in XMODEM transfer)
  while (uart.available()) {
    uint8_t b = (uint8_t)uart.read();
    uint32_t now_ms = millis();
    uint8_t out_b = b;
    // XMODEM handshake (ATmega -> PC).
    // OpenAVRc Desktop / shared xmodem expects raw NAK (0x15) here.
    // Do NOT translate NAK to 'C' on this project, otherwise Desktop never starts sending.
    if (xmdmArmed(now_ms) && xmdm_wait_soh_from_pc && b == 0x15) {
      out_b = 0x15;
    }
    // If ATmega starts sending blocks, stop waiting for SOH from ATmega
    if (b == 0x01 || b == 0x02) {
      xmdm_wait_soh_from_at = false;
    }

    xferTouch(out_b);

    // RAW bridge test: no filtering, no interpretation, every UART byte goes to TCP as-is.
    ftClient.write(&out_b, 1);
    ftUart2Tcp++;
  }

  // periodic stats on Serial only (never to TCP/UART), helps diagnose file copy issues
  if (xferActive) {
    uint32_t now = millis();
    if (now - ftLastPrintMs >= 1000) {
      ftLastPrintMs = now;
      // Dbg.printf("[FT] bytes tcp->uart=%u uart->tcp=%u\n", (unsigned)ftTcp2Uart, (unsigned)ftUart2Tcp); // disabled for raw bridge test
    }
  }
}

// ================= FT CTRL (TCP 3334) v1.6j =================
// Control channel is always listening. It can start/stop FT without USB typing.
// Commands (one per line, LF or CRLF):
//   FT:STA
//   FT:AP
//   FT:OFF
//   FT:STATUS
void ctrlTask()
{
  if (!ctrl_enabled) return; // avoid lwIP asserts when WiFi/tcpip is not started
  // accept client
  if (!ctrlClient || !ctrlClient.connected()) {
    ctrlClient = ctrlServer.accept();
    if (ctrlClient) {
      ctrlClient.setNoDelay(true);
      Dbg.println("[CTRL] client connected");
    }
  }
  if (!ctrlClient || !ctrlClient.connected()) return;

  // read line
  if (!ctrlClient.available()) return;
  String cmd = ctrlClient.readStringUntil('\n');
  cmd.trim();
  if (cmd.length() == 0) return;

  if (cmd == "FT:STATUS") {
    String mode = (ft_mode==FT_AP) ? "AP" : (ft_mode==FT_STA) ? "STA" : "OFF";
    IPAddress ip = (ft_mode==FT_AP) ? WiFi.softAPIP() : WiFi.localIP();
    ctrlClient.printf("OK FT=%s MODE=%s IP=%s PORT=3333\r\n", wifi_ft ? "ON":"OFF", mode.c_str(), ip.toString().c_str());
    return;
  }

  // Reboot command (useful when Desktop closes): ESP32 restarts and goes back to wait/advertise.
  // Accepted commands: REBOOT, RST, SYS:REBOOT
  if (cmd == "REBOOT" || cmd == "RST" || cmd == "SYS:REBOOT") {
    ctrlClient.println("OK REBOOT");
    ctrlClient.clear();
    delay(80);
    ESP.restart();
    return;
  }

  if (cmd == "FT:OFF") {
    Dbg.println("w off");
    if (wifi_ft) {
      wifiFtStop();          // modified below to keep STA if needed
    }
    ctrlClient.println("OK OFF");
    return;
  }

  if (cmd == "FT:STA") {
    Dbg.println("w sta");
    // Use saved STA creds
    if (ft_sta_ssid.length()==0 || ft_sta_pass.length()==0) {
      ctrlClient.println("ERR NO_CREDS");
      return;
    }
    if (wifi_ft) wifiFtStop();
    bool ok = wifiFtStartSTA(ft_sta_ssid, ft_sta_pass);
    ctrlClient.println(ok ? "OK STA" : "ERR STA");
    return;
  }

  if (cmd == "FT:AP") {
    Dbg.println("w ap");
    if (wifi_ft) wifiFtStop();
    bool ok = wifiFtStartAP();
    ctrlClient.println(ok ? "OK AP" : "ERR AP");
    return;
  }

  ctrlClient.println("ERR UNKNOWN");
}

// ---------------- setup helper (moved from setup()) ----------------
void wifiCtrlBootInit() {
  // v1.6j: bring up STA (if creds exist) so CTRL port is reachable without manual 'w sta'
  if (ft_sta_ssid.length() && ft_sta_pass.length()) {
    Dbg.println();
    Dbg.print("[CTRL] pre-connect STA SSID: ");
    Dbg.println(ft_sta_ssid);

    WiFi.mode(WIFI_STA);
    WiFi.begin(ft_sta_ssid.c_str(), ft_sta_pass.c_str());

    // IMPORTANT (ESP32-S3 + external UART console):
    // Serial1 writes can block if the USB-UART dongle/terminal can't drain fast enough.
    // Keep boot prints minimal and never spam dots in a tight loop.
    const uint32_t timeout_ms = 12000;
    uint32_t t0 = millis();
    uint32_t last_dot = 0;

    while (WiFi.status() != WL_CONNECTED && (millis() - t0) < timeout_ms) {
      delay(50); // give time to WiFi + background tasks
      // print a dot max 1Hz, and only if TX buffer has room (avoids blocking)
      if (millis() - last_dot >= 1000) {
        last_dot = millis();
        if (Dbg.availableForWrite() > 16) Dbg.print('.');
      }
    }
    if (Dbg.availableForWrite() > 2) Dbg.println();

    if (WiFi.status() == WL_CONNECTED) {
      String ip = WiFi.localIP().toString();
      if (Dbg.availableForWrite() > 32) {
        Dbg.print("[CTRL] STA IP: ");
        Dbg.println(ip);
      }
    } else {
      if (Dbg.availableForWrite() > 32)
        Dbg.println("[CTRL] STA not connected (CTRL may be unreachable until FT started)");
    }
  } else {
    if (Dbg.availableForWrite() > 32) Dbg.println("[CTRL] No STA creds saved");
  }

  if (WiFi.getMode() != WIFI_OFF) {
    ctrlServer.begin();
    ctrlServer.setNoDelay(true);
    ctrl_enabled = true;
    if (Dbg.availableForWrite() > 32)
      Dbg.println("[CTRL] listening on port 3334");
  } else {
    ctrl_enabled = false;
    if (Dbg.availableForWrite() > 32)
      Dbg.println("[CTRL] WiFi OFF - CTRL server disabled");
  }
}
