#include <ESP32_PPM.h>

/*
  ESP32_PPM 1.1.0 MERGED
  ----------------------
  Les commentaires [MERGE 1.1.0] identifient les corrections/ajouts faits
  lors de la fusion de la version corrigee precedente avec les ajouts
  ulterieurs du collegue.

  Principaux points conserves du collegue :
    - 16 voies PPM
    - setTxEnabled()
    - double buffer TX (channelValues -> outChannelValues)
    - correction du calcul du temps de synchro TX

  Principaux points ajoutes/securises pendant la fusion :
    - periode TX minimale coherente avec le nombre de voies
    - diagnostics RX rxIsrCount()/rxLastDtUs() conserves
    - detach propre de l'ancienne IRQ lors d'un nouveau beginRx()
    - lecture RX protegee par rxMux
    - sortie TX remise au repos hors section critique
*/

#define MAX_PPM_CHANNELS_COUNT ESP32_PPM_MAX_CHANNELS

static hw_timer_t *timer = NULL;
static portMUX_TYPE timerMux = portMUX_INITIALIZER_UNLOCKED;

ESP32_PPM Cppm32 = ESP32_PPM();

ESP32_PPM::ESP32_PPM(void)
{
}

// ---------------------------------------------------------------------
// TX (PPM OUT)
// ---------------------------------------------------------------------
static volatile bool txEnabled = true;
static uint8_t  _tx_pin = 255;
static uint8_t  _ChNb = 0;
static int      _PPMFrameLengthUS = DEFAULT_PPM_PERIOD_US;

static uint16_t _PpmModu = CPPM_GEN_NEG_MOD;
static uint16_t _PpmHeader_us = DEFAULT_PPM_HEADER_US;

static volatile uint8_t _Synchro = 0;

// Ajout du collegue : double buffer TX.
// channelValues contient les valeurs ecrites par l'application.
// outChannelValues est le snapshot fige utilise pendant toute la trame PPM.
static uint16_t outChannelValues[MAX_PPM_CHANNELS_COUNT];
static uint16_t channelValues[MAX_PPM_CHANNELS_COUNT];

enum ppmState_e
{
  PPM_STATE_PULSE,
  PPM_STATE_FILL,
  PPM_STATE_SYNC,
  PPM_STATE_FAILSAFE
};

// ---------------------------------------------------------------------
// RX (PPM IN)
// ---------------------------------------------------------------------
static portMUX_TYPE rxMux = portMUX_INITIALIZER_UNLOCKED;

static volatile uint8_t  _rx_pin         = 255;
static volatile uint8_t  _rx_chNb        = 0;
static volatile uint16_t _rx_syncMinUs   = 3500;
static volatile uint16_t _rx_minUs       = 800;
static volatile uint16_t _rx_maxUs       = 2200;

static volatile uint32_t _rx_lastEdgeUs  = 0;
static volatile uint8_t  _rx_idx         = 0;
static volatile uint8_t  _rx_frameAvail  = 0;

static volatile uint16_t _rx_work[MAX_PPM_CHANNELS_COUNT];
static uint16_t          _rx_stable[MAX_PPM_CHANNELS_COUNT];

static ESP32_PPM* s_rx_inst = nullptr;
// [MERGE 1.1.0] Diagnostics RX conserves depuis notre version corrigee.
// Ils permettent de verifier qu'une IRQ arrive et de connaitre le dernier dt.
static volatile uint32_t s_rx_isr_count = 0;
static volatile uint32_t s_rx_last_dt_us = 0;

// ---------------------------------------------------------------------
// RX ISR thunk
// ---------------------------------------------------------------------
void IRAM_ATTR rx_isr_thunk()
{
  if (s_rx_inst) s_rx_inst->_rx_isr();
}

// ---------------------------------------------------------------------
// RX ISR body
// ---------------------------------------------------------------------
void IRAM_ATTR ESP32_PPM::_rx_isr()
{
  s_rx_isr_count++;

  const uint32_t now = (uint32_t)micros();
  const uint32_t dt  = now - _rx_lastEdgeUs;
  s_rx_last_dt_us = dt;
  _rx_lastEdgeUs = now;

  // Sync gap => commit the completed frame.
  if (dt >= _rx_syncMinUs)
  {
    portENTER_CRITICAL_ISR(&rxMux);

    if (_rx_idx > 0)
    {
      uint8_t n = _rx_idx;
      if (n > _rx_chNb) n = _rx_chNb;

      for (uint8_t i = 0; i < n; i++)
        _rx_stable[i] = _rx_work[i];

      _rx_frameAvail = 1;
    }

    _rx_idx = 0;
    portEXIT_CRITICAL_ISR(&rxMux);
    return;
  }

  // Channel value = time between selected edges.
  uint16_t v = (dt > 0xFFFFu) ? 0xFFFFu : (uint16_t)dt;
  if (v < _rx_minUs) v = _rx_minUs;
  if (v > _rx_maxUs) v = _rx_maxUs;

  if (_rx_idx < _rx_chNb)
  {
    _rx_work[_rx_idx] = v;
    _rx_idx++;
  }
}

// ---------------------------------------------------------------------
// TX timer ISR
// ---------------------------------------------------------------------
void IRAM_ATTR onTimerISR()
{
  static volatile uint8_t ppmState = PPM_STATE_PULSE;
  static volatile uint8_t ppmChannelIndex = 0;
  static volatile int usedFrameLengthUS = 0;

  portENTER_CRITICAL_ISR(&timerMux);

  if (!txEnabled)
  {
    digitalWrite(_tx_pin, _PpmModu ? HIGH : LOW);
    ppmState = PPM_STATE_PULSE;
    ppmChannelIndex = 0;
    usedFrameLengthUS = 0;
    _Synchro = 0;

    // Keep a low-rate timer heartbeat so re-enabling starts automatically.
    timerAlarm(timer, 3000, true, 0);
    portEXIT_CRITICAL_ISR(&timerMux);
    return;
  }

  switch (ppmState)
  {
    case PPM_STATE_PULSE:
      digitalWrite(_tx_pin, !_PpmModu);
      timerAlarm(timer, _PpmHeader_us, true, 0);
      ppmState = PPM_STATE_FILL;
      break;

    case PPM_STATE_FILL:
    {
      digitalWrite(_tx_pin, _PpmModu);
      ppmState = PPM_STATE_PULSE;

      if (ppmChannelIndex >= _ChNb)
      {
        // Ajout du collegue : le dernier header est deja consomme par la
        // trame ; on le retire donc aussi du temps de synchro restant.
        int remaining = _PPMFrameLengthUS - usedFrameLengthUS - _PpmHeader_us;

        // Never generate a negative/underflowed sync gap.
        // If the requested frame period is too short (common with many
        // channels), the real frame is extended to preserve >= 3 ms sync.
        if (remaining < 3000) remaining = 3000;

        timerAlarm(timer, (uint32_t)remaining, true, 0);

        ppmChannelIndex = 0;
        usedFrameLengthUS = 0;

        // Ajout du collegue : publication groupee des nouvelles valeurs
        // uniquement entre deux trames. Une trame reste donc coherente.
        for (uint8_t i = 0; i < _ChNb; ++i)
          outChannelValues[i] = channelValues[i];

        _Synchro = 0xFF;
      }
      else
      {
        uint16_t currentChannelValue = outChannelValues[ppmChannelIndex];

        // Avoid subtraction underflow if a bad value/header is configured.
        if (currentChannelValue < (_PpmHeader_us + 100))
          currentChannelValue = _PpmHeader_us + 100;

        timerAlarm(timer,
                   (uint32_t)(currentChannelValue - _PpmHeader_us),
                   true,
                   0);
        usedFrameLengthUS += currentChannelValue;
        ppmChannelIndex++;
      }
      break;
    }

    default:
      ppmState = PPM_STATE_PULSE;
      break;
  }

  portEXIT_CRITICAL_ISR(&timerMux);
}

// ---------------------------------------------------------------------
// TX begin
// ---------------------------------------------------------------------
void ESP32_PPM::begin(bool PpmModu, uint8_t ChNb, uint16_t PpmPeriod_us,
                      uint16_t PpmHeader_us, uint8_t tx_pin)
{
  _tx_pin = tx_pin;

  if (ChNb < 1) ChNb = 1;
  if (ChNb > MAX_PPM_CHANNELS_COUNT) ChNb = MAX_PPM_CHANNELS_COUNT;
  _ChNb = ChNb;

  _PpmModu = (uint16_t)PpmModu;
  _PpmHeader_us = PpmHeader_us;
  _PPMFrameLengthUS = (int)PpmPeriod_us;

  // [MERGE 1.1.0] Avec 16 voies, 22.5 ms peuvent devenir insuffisantes.
  // On augmente automatiquement la periode interne minimale afin de garder
  // une periode fixe et au moins 3 ms de synchro, meme avec des voies a 2000 us.
  const int minFrameLengthUS = ((int)_ChNb * 2000) + (int)_PpmHeader_us + 3000;
  if (_PPMFrameLengthUS < minFrameLengthUS)
    _PPMFrameLengthUS = minFrameLengthUS;

  _Synchro = 0;
  txEnabled = true;

  for (uint8_t i = 0; i < MAX_PPM_CHANNELS_COUNT; i++)
  {
    outChannelValues[i] = 1500;
    channelValues[i] = 1500;
  }

  pinMode(_tx_pin, OUTPUT);
  digitalWrite(_tx_pin, _PpmModu ? HIGH : LOW);

  timer = timerBegin(1000000);              // 1 tick = 1 us
  timerAttachInterrupt(timer, &onTimerISR);
  timerAlarm(timer, 12000, true, 0);        // start
}

// ---------------------------------------------------------------------
// TX enable/disable
// Ajout du collegue : permet de couper/reprendre le PPM sans reconfigurer.
// ---------------------------------------------------------------------
void ESP32_PPM::setTxEnabled(bool enabled)
{
  portENTER_CRITICAL(&timerMux);
  txEnabled = enabled;
  if (!enabled)
    _Synchro = 0;
  portEXIT_CRITICAL(&timerMux);

  // [MERGE 1.1.0] La remise au niveau de repos est faite hors section
  // critique : digitalWrite() n'a pas besoin d'etre execute sous timerMux.
  if (!enabled && timer && _tx_pin != 255)
    digitalWrite(_tx_pin, _PpmModu ? HIGH : LOW);
}

// ---------------------------------------------------------------------
// TX set channel width
// ---------------------------------------------------------------------
void ESP32_PPM::width_us(uint8_t Ch, uint16_t width_us)
{
  if (Ch < 1 || Ch > MAX_PPM_CHANNELS_COUNT) return;
  const uint8_t idx = (uint8_t)(Ch - 1);
  const uint16_t v = (uint16_t)constrain(width_us, 1000, 2000);

  portENTER_CRITICAL(&timerMux);
  channelValues[idx] = v;
  // The ISR publishes the complete set at the next frame boundary.
  portEXIT_CRITICAL(&timerMux);
}

// ---------------------------------------------------------------------
// TX synchronization flag
// ---------------------------------------------------------------------
uint8_t ESP32_PPM::isSynchro(uint8_t SynchroClientIdx)
{
  uint8_t ret;

  portENTER_CRITICAL(&timerMux);
  ret = !!(_Synchro & RCUL_CLIENT_MASK(SynchroClientIdx));
  if (ret)
    _Synchro &= (uint8_t)~RCUL_CLIENT_MASK(SynchroClientIdx);
  portEXIT_CRITICAL(&timerMux);

  return ret;
}

// ---------------------------------------------------------------------
// RX begin
// ---------------------------------------------------------------------
void ESP32_PPM::beginRx(uint8_t rx_pin, uint8_t chNb, bool risingEdge,
                        uint16_t syncMinUs, uint16_t minUs, uint16_t maxUs)
{
  if (chNb < 1) chNb = 1;
  if (chNb > MAX_PPM_CHANNELS_COUNT) chNb = MAX_PPM_CHANNELS_COUNT;

  // [MERGE 1.1.0] beginRx() peut etre rappele sur une autre GPIO :
  // on detache explicitement l'ancienne interruption avant de reconfigurer.
  const uint8_t oldPin = _rx_pin;
  if (oldPin != 255)
    detachInterrupt(digitalPinToInterrupt(oldPin));

  portENTER_CRITICAL(&rxMux);

  _rx_pin       = rx_pin;
  _rx_chNb      = chNb;
  _rx_syncMinUs = syncMinUs;
  _rx_minUs     = minUs;
  _rx_maxUs     = maxUs;

  _rx_lastEdgeUs = (uint32_t)micros();
  _rx_idx        = 0;
  _rx_frameAvail = 0;

  for (uint8_t i = 0; i < MAX_PPM_CHANNELS_COUNT; i++)
  {
    _rx_work[i]   = 1500;
    _rx_stable[i] = 1500;
  }

  portEXIT_CRITICAL(&rxMux);

  s_rx_inst = this;

  pinMode(_rx_pin, INPUT);
  detachInterrupt(digitalPinToInterrupt(_rx_pin));
  attachInterrupt(digitalPinToInterrupt(_rx_pin),
                  rx_isr_thunk,
                  risingEdge ? RISING : FALLING);
}

// ---------------------------------------------------------------------
// RX end
// ---------------------------------------------------------------------
void ESP32_PPM::endRx()
{
  const uint8_t oldPin = _rx_pin;
  if (oldPin != 255)
    detachInterrupt(digitalPinToInterrupt(oldPin));

  portENTER_CRITICAL(&rxMux);
  _rx_pin = 255;
  _rx_chNb = 0;
  _rx_frameAvail = 0;
  _rx_idx = 0;
  portEXIT_CRITICAL(&rxMux);

  s_rx_inst = nullptr;
}

// ---------------------------------------------------------------------
// RX available
// ---------------------------------------------------------------------
uint8_t ESP32_PPM::rxAvailable()
{
  uint8_t r;
  portENTER_CRITICAL(&rxMux);
  r = _rx_frameAvail;
  _rx_frameAvail = 0;
  portEXIT_CRITICAL(&rxMux);
  return r;
}

// ---------------------------------------------------------------------
// RX read channel
// [MERGE 1.1.0] Lecture protegee pour eviter une concurrence avec l'ISR.
// ---------------------------------------------------------------------
uint16_t ESP32_PPM::rxRead(uint8_t ch)
{
  uint16_t v = 1500;

  portENTER_CRITICAL(&rxMux);
  if (ch >= 1 && ch <= _rx_chNb)
    v = _rx_stable[ch - 1];
  portEXIT_CRITICAL(&rxMux);

  return v;
}

uint8_t ESP32_PPM::rxChannels() const
{
  return _rx_chNb;
}

// [MERGE 1.1.0] Diagnostics RX de la version corrigee precedente.
uint32_t ESP32_PPM::rxIsrCount() const
{
  return (uint32_t)s_rx_isr_count;
}

uint32_t ESP32_PPM::rxLastDtUs() const
{
  return (uint32_t)s_rx_last_dt_us;
}

// ---------------------------------------------------------------------
// RCUL support
// ---------------------------------------------------------------------
uint8_t ESP32_PPM::RculIsSynchro(uint8_t ClientIdx)
{
  return isSynchro(ClientIdx);
}

void ESP32_PPM::RculSetWidth_us(uint16_t Width_us, uint8_t Ch)
{
  this->width_us(Ch, Width_us);
}

uint16_t ESP32_PPM::RculGetWidth_us(uint8_t Ch)
{
  (void)Ch;
  return 0;
}
