#pragma once

#include <Arduino.h>
#include <stdint.h>
#include <Rcul.h>

#define CPPM_GEN_POS_MOD                    HIGH
#define CPPM_GEN_NEG_MOD                    LOW

#define DEFAULT_PPM_PERIOD_US               22500
#define DEFAULT_PPM_HEADER_US               300

// Local merged version: supports PPM channels 1..16.
// Ajout du collegue, conserve dans la fusion : extension de 8 a 16 voies.
#define ESP32_PPM_MAX_CHANNELS              16

void rx_isr_thunk();

class ESP32_PPM : public Rcul
{
public:
  ESP32_PPM(void);

  // ----- PPM OUT (TX) -------------------------------------------------
  void begin(bool PpmModu = CPPM_GEN_NEG_MOD,
             uint8_t ChNb = 8,
             uint16_t PpmPeriod_us = DEFAULT_PPM_PERIOD_US,
             uint16_t PpmHeader_us = DEFAULT_PPM_HEADER_US,
             uint8_t tx_pin = 13);

  // Ajout du collegue : active/desactive le PPM OUT sans perdre la config.
  // Enable/disable the PPM output without destroying the configuration.
  // Disabled state keeps the pin at the configured idle polarity.
  void setTxEnabled(bool enabled);

  // ch = 1..configured channel count (values are constrained to 1000..2000 us)
  void width_us(uint8_t Ch, uint16_t width_us);

  // End-of-frame strobe for RCUL clients.
  uint8_t isSynchro(uint8_t SynchroClientIdx = 7);

  // ----- PPM IN (RX) --------------------------------------------------
  // risingEdge: true=RISING, false=FALLING
  // syncMinUs : dt >= syncMinUs starts a new frame (often 3000..5000 us)
  void beginRx(uint8_t rx_pin,
               uint8_t chNb = 8,
               bool risingEdge = true,
               uint16_t syncMinUs = 3500,
               uint16_t minUs = 800,
               uint16_t maxUs = 2200);

  void endRx();

  // Returns non-zero once for each completed received frame, then clears flag.
  uint8_t  rxAvailable();

  // ch = 1..N
  uint16_t rxRead(uint8_t ch);

  // [MERGE 1.1.0] Diagnostics RX conserves de notre version precedente.
  uint32_t rxIsrCount() const;
  uint32_t rxLastDtUs() const;

  uint8_t  rxChannels() const;

  // RCUL support
  virtual uint8_t  RculIsSynchro(uint8_t ClientIdx = RCUL_DEFAULT_CLIENT_IDX);
  virtual void     RculSetWidth_us(uint16_t Width_us, uint8_t Ch = 255);
  virtual uint16_t RculGetWidth_us(uint8_t Ch);

private:
  // [MERGE 1.1.0] L'ISR reste interne a la classe ; seul le thunk global
  // est autorise a l'appeler. Cela evite d'exposer _rx_isr() dans l'API.
  friend void rx_isr_thunk();
  void IRAM_ATTR _rx_isr();
};

extern ESP32_PPM Cppm32;
