# Lessons Learned

- GPIO direction helpers can reset peripheral output routing. On legacy ESP32,
  enabling output via gpio_set_direction reconnects SIG_GPIO_OUT_IDX. Preserve
  RMT routing with vendor input/output-enable operations that only change the
  enable bits, and verify actual loopback bytes after lifecycle changes.

- Treat questions about an unexpected backend as questions first. Confirm the
  selected implementation and cause before interpreting them as scope changes.
  A hardware-backed driver silently falling back deserves explicit investigation
  when the user expects that peripheral to be used.

- Verify the selected peripheral backend in the actual ELF before describing
  size parity as preserving hardware-driver quality. Older ESP32 SDKs can
  expose RMT geometry without `SOC_RMT_SUPPORTED`; silently selecting a
  generic fallback invalidates RMT-versus-RMT conclusions even when the same
  sketch and toolchain build successfully. Keep failed bring-up probes out
  of production and retain their evidence separately.

- Keep annotation enforcement in the existing `./lint` path. Before adding
  SDK provisioning, a CI matrix, or a cache subsystem, test whether a small
  source parser can reject missing annotations across inactive branches.
  User requested this simpler approach for FL_NO_EXCEPT on 2026-10-20.

- For WASM viewer fixes, run the compiled reproducer through the actual page
  and worker, then retain and inspect before/after screenshots. Module-level
  WebGL pixel tests do not verify app startup, asset staging or the worker
  integration. Distinguish phone viewport emulation from a physical phone test.

- A prerequisite abstraction is not progress toward a niche feature when no
  production path uses it. PR #4534 added hundreds of lines of optional
  presentation-timing API, but no built-in driver produced measured events and
  no dither consumer used them, so it could not improve emitted light or meet
  the issue's XYZ criterion. Before opening a feature PR, prove the smallest
  end-to-end behavior, describe its concrete benefit and relevant costs, and
  only split out an API seam when a named near-term real consumer (including
  downstream use) and separate-landing need are clear.

- Host-tool selection and host-tool import context are separate concerns. When
  Meson executes repository Python helpers for an external consumer, provide
  the repository root through the command environment so package imports do not
  accidentally depend on the caller's working directory.

<!-- Add lessons from corrections and discoveries here -->

- A binary-size PR needs same-configuration before/after symbol evidence, not
  only aggregate firmware bytes. Preserve both reports and explain which
  symbols disappeared, shrank, grew, or moved before claiming a bloat win.

- Before adding a local bounded container made from an array plus a count,
  check whether `fl::vector_fixed` already implements the needed shape. Its
  `push_back()` silently ignores overflow, so use the bool-returning
  `insert(end(), value)` when capacity failure must be observable; prefer the
  existing container and teach CodeRabbit to spot future one-off duplicates.

- Before diagnosing missing functionality in a local integration checkout,
  fetch and compare it with its upstream branch; a stale checkout can omit the
  entire subsystem under test. For Meson host tools in a cross-build, branch on
  `build_machine.system()`, never `host_machine.system()`.

- QEMU CI must use fbuild's native `test-emu` runner as the owner of the
  build, flash-image preparation, and emulation lifecycle. Do not repair or
  extend legacy-backend merged-bin artifact plumbing now that the legacy
  backend is gone; retain only the minimum example staging fbuild requires.

- QEMU success markers must match the emulator's actual hardware model. For
  unmodeled LED peripherals, assert a real build, boot, and driver/channel
  registration and label it as such; reserve transmit-completion assertions
  for hardware-in-the-loop tests.

- Inspect the actual WASM compiler manifest before assuming an npm dependency: it
  currently pins the `@fastled/gfx` GitHub Release tarball by exact URL.

- For the current HydroPack prototype, prioritize a readable ordinary-LED
  approximation of the < | > layout over further EL-shape fidelity.

- HydroPack's two sensitivity levels are visual layers, not separate status
  dots: use the sensitive analyzer for the center and the loud analyzer for
  the triangles so strong bass appears to launch outward.

- For HydroPack's audience-safe behavior, use FastLED's INMP441-calibrated
  SPL meter with its adaptive bass-beat detector rather than a custom
  sound-floor histogram or a separate tempo lock.

- For a responsive music-only visual, require five seconds of recurring
  qualifying beat evidence plus a low-ZCF check to arm a temporary
  music-present state. Never use a fixed tempo-consistency or animation lock.

- For browser media, derive the 0-1 music confidence from Vibe's normalized
  bass rise above its short-term average. The generic raw spectral-flux beat
  detector can remain below its fixed threshold despite healthy decoded audio.

- A WASM-only per-frame telemetry toggle can expose raw Beat and Tempo
  confidence alongside Vibe levels without adding a physical output pixel to
  the HydroPack fixture.

- When consuming a tool's stderr through `RunningProcess.run`, request
  `stderr=PIPE` explicitly and test the real output format. Default capture
  combines streams and leaves `result.stderr` unset.

- GitHub-hosted Azure Linux VMs can return `<not supported>` for every PMU
  event even after relaxing `perf_event_paranoid`. For a reproducible hosted
  gate, record pinned N=30 compiler cycle-counter medians and pair them with
  explicitly labeled deterministic Callgrind instruction/branch simulation;
  never relabel simulated data as hardware `perf` output.

- LLVM operation ledgers must follow product values through O0 casts and spill
  slots before classifying accumulations; direct SSA-use matching changes
  across compiler versions even when the source operations are identical.

- Target codegen audits must keep production optimization flags. If a static
  kernel is fully inlined and its symbol disappears, retain it with a narrow
  no-inline audit caller and measure the optimized kernel body, rather than
  disabling inlining for the entire translation unit.
- When a regression test mutates a primary metric in a schema with validated
  derived metrics, recompute the derived fields first so the test reaches the
  intended regression gate instead of failing schema validation.
- GitHub-hosted runner labels can rotate among materially different CPU
  models. Host performance gates need separate environment-keyed baselines;
  a single baseline for an OS label either flakes or compares unlike machines.
- A multiply identity that avoids materialising the low half of the product is
  only a win where the low half costs something. On a target whose single
  instruction yields all 64 bits it is pure overhead: applying
  `mp3d_mulshift_k` unguarded cost +7.5% in `L3_dct3_9` and +0.95% across the
  fixed-point decode on the x86-64 audit host, while buying 0.43% on an
  ESP32-C6. Guard such lowerings on register width and let the portable form
  serve everyone else, exactly as `fl::math::mul_shift_round32` already does.
- An `exact operation ledger changed` failure is a question, not a chore.
  Re-baselining it from CI's artifact is only correct once the direction of
  every moved figure has been explained; here the ledger and the per-function
  Callgrind budget were both reporting a real host regression, and a
  re-baseline would have recorded it as the new normal. Read the callgrind
  deltas in the artifact before rewriting the file.
- A harness `PASS` means what the harness checked, not what its name implies.
  `runParallelTest` skips RX loopback validation for the RP `PIO0`+`PIO1` pair
  (`AutoResearchRemoteRunParallelTest.cpp:308`, `is_rp_pio_pair`), so its PASS
  proves channel creation and a clean shared `show()` — not byte-correct output.
  It was quoted as "decisive loopback evidence" on #3899 and had to be retracted.
  Read what a green result asserts before citing it as evidence for a checklist
  item.
- On a HIL bench, most "device faults" are host-side. Four in one session on
  RP2350W: a 20 ms RPC timeout that read as a hung board (`--timeout` is a
  whole-run deadline for `--net-peer`, not a per-phase one); `deployed firmware
  schema does not contain rpSpiLoopback` on a board that exposes it (a failed
  `rpc.discover` collapsed to `None`); `zero_capture` on SPI that was an
  unfitted jumper; and `serial driver may be wedged` that was a dead fbuild
  daemon. Check the transport and the harness before concluding anything about
  silicon.
- A second `RpcBench` on a port another client already holds connects without
  error and is then inert — every call returns `None`, while the first client
  keeps working (FastLED#4207). Because the failure is silent, callers read the
  `None` as a statement about the device. Any code spawning a device script
  against a port the harness still holds must release it first.
- When an error path swallows its own signal, stop reasoning and instrument.
  Four successive hypotheses for one `None` (short timeout, `call_flat` frame
  shape, payload size, then the real cause) were each refuted by the next run,
  because `call_flat` collapses every exception to `None`. A twenty-line
  two-client repro settled it immediately and was available the whole time.
- Verify a fix landed on the hardware you think you flashed. A failed build
  followed by a successful RPC answers from resident firmware, so "after"
  numbers can be byte-identical to "before" and look like a null result. Check
  for a field only the new build emits.
- Exhaustive equivalence checks written in Python cannot see C overflow. A
  32-bit fast path for `cycles_from_ns` compared equal to the 64-bit oracle
  across every sampled input while silently overflowing `u32` above 215 MHz;
  only a separate explicit overflow counter caught it. Assert the width bound,
  not just the values.
- Peer-network autoresearch reflashes the fixture as well as the DUT. The
  RP2350W has a watchdog/bootloader escape armed (#4167/#4172); the ESP32-C6
  has none. A wedged C6 CDC gives `EBUSY` with no holding process, and every
  recovery handle (usbfs, `authorized`, `unbind`, `remove`) is root-only — so
  an unattended bench has no way back. Assess the fixture's recovery path, not
  just the DUT's, before running `--net-peer --ota`.
- Building the non-W `rp2350` target changes the board's USB product string, so
  `/dev/serial/by-id` renames from `..._Pico_2W_<serial>` to `..._Pico_2_<serial>`.
  Anything addressing the board by the old by-id path silently stops resolving
  and presents as a missing board. The serial is stable across both variants,
  which is why fbuild's `SER=<serial>` selector is the robust way to address it.
- A single artifact is not a sample when the property depends on cache-hit
  status. I cleared the "missing exec bit" hypothesis (#4205) after checking
  `tests/runner` alone and finding it executable — it had simply been freshly
  linked rather than served from cache that run. A later survey found 4 of 4
  ELF executables in the build dir lacking `+x`. Enumerate the whole class
  before ruling out a permissions or attribute defect.
- Finding a real bug in the right subsystem is not the same as finding the
  cause. `mtime_stabilizer.py` genuinely matched 0 of 383 outputs on Linux
  (it globbed only `*.dll`), and fixing it was correct — but the #4212 stale
  failures recurred, because the stabilizer compares outputs against *input
  file* mtimes while the #3011 guard compares against *build start*. Different
  comparison, so satisfying one says nothing about the other. Re-run and
  confirm the symptom actually clears before claiming causation.
- When a build system reports an opaque wrapper error, force the underlying
  exception out before theorising. `ERROR: Unhandled python OSError ... return
  code 13` named neither the file nor the errno; `MESON_FORCE_BACKTRACE=1`
  turned it into `PermissionError: [Errno 13] Permission denied: <path>` in
  one step. The "13" was the errno, not an exit code — the message actively
  misdirects.
- Check what a manifest actually is before calling it truncated. `help`
  returning 36 of `rpc.discover`'s 72 methods looked like a response-size cap;
  it is a hand-maintained `kHelpEntries[]` table in
  `AutoResearchRemotePinMethods.cpp`. A new RPC method must be added there too
  or `--rpc-smoke` fails on it.
- On RP, `ClocklessController` acquires PIO/DMA/pin resources in `init()` and
  every `release*` call in `clockless_rp_pio.h` is an error-path rollback.
  Before #4214 there was no destructor, so successful controllers leaked their
  state machine, program space, DMA channel, pin claim, and `dma_buf` — and
  left `dma_chan_waits[]` pointing at a destroyed `mWait` for the shared ISR.
  When testing resource arbitration, always include a control leg that claims
  and then releases; the starved leg alone cannot see a leak.
- Read the command output before writing the sentence that summarises it. Three
  times in one session I asserted a verification result I had not looked at: I
  quoted `_EXIT=` values that were measuring `tail` rather than the command
  (without `pipefail`, `cmd | tail; echo $?` reports the tail's status, not the
  command's; shells with `set -o pipefail` report the pipeline's, so the
  reading depends on shell configuration), and twice wrote "`bash test --cpp`
  is clean"/"still fails" from the previous run's behaviour rather than the run
  just executed — once in each direction. None changed a conclusion, because
  the logs were read afterward, but each put a false claim in a PR that then
  needed a correction comment. Capture the result, read it, then write.
- A test that asserts only an exit code can pass for a completely unrelated
  reason. My `--legacy` chipset-rejection test returned 1 from the
  Teensy/root-ini escape-hatch check and never reached the guard it was
  written for; my `--net-peer` summariser test checked call counts and would
  have passed with the summariser deleted. Assert on the *evidence* — the
  message text, the printed rows — and prove the assertion discriminates by
  temporarily disabling the code under test.
- An exhaustive check is only as good as its input space. `cycles_from_ns()`
  was verified against a 64-bit oracle across 16 clock rates and still shipped
  a bug for clocks that are not whole kHz, because all 16 rates were multiples
  of 1000 and the truncation had nothing to truncate. The same PR's earlier
  overflow bug survived a Python equivalence sweep because bignums never
  overflow. When a check passes, ask what shape of input it structurally
  cannot contain.
- `git pull --rebase` is not a safe refresh for a branch that carries a merge.
  Rebasing #4214 linearised it and silently dropped the #4215 merge commit
  along with two files; only a `FileNotFoundError` on the next edit revealed
  it. Reset to the remote to recover. For stacked or merge-carrying branches,
  merge master in or leave the branch alone.
- Eliminating the obvious candidate does not make the next one proven. I
  reported "transient PCB exhaustion" because `SOF_REUSEADDR` ruled out
  TIME_WAIT, and named `-Os` as the cause of a 12x slowdown because alignment
  and `FL_IRAM` were refuted — both wrong, the second demonstrably so once the
  disassembly was read. State what the evidence supports and name the
  unexplained remainder.
- On a fixture with time-varying flakiness, a cross-build comparison proves
  almost nothing; isolate the change *within one build* instead. Four times on
  the RP2350W peer link a small sample looked like causation: a `stopNet`
  settle delay (1 join -> 4), a raised WiFi join budget (2 master failures vs
  3 clean branch runs), and client-side HTTP deadlines (master 0/2 vs branch
  3/3, with master failing on the exact symptom the fix addressed). Reverting
  only the change in question, on the same branch, produced evidence against
  all three — the runs passed anyway. Two runs per arm is not proof of a
  negative on a link this variable; it is enough to stop crediting the change,
  not enough to rule it out. The same technique caught a genuine regression I had
  introduced (a server-side service-gap credit produced 408s that master never
  showed, across three formulations), so it discriminates in both directions.
  This link's behaviour varies over hours; two or three runs per arm cannot
  see through that.
- After resolving a conflict in a test file, check the **collection** count, not
  the pass count. Resolving a merge in `test_autoresearch_phases.py` left two
  tests nested inside another test function, where pytest never collects them.
  The suite reported `180 passed` before and after the fix — the missing tests
  were absent from the count rather than failing, so the green run and the
  plausible number hid it. `pytest --collect-only -q` showed 178 vs 180, and
  grepping the collected names showed 0 vs 2. A pass count cannot distinguish
  "passing" from "not present"; a collection count can.
- Do not reimplement production logic to investigate a bug caused by
  reimplemented production logic. The AutoResearch UART decoder hardcoded one
  chipset's quantised wire timing, so 400 kHz frames decoded every symbol
  wrongly. To test the fix I derived the timing *by hand*, got 1 of 40 LEDs
  still wrong, called the remainder a "missing final byte" capture defect, and
  spent an iteration hunting it. There was no such defect: my derivation had
  omitted the minimum-symbol-separation bump that `fitUartWave()` applies
  (`kMinSymbolSeparationNs`), so the decode windows were subtly wrong and
  clipped one LED. Calling the real function decoded the frame completely. The
  encoder's own comment had named the hazard — *"Shared by buildWave10Lut()
  and canRepresentTiming() so the LUT that gets built is always judged by the
  same rules that admitted it"* — and I reproduced it by hand while
  investigating it. Before positing a new defect to explain a residual,
  suspect the approximation you introduced to look for it.
- A long hardware campaign and a `git checkout` share one working tree. I
  started a five-run `--net-peer` campaign on the branch carrying the
  `netServerStats` probe, then checked out a different branch in the same
  repository to resolve an unrelated PR conflict. The first run had already
  died on the conflict markers still in `ci/autoresearch/net.py`; the
  remaining runs would have built and deployed firmware from a branch that
  does not contain the probe the campaign existed to exercise. Nothing was
  wedged, but the evidence would have been silently worthless. Background
  device work pins the tree: do concurrent branch work in a `git worktree`,
  and have the loop assert its own branch before each run so a stray checkout
  aborts the campaign instead of quietly changing what it measures.
- Parallel worktrees are not free, and the thing they kill is the unattended
  run. Three `git worktree`s, each with its own `.build` tree and its own
  `fbuild-daemon`, plus a device campaign and a platform compile, drove the
  host out of memory; the harness killed the campaign mid-run. Nothing was
  wedged and both boards re-enumerated healthy, but an hour of unattended
  collection was lost, and the kill looked at first glance like a test
  failure rather than an environmental one. Worktrees are the right answer to
  the shared-tree hazard above, so the fix is not to stop using them: retire
  each one as soon as its work is pushed, kill the daemon that belongs to it,
  and have long unattended loops check free memory before each iteration and
  stop cleanly rather than be killed part-way. Read the exit reason before
  concluding anything about the code. See [[shared-tree-hazard]].
- A tty node path is not a device identity, and the failure it produces lies.
  Four unattended runs died on `Could not open /dev/ttyACM2, the port is busy
  or doesn't exist`, which reads like a wedged board. Nothing was wedged: the
  ESP32-C6 had re-enumerated and the kernel gave it `/dev/ttyACM1` instead.
  I had hardcoded both node paths because `--net-peer` requires them and
  neither `bash autoresearch` nor `fbuild deploy` accepts a USB serial, and
  they had been stable for 241 cycles before they were not. The benign
  outcome is a failed deploy; the dangerous one is two boards swapping
  numbers, which turns a hardcoded path into flashing the wrong board and
  breaks the deploy-isolation property #3832 requires. Resolve the USB serial
  to a node immediately before each use and abort cleanly when the serial is
  absent, rather than deploying to whoever inherited the path. Identity comes
  from something stable, never from enumeration order -- the same rule the
  USB VID/PID registry exists to enforce. See [[worktree-memory-exhaustion]].
- When a whole campaign inverts -- 1-in-6 runs failing became 5-in-6 -- suspect
  the harness before the device. I had just raised an HTTP deadline and was
  ready to read the result as "the peer got worse under the longer budget".
  It was the renumbering above: run 1 was real, runs 3-6 never reached a
  single network cycle because the deploy could not open a port. A result that
  large and that sudden is nearly always the measurement, not the thing
  measured; check how many cycles actually executed before interpreting a
  rate.
- A dual-device campaign builds *two* firmware images, and pre-building only
  one leaves the spike in place. Three unattended campaigns were killed for
  host memory, every one during run 1 of a freshly created worktree. I had
  pre-compiled the RP image each time and concluded the builds were cached;
  `--net-peer` also builds the ESP32-C6 peer image, which took 2m18s from
  cold and was the actual spike. Later runs in every campaign were fine
  because run 1 had warmed the cache. Two consequences: pre-build every
  target a run will touch, not just the one under test; and stop creating a
  worktree per experiment, because each new one pays for two full toolchain
  builds when only a few lines differ -- reuse one bench worktree and change
  what is merged into it. Note a memory guard that samples before each run
  cannot see a spike that happens inside a run; smaller batches limit the
  loss instead. See [[worktree-memory-exhaustion]].
- A board missing from the USB bus is not necessarily wedged. Immediately
  after a killed campaign the RP2350W was absent entirely -- the wedge
  signature -- and it was in BOOTSEL as `2e8a:000f RP2350 Boot`, the normal
  transient while fbuild flashes it, returning as `2e8a:f00f` within about
  four seconds. Checking only for the application VID/PID and stopping there
  would have reported a wedged board and halted the loop for nothing. Scan
  the whole vendor family and wait for re-enumeration before calling a board
  lost.
- "Are stray processes accumulating?" and "have my long-lived daemons grown?"
  are different questions, and I only asked the first one for nine kills. Nine
  unattended campaigns died to host memory pressure. Each time I checked for
  orphaned `autoresearch`/`esptool` processes, found none, saw `MemAvailable`
  looking healthy, and concluded the pressure was external. It was not:
  `zccache-daemon` had grown to 4.4 GB and `fbuild-daemon` to 3.5 GB, ~8 GB of
  reclaimable cache sitting idle between runs. Killing both -- they respawn on
  demand -- moved `MemAvailable` from 82 GB to 91 GB, and the run that had
  failed nine times completed immediately. The 9 GB recovered exceeds the
  8 GB those two processes reported as RSS; page cache and shared mappings
  released alongside them make up the difference, so treat the two numbers as
  separate measurements rather than one. Every mitigation applied before
  that was real but aimed elsewhere: pre-building images removed the build
  spike, `--skip-lint` removed the lint phase, a memory floor gated each run,
  smaller batches limited the loss. None of them touched a daemon idling on
  4 GB. When a resource problem survives several plausible fixes, enumerate
  what is actually holding the resource before absorbing the failure as
  environmental. See [[worktree-memory-exhaustion]].
- A merged PR does not mean your last commits are in. #4233 was merged from an
  earlier commit while three later pushes sat on the branch; the branch still
  existed, the PR read MERGED, and none of that work was on master. I caught it
  only because I grepped the merged file for each fix instead of trusting the
  merge status -- `grep -c` for one of the fixes printed `0`, i.e. it matched
  zero times, which is not the same signal as grep's exit status. Verify
  content, not state, and
  when commits are stranded rebuild them onto current master as a fresh PR
  rather than reopening the merged one.
- The last line of a log and the code path that produced it can disagree, and
  the code path wins. A peer OTA run ended with `C6 artifact server failed`,
  and I read the tail as "the transfer never ran". Reading `ota.py` in order
  showed the opposite: reaching that raise requires the whole
  `writeOtaArtifact` chunk loop to have returned success and
  `finishOtaArtifact` to have matched the SHA-256, because either one failing
  raises earlier and differently. The transfer had in fact completed and
  verified 1,030,348 bytes. An error message names where execution stopped,
  which is also a statement that everything before it passed -- for a
  sequential flow that is free evidence, and I nearly discarded it by reading
  bottom-up. Before concluding a stage did not run, find the raise that would
  have fired if it had failed.
- When two runs of the same thing disagree, subtract before calling either
  one flaky. Run 1 of a peer OTA transferred all 1,030,348 bytes; run 2 died
  at byte 200,448. The fixture partition is 0x130000 (1,245,184 B) and
  `finishOtaArtifact` deletes the previous artifact only after the new one
  verifies, so run 2 needed room for two copies:
  1,245,184 - 1,030,348 = 214,836 B of headroom against a failure at 200,448 B,
  the difference being LittleFS block overhead. One cause explained both runs
  exactly. Arithmetic that lands within a few percent is a root cause;
  "probably flaky" is what I would have written without doing it.
- A stale branch head is not evidence that nobody is working on it. I
  diagnosed the seven red builds on #4311, posted the cause, then implemented
  the fix anyway because the head had not moved in 21 minutes. It was another
  session's active branch; they pushed the same fix while I was testing and my
  push was rejected. My existing lesson said to fetch before starting, and I
  did fetch -- the gap was treating "no commits for N minutes" as "abandoned".
  On a branch this session does not own, the diagnosis comment is the whole
  contribution; implementing on top of it is duplicated work with a merge
  conflict attached. See [[fetch-before-starting-not-before-pushing]].
- Grep patterns used as completion signals must not match the configuration
  that announces the work. I polled a log for `TEST_COMPLETED` to detect the
  end of a 20-minute run and got a hit within 30 seconds -- from the startup
  banner `stop on 'TEST_COMPLETED_EXIT_(OK|ERROR)'`, which is the harness
  printing what it will look for. I reported the run finished while it had 18
  minutes left. Anchor a completion pattern on text only the result can
  produce (`AUTORESEARCH PASSED`, `autoresearch failed`), and check what the
  first hundred lines of the log already contain before trusting a match.
- On a machine with no swap, a "low memory" alarm can mean a full page cache
  rather than exhaustion -- read `MemFree` and `MemAvailable` separately
  before acting on it. Three long device runs were killed for low memory
  while a 20-minute sampler I had running showed `MemAvailable` never
  dropping below 77 GB of 131 GB. The real reading was `MemFree: 1.4 GB`
  against `Cached: 59.6 GB` with `SwapTotal: 0`: build I/O had filled the
  page cache, so anything thresholding on `MemFree` saw 1.4 GB while
  `MemAvailable`, which counts reclaimable cache, correctly reported 80 GB.
  This corrects my earlier conclusion that daemon growth was the cause.
  Killing `fbuild-daemon` and `zccache-daemon` appeared to fix it once
  because it briefly returned pages to `MemFree`, then stopped working,
  because the daemons were never it -- `fbuild-daemon` was back at 5.26 GB
  within ten minutes and the run died anyway. Page cache is reclaimable and
  cannot be dropped from userspace without root, so the honest responses are
  to retry, shorten the exposed run, or fix the threshold -- not to reap
  processes and call it fixed.
- Do not hunt a deterministic cause for an intermittent failure until you have
  established it is deterministic. `No response with ID 1 within 20.0s` failed
  two peer-OTA runs in a row, which I took as proof it was not flaky, and I
  then produced four wrong causes in sequence -- a first-boot filesystem
  format, a 2 MB filesystem slowing boot, a short `boot_wait`, and a stale
  CDC on the primary. Each was built on a two-sample correlation with my own
  most recent change. The next run passed the same point untouched: it is a
  race on the companion's USB-CDC re-enumeration, which
  `_connect_peer_with_retry`'s docstring had already recorded across four
  prior captures, naming the C6 and saying a fixed `boot_wait` cannot cover
  it. Two consecutive failures of a race are unremarkable. Read the existing
  docstrings on the failing path before forming a theory, and prefer adding
  attribution over adding a hypothesis when the error names neither the
  component nor the operation.
- `git fetch` before starting work, not before pushing. I root-caused the
  `s16x16x4` 15x penalty in #4216 (rolled 4-lane loops defeating
  scalar-replacement), fixed it, and measured it on hardware -- and only when
  the cherry-pick conflicted did I discover #4299 had landed the same root
  cause and a better fix (`FL_SIMD_LANE4`, which also covers `simd_riscv.hpp`)
  nine hours earlier. My local `master` was clean but stale, so every check I
  ran agreed with me. This is the third time this session I have rebuilt work
  the remote already had. The cheap guard is not "check before pushing" -- by
  then the work exists -- it is running this before reading the code, with the
  paths you are about to touch spelled out:

  ```bash
  git fetch origin
  git log --oneline HEAD..origin/master -- src/platforms/shared/simd_noop.hpp
  ```

  `HEAD..origin/master` lists what upstream has that you do not, and the
  path filter narrows it to the files in question -- in the #4216 case that
  one command would have printed the commit for #4299 and saved the whole
  detour. Name real paths rather than a placeholder: without them the log is
  the full upstream delta and you will skim past the one line that matters. The measurement was
  still worth posting to the issue, because #4299 argued from instruction
  counts and I had before/after on real silicon; salvage the part that is
  genuinely yours rather than opening a duplicate PR.
- A diagnostic field named after the subsystem you are testing may be sourced
  from the other side of the loopback. Chasing the RP PIO capture ceiling in
  #4371 I used `rpPioWordCount` as evidence about the RX DMA and wrote on the
  issue that "the DMA is not the constraint", because the field read exactly
  `8 * wire_bytes` in every row, passing and failing alike. It comes from
  `fl::BusTraits<fl::Bus::FLEX_IO, N>::instance().lastWordCount()` -- the
  **transmitter**. Eight words per byte is one TX word per bit, which is
  precisely why it tracked byte count so cleanly and said nothing at all about
  capture. The tell was there in the data: a number that is an exact linear
  function of the input, with no variation between the cases you are trying to
  tell apart, is usually not measuring the thing that separates them. Grep the
  field back to where the response sets it before drawing a conclusion from it.
  The pass/fail boundaries themselves were unaffected, which is the reason the
  rest of that analysis survived the correction -- prefer evidence from the
  behaviour you are measuring over evidence from a field that claims to explain
  it.
- Two constraints can hide each other completely. The same capture had an edge
  pool bounding fast chipsets at 300 wire bytes and a fixed sample-time budget
  bounding slow ones at 3.8 ms, and each ceiling is unreachable in the other's
  regime -- so every 800 kHz part reported 100 LEDs, the one 400 kHz part
  reported 63, and no single model fit. Separating them took constructing a
  case where one variable was held equal: 192 wire bytes and 3072 phases passes
  at 800 kHz and fails at 400 kHz. When measurements refuse to collapse into
  one model, stop fitting curves and look for the input you have never varied
  independently.
- Do not copy `id-token: write` into build/test workflows merely because they
  upload artifacts or cache outputs. OIDC is for obtaining a federated identity,
  not ordinary artifact upload. Before granting it, identify the exact step
  that requests the token, including any composite action. When removing an
  unused grant from a reusable workflow, update callers and callees together
  and test the permission contract so an old callee declaration cannot turn a
  least-privilege caller into a startup failure.
- Do not extrapolate a Linux ELF linker benchmark into macOS or Windows
  policy. A tool that has releases for multiple hosts may still route those
  hosts through different engines, and Windows GNU can depend on special
  linker/DLL injection. Keep the override scoped to the host the user chose,
  preserve the other platforms' established linkers, and distinguish raw-link
  speed from end-to-end job speed.
- A native compiler executable does not prove its whole link path is native.
  `ctc-clang++` was launched by zccache, but FastLED set the global
  `ZCCACHE_LINK_DEPLOY_CMD=clang-tool-chain-libdeploy` hook, which started
  Python after every cache-miss test/example link on Linux. I incorrectly
  attributed the roughly one-second cadence to generic wrapper overhead.
  Inspect child processes and post-link hooks before explaining a link-time
  bottleneck; then compare the same linker with and without the hook before
  attributing end-to-end gains to a linker switch.
- Before creating a follow-up PR after a concurrent merge, compare the exact
  branch and current master trees. PR #4552 merged the late Windows-only
  deployment fix, so rebasing its branch produced no diff; the actual
  follow-up was a Python cache test that assumed the new Linux linker
  environment variable was absent. Run cache tests with the CI environment
  set as well as locally with defaults.

- For matched firmware comparisons, copy the saved controlled sketch verbatim, including delay constants; do not reconstruct it from memory. Recreated Uno 500-ms controls were replaced by the exact historical 1000-ms sketch before final acceptance (same 3914/266 result). Also wait for an fbuild session to become terminal before bloat; otherwise the report can silently describe the preceding example's ELF.
- GitHub closing-keyword parsing ignores negation: “Do not auto-close #4737” in PR #4752 created a closing reference and closed the parent on merge. Reopened it immediately, changed the body to “Parent #4737 must remain open,” and verified closingIssuesReferences. Use Refs for non-closing links; inspect that field before merging every memory PR.
- In ESP32 HTTP lifecycle probes, assert the numeric status code and body: the current SDK response path emits numeric `200` without an `OK` reason phrase. Initialize the ESP-IDF default event loop alongside esp_netif; the old/new lifecycle probe then passes actual loopback requests, route additions, restart and registration-failure cleanup.

- ESP32 SPI probes: booting QEMU and compiling the real SDK do not prove peripheral operations complete. A recovery probe stopped after host acquisition inside SPI bus initialization; repeat with verbose diagnostics and the unchanged implementation before attributing the timeout to a storage optimization. Keep compilation, accounting, HTTP loopback and physical waveform evidence distinct.

- Native sanitizer verification: debug mode can report UBSan errors and still return success under recovery defaults. Use UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 for the acceptance gate; compare named test inventories before describing cached results. The memory audit exposed integer minimum, negative-shift and signed Q15 defects that ordinary debug runs had masked.

- Blink must remain a minimal LED example with no Serial initialization or banner prints. Serial links the AVR UART object and its RX/TX buffers even when only transmitting; keep example-induced overhead separate from library regressions and do not preserve accidental banner functionality as a requirement.
- ChannelOptions and new emitter/source color profiles belong to the Channels API. Never store them in the legacy CLEDController base: legacy addLeds is the memory-conscious path, including on AVR Uno, which is not classified as the <=1 KB tiny-memory tier. Enforce the API boundary with legacy layout tests rather than protecting only a memory-tier macro.

- ESP crash handlers and CPU faults do not imply supported C++ throw/catch paths
  in FastLED. Verify compiler policy and maintainer contracts before adding
  exception propagation or callback contract changes. Preserve system-owned
  debug exception frames for crash tracing; FastLED still assumes no throw.

- No-throw lint must use the function's semantic AST contract. Annotation tokens
  inside return types, default-argument lambdas, or same-line bodies cannot
  excuse an unannotated enclosing function. After deleting a regex exemption,
  verify its remaining call sites as well as the added regression test.

- For header-based size changes, inspect the claimed removed symbols after building. If an incremental image retains impossible old guards, verify with a clean rebuild before publishing the size claim; keep the first result as diagnostic evidence. Use FL_STATIC_ASSERT for portable compile-time regression assertions.

- A native-console hardware test must use the selected backend for both directions. AutoResearch formerly read through fl I/O but replied through Arduino Serial; raw RPC output must use fl::write_bytes to bypass log filtering while honoring console selection. Compare failing hardware behavior with a selective revert before attributing it to an optimization.

- "Legacy-only" means sketches using `FastLED.addLeds<>()`, not
  `FastLED.add()`. Select the smaller bridge at that API boundary; do not
  infer legacy use from the ESP32 memory tier or remove Channel API behavior.

- Before changing a shared direct-driver flush policy, audit whether every
  backend consumes a queue or only its first strip. LPC SCT requires immediate
  per-strip flushing; opt RMT4 into batched completion with a separate template
  policy and test both lifecycles.

- Distinguish interrupt-driven output from nonblocking `show()` return when
  comparing historical backends. Verify both contracts from source and device
  evidence. READY alone cannot establish a complete waveform: an SDK translator
  that ends a frame early must propagate an error, and long-transfer validation
  must inspect output beyond the initial hardware buffer.

- Queue insertion can fail without throwing. Acquire a frame's in-use lease
  only after insertion succeeds, and reserve destination capacity before moving
  a batch. Exercise failure with a rejecting memory resource and selectively
  restore the old insertion order to verify the regression test catches it.

- Reserve the complete encoded frame before clearing or writing it. A vector's
  failed growth can otherwise create a valid-looking short transmission; keep
  batch failure sticky even if later strips encode successfully.
- Refill deadlines must start from hardware launch, using a clock shared by
  the producer task and ISR. SDK software preload is not a hardware underrun.

- An absolute native-ESP policy includes every ESP32 variant and USB route;
  do not preserve an Arduino-header probe or serial bridge as a convenience
  exception. Keep application-owned Arduino calls separate from FastLED's
  implementation. Native TinyUSB ownership requires disabling Arduino's USB
  auto-start callbacks and retaining the board's registered USB identity.
- Validate console IRQ priority with RMT active. Native UART console traffic
  must use level 1 so RMT's level-3 refill ISR can preempt it. Bidirectional
  AutoResearch RPC plus physical loopback passed after this priority change;
  that evidence covers the UART path, not TinyUSB or USB Serial/JTAG hardware.
- UART write-call atomicity already exists in the shared SDK TX mutex. Preserve
  complete records in one write; a separate library mutex cannot serialize
  arbitrary external print fragments. Weak C provider hooks avoid pulling a
  framework class into native code, while address-only weak vendor-object
  references can detect a linked owner without assuming its class layout.
- Check framework lifecycle as well as SDK behavior: Arduino 2.0.3 can crash
  when Serial.begin replaces a native driver before its HAL mutex exists.
  Test both initialization orders; preserve native-only fallback behavior.
- Library footprint changes must work with unmodified supported SDKs. Do not rely on forked framework startup patches or custom package pins for a claimed FastLED saving; stock framework-owned references remain outside the library's control.
