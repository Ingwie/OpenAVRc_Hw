# C++ Code Standards

## Namespace and Headers
- **Use `fl::` namespace** instead of `std::`
- **If you want to use a stdlib header like <type_traits>, look check for equivalent in `fl/type_traits.h`
- **Vector type usage**: Use `fl::vector<T>` for dynamic arrays. The implementation is in `src/fl/stl/vector.h`.

## `fl::net` Namespace Convention

Files in `src/fl/net/` follow a two-level namespace pattern:

- **Primary user-facing type** (if a single one exists) → lives directly in `fl::net`
  - Example: `fl::net::OTA`
- **Supporting types** (enums, transport types, options) → live in `fl::net::<module>` sub-namespace
  - Example: `fl::net::ota::Service`
- **Facade / collection modules** (no single primary type) → all types in `fl::net::<module>`
  - Example: `fl::net::http::*`, `fl::net::ble::*`

When moving a type into a sub-namespace, **drop the module prefix** from the name since the namespace already provides context:
- `OTAService` → `fl::net::ota::Service`
- `BleStatusInfo` → `fl::net::ble::StatusInfo`
- `BleTransportState` → `fl::net::ble::TransportState`

| File | Primary type (`fl::net`) | Sub-namespace (`fl::net::<mod>`) |
|------|--------------------------|----------------------------------|
| `ota.h` | `OTA` | `ota::Service` |
| `rpc.h` | *(none — transport aliases)* | `rpc::StreamClient`, `rpc::StreamServer` |
| `http.h` | *(none — facade)* | `http::Server`, `http::Response`, `http::fetch_get`, … |
| `ble.h` | *(none — collection)* | `ble::TransportState`, `ble::StatusInfo`, `ble::createTransport`, … |

## API Object Pattern

An **API object** is a public-facing wrapper header that lives alongside a directory of the same name containing implementation details. Users only ever `#include` the API header.

**File layout:**
```
src/fl/stl/fixed_point.h        ← API object (public interface)
src/fl/stl/fixed_point/          ← implementation directory
    s16x16.h                     ← concrete type
    base.h                       ← shared internals
    ...
```

**Rules:**
1. **One header, one directory, same name.** `foo.h` is the public API; `foo/` holds everything behind it.
2. **The API object wraps, it doesn't implement.** It inherits from or delegates to concrete types in the directory. It adds uniformity (common interface, operator forwarding) and convenience (type promotion, free functions) but contains no core logic itself.
3. **Concrete types are self-contained.** Each file in the directory is independently functional. The API object composes them — it doesn't modify them.
4. **A trait maps parameters to concrete types.** A dispatch mechanism (e.g. `fixed_point_impl<IntBits, FracBits, Sign>`) selects the right concrete type at compile time. Invalid combinations fail via an undefined primary template.
5. **The API object re-exposes everything through a uniform interface.** Operators, math functions, conversions — all forwarded. The wrapper adds no new logic, just type-safe forwarding.
6. **Free functions live in the API header.** ADL-enabled free functions (e.g. `fl::sin()`, `fl::floor()`) are SFINAE-gated to the wrapper type, giving users a natural calling convention.
7. **Cross-type interactions live in the API header.** Operations spanning multiple concrete types (e.g. `s0x32 * s16x16 → s16x16`) are defined at the bottom, after all types are visible.

**Exemplar:** `src/fl/stl/fixed_point.h` wrapping `src/fl/stl/fixed_point/`

## Platform Dispatch Headers
- FastLED uses dispatch headers in `src/platforms/` (e.g., `int.h`, `io_arduino.h`) that route to platform-specific implementations via coarse-to-fine detection. See `src/platforms/README.md` for details.
- **All ESP32 variants use native SDK APIs, including console I/O.** Select the required SDK capability, such as `FL_HAS_INCLUDE("driver/gpio.h")`. ESP platform source must not include or probe for `Arduino.h`/`WProgram.h`, or include the Arduino serial bridge (`platforms/arduino/io_arduino.hpp`), even in an inactive branch or an optional backend. `EspArduinoHeaderChecker` runs in normal `./lint` and enforces this throughout `src/platforms/esp/`. Application sketches may still include Arduino headers and explicitly use Arduino `Serial`. Framework/chip identification macros and host-mock selection remain valid; they must not select an Arduino device implementation. See `src/platforms/esp/32/ARCHITECTURE.md` → "No Environment Directories (Arduino vs ESP-IDF)".
- **Keep Arduino UART compatibility narrow.** A version-scoped small C HAL bootstrap may repair initialization with an application-linked Serial object on older cores. Detect that object through an address-only weak reference; do not acquire a strong HardwareSerial dependency or select an Arduino console backend. Heavy Arduino stream and USB class headers remain prohibited.
- **Keep native console transport ownership explicit.** UART uses the SDK UART driver; hardware USB Serial/JTAG uses its own SDK driver with `FASTLED_ESP_FORCE_USB_SERIAL_JTAG=1` and `ARDUINO_USB_CDC_ON_BOOT=0` globally. Arduino HWCDC installs a competing ISR/RX queue and must not start. Native TinyUSB CDC is opt-in with `FL_ESP_USE_TINYUSB_CDC=1` and requires `ARDUINO_USB_CDC_ON_BOOT`, `ARDUINO_USB_MSC_ON_BOOT`, `ARDUINO_USB_DFU_ON_BOOT`, and `ARDUINO_USB_ON_BOOT` all zero, plus board-provided `USB_VID`/`USB_PID` from the existing board registry. Do not attach a native reader to Arduino-owned TinyUSB callbacks or substitute JTAG for a TinyUSB board route. Keep console IRQs at level 1 so RMT level 3 can preempt them; validate RPC traffic and LED output together. USB compilation is not USB hardware validation.
- **Platform-specific headers (`src/platforms/**`)**: Header files typically do NOT need platform guards (e.g., `#ifdef ESP32`). Only the `.cpp` implementation files require guards. When the `.cpp` file is guarded from compilation, the header won't be included. This approach provides better IDE code assistance and IntelliSense support.
  - Correct pattern:
    - `header.h`: No platform guards (clean interface)
    - `header.cpp`: Has platform guards (e.g., `#ifdef ESP32 ... #endif`)
  - Avoid: Adding `#ifdef ESP32` to both header and implementation files (degrades IDE experience)

## Pin Function Names: Parenthesize `pinMode`/`digitalWrite`/`digitalRead`/`analogRead`/`analogWrite` (REQUIRED)

Arduino-ESP32 boards that set `BOARD_HAS_PIN_REMAP` (Arduino Nano ESP32) get
function-like macros named exactly `pinMode`, `digitalWrite`, `digitalRead`,
`analogRead` and `analogWrite` from `cores/esp32/io_pin_remap.h`. A
function-like macro expands wherever its name is followed by `(`, so it
rewrites declarations, definitions, `fl::`-qualified calls, and even
`platforms::`-qualified calls. Arduino's macro maps Arduino D-numbers to GPIO
numbers; FastLED's pin numbers are always raw GPIO numbers, so applying the
remap would be silently wrong, not just noisy.

Spell the name in parentheses everywhere FastLED owns it — declaration,
definition, and call site:

```cpp
void (pinMode)(int pin, PinMode mode) FL_NO_EXCEPT;         // pin.h
void (pinMode)(int pin, PinMode mode) FL_NO_EXCEPT { ... }  // pin.cpp.hpp
(fl::pinMode)(pin, PinMode::Output);                        // call site
```

Parenthesizing a *call* disables argument-dependent lookup, so every call site
states its namespace: `(fl::pinMode)(...)` or `(platforms::pinMode)(...)`,
never a bare `(pinMode)(...)`. `ci/tests/test_esp32_pin_remap_macros.py`
enforces this across `src/fl`, `src/platforms/esp/32` and
`src/platforms/shared` (see #4914). Arduino-API implementations that
deliberately use Arduino pin numbers — `src/platforms/arduino`, and the host
Arduino shim in `src/platforms/stub` — are exempt.

## Select Types at the Preprocessor Boundary (REQUIRED)

When behavior is selected at compile time, keep platform/capability `#if`
branches at the dispatch boundary. Select a concrete backend type or template
specialization there, then express shared behavior in ordinary C++ using that
type. Avoid repeating the same platform conditions throughout constructors,
methods and call sites.

Illustrative shape (use the component's actual capability macros and backends):

```cpp
#if defined(FL_COMPONENT_HAS_BACKEND_A)
#include "backend_a.h"
using SelectedBackend = BackendA;
#else
#include "backend_b.h"
using SelectedBackend = BackendB;
#endif

using PlatformComponent = Component<SelectedBackend>;
```

- Use a backend template when it shares meaningful implementation across
  backends. If no shared algorithm needs a template, a selected type alias alone
  is sufficient. Do not introduce a template solely to wrap an existing type.
- Keep guards for unavailable SDK headers, types and symbols at the boundary;
  templates and `if constexpr` do not make unavailable non-dependent names valid.
  Follow the capability-detection rules above and sparse-dispatch rules below.
- Make fixed configuration visible to the compiler through concrete types,
  template parameters or small inline helpers so unused branches can be removed.
  Keep runtime configuration when callers require it; this rule does not replace
  runtime driver selection such as `Bus::FLEX_IO`.
- Preserve public behavior, defaults and diagnostics when refactoring. For a
  footprint claim, measure matched before/after images and check that template
  instantiations have not duplicated code. This pattern alone does not guarantee
  a smaller binary.

## Driver selection is by template, never a code-enabling define (REQUIRED)

**Do not gate a driver's code behind a `#define` that turns it on.** Select
drivers by *template*, and let the linker drop the ones nothing references.

FastLED already has the mechanism: `BusTraits<Bus::X>::instance()` /
`BusSupports<Bus::X, Chipset>` (see `src/fl/channels/bus_traits.h`). Naming
`BusTraits<Bus::X>::instance()` anywhere in the program is what makes the linker
keep that driver's translation unit; if no instantiation references it, the TU is
dead-stripped (#2428). So on a given target the *unused* drivers are eliminated
automatically — most of them — with no compile-time enable flag, and the whole
program is still type-checked.

```cpp
// Yes — a driver is a BusTraits specialization plus a BusSupports capability.
template<> struct BusTraits<Bus::SPI> {
    using Driver = Esp8266HspiChannelDriver;
    static fl::shared_ptr<Driver> instancePtr() FL_NO_EXCEPT { /* ... */ }
    static Driver& instance() FL_NO_EXCEPT { return *instancePtr(); }
    static void registerWithManager() FL_NO_EXCEPT { /* ... */ }
};
template<> struct BusSupports<Bus::SPI, SpiChipsetConfig> : fl::true_type {};

// No — an opt-in define that turns the driver's code on. It moves the decision
// to the build system and prevents the driver from being link-eliminated *or*
// compile-verified. (Retired: FASTLED_ESP8266_UART, FASTLED_ALL_PINS_HARDWARE_SPI,
// FL_ESP8266_EMBEDDED_FS — FastLED#4940 / #4949.)
#ifdef MY_DRIVER
#include "platforms/.../my_driver.h"
#endif
```

Consequences when adding or changing a platform driver:

- A new platform driver is a `BusTraits`/`BusSupports` specialization (plus a
  `DefaultBus<Chipset>` arm when it should be the platform default), **not** an
  `#ifdef MY_DRIVER` guard.
- Select the concrete backend at the preprocessor boundary (see the section
  above); do not repeat `#if defined(MY_DRIVER)` throughout a driver's body.
- A define may still gate code that is genuinely unavailable (a missing SDK
  header), or carry platform wiring options (pin order). It must not be the
  switch that turns a driver's implementation on.
- Prove elimination with a size diff (`bash bloat`), not by reading the source.

## Sparse Platform Dispatch Pattern (`.cpp.hpp` files)

A `.cpp.hpp` file is a **compile-time component router** that assembles a complete feature from sparse, per-platform fragments with null/no-op fallbacks.

**Key properties:**
1. **Sparse** — No platform implements everything. Each platform contributes only the pieces it supports (e.g., ESP32 provides FreeRTOS tasks but not cooperative coroutines; Teensy provides cooperative context switching but not OS tasks).
2. **Fallback** — Missing pieces get a null/no-op implementation automatically. If a platform doesn't provide a component, the system still works — those features are simply inert.
3. **Component routing** — The `.cpp.hpp` file examines platform defines and `#include`s the right fragments. It composes a complete system from whatever pieces the current platform offers.

**Why `.cpp.hpp` instead of `.cpp` or `.h`?**
- Contains **function definitions** (like `.cpp`) — so it can't be a normal `.h` (would cause multiple-definition linker errors).
- Designed to be **`#include`d from exactly one translation unit** (like `.hpp`) — not compiled on its own.
- Marked `// IWYU pragma: private` to enforce single inclusion.
- The extension signals: "I contain implementations, I'm meant to be included, and I must only be included once."

**Naming convention (future standard):**
- **`component.impl.cpp.hpp`** — The router file. Contains the `#if`/`#elif` dispatch logic that selects which platform fragment to include. Included from exactly one translation unit.
- **`component_<platform>.impl.hpp`** — Platform-specific implementation fragments that the router includes (e.g., `coroutine_esp32.impl.hpp`, `coroutine_wasm.impl.hpp`).

The names make roles explicit: `.impl.cpp.hpp` = "implementation router, include me once." `_<platform>.impl.hpp` = "platform fragment, the router includes me."

**Structure of a `.impl.cpp.hpp` router:**
```cpp
// IWYU pragma: private

// Platform detection
#include "platforms/arm/is_arm.h"
#include "platforms/esp/is_esp.h"
#include "platforms/wasm/is_wasm.h"

#if defined(FL_IS_WASM)
#include "platforms/wasm/feature_wasm.impl.hpp"
#elif defined(FASTLED_STUB_IMPL)
#include "platforms/stub/feature_stub.impl.hpp"
#elif defined(FL_IS_ESP32)
#include "platforms/esp/32/feature_esp32.impl.hpp"
#else
// Fallback: null/no-op implementation
#include "platforms/shared/feature_null.impl.hpp"
#endif
```

**Current exemplar:** `src/platforms/coroutine.impl.cpp.hpp`.

### No-op Fallback (`_noop.hpp`)

The dispatcher's `#else` branch needs a target — that's the **no-op implementation**. Platforms without hardware support for a feature get an implementation that satisfies the same API signature with empty / zero-returning bodies, so user code compiles unconditionally on any platform.

**Naming and location:**
- Lives in `src/platforms/shared/` with the suffix `_noop.hpp` — e.g., `pin_noop.hpp`, `memory_noop.hpp`, `simd_noop.hpp`, `codec/h264_noop.hpp`.
- Never call it `_null.hpp`, `_stub.hpp`, or `_dummy.hpp`. The keyword is **`noop`** — this is what to grep for to find the convention.

**File contents:**
- Mark `// IWYU pragma: private` (header is only included via the dispatcher, never directly).
- Functions are `inline` to stay ODR-safe if the header is reached from multiple TUs.
- Live in the `fl::platforms::` namespace (not `fl::` — keeps the public surface clean).
- Body convention: return a safe API-defined inert default — commonly `0`, `false`, `nullptr`, or empty span, but **documented sentinel values are also valid when the API contract requires them** (e.g., `pin_noop.hpp::needsPwmIsrFallback` returns `true` because the no-op platform genuinely needs the ISR fallback path; `setPwmFrequencyNative` returns `-4` as the documented "not supported" error code). **Never assert, throw, or call `FL_WARN`.** A no-op is a no-op — the whole point is that user code keeps running on unsupported platforms.
- For multi-tier APIs that ship `FL_<COMPONENT>_HAS_<FEATURE>` capability macros (see Type 3 below), the no-op header **must not define any of the boolean capability flags** — so `#ifdef FL_<COMPONENT>_HAS_<FEATURE>` evaluates to false on the unsupported platform. It **must** still define any numeric properties (e.g., `#define FL_WATCHDOG_PERSIST_BYTES 0`) so user code that reads them compiles.

**Stub-only variant (`_stub_noop.h`):**
When the no-op only makes sense for the host/stub build (because it pretends to be a real OS primitive that no real MCU exposes), put it in `src/platforms/stub/` with the `_stub_noop.h` suffix instead — e.g., `mutex_stub_noop.h`, `thread_stub_noop.h`, `semaphore_stub_noop.h`. Rule of thumb:
- **`shared/<x>_noop.hpp`** — fallback that *any* unsupported platform may include via the dispatcher.
- **`stub/<x>_stub_noop.h`** — only the host/stub build consumes it.

**Current exemplars:** `src/platforms/shared/memory_noop.hpp`, `src/platforms/shared/pin_noop.hpp`, `src/platforms/shared/simd_noop.hpp`, `src/platforms/shared/codec/h264_noop.hpp`.

## Span Usage
- **Automatic span conversion**: `fl::span<T>` has implicit conversion constructors - you don't need explicit `fl::span<T>(...)` wrapping in function calls. Example:
  - Correct: `verifyPixels8bit(output, leds)` (implicit conversion)
  - Verbose: `verifyPixels8bit(output, fl::span<const CRGB>(leds, 3))` (unnecessary explicit wrapping)
- **Container auto-conversion**: `fl::span` auto-converts from containers with `data()`/`size()`. Pass the container directly:
  - ✅ `AudioSample(data, timestamp)` or `fl::span<const fl::i16> s = myVector;`
  - ❌ `AudioSample(fl::span<const fl::i16>(data.data(), data.size()), timestamp)`
- **Prefer passing and returning by span**: Use `fl::span<T>` or `fl::span<const T>` for function parameters and return types unless a copy of the source data is required:
  - Preferred: `fl::span<const uint8_t> getData()` (zero-copy view)
  - Preferred: `void process(fl::span<const CRGB> pixels)` (accepts arrays, vectors, etc.)
  - Avoid: `std::vector<uint8_t> getData()` (unnecessary copy)
  - Use `fl::span<const T>` for read-only views to prevent accidental modification

## No Raw Pointers Into `fl::` Containers (lint-enforced)

Do not treat an `fl::` container as a flat buffer by taking a raw pointer into
its storage. `fl::deque<T>` stores elements as a chunked map of fixed-size
blocks (PR #3282), so `&dq[0]` / `dq.data()` addresses at most one chunk —
that was the `json::to_string_native` overrun and the #3286 audio-detector
crash. Even on containers that ARE contiguous today the idiom is brittle to
layout changes and bypasses bounds checking.

Banned forms on `fl::` containers: `.data()` (non-contiguous containers only),
`&c[i]`, `&c.at(i)`, `&c.front()`, `&c.back()`.

Use instead:

- `fl::span<T>` — a bounded view; contiguity is proven at the type level.
- An iterator pair `[begin, end)` — works for any container, including `fl::deque`.
- An explicit copy for legacy C APIs:
  `fl::vector<T> flat(dq.begin(), dq.end()); use(flat.data(), flat.size());`

Enforced by two Rust lint checkers in
`ci/lint_cpp_rs/src/checkers/container_ptr.rs` (FastLED#3287):
`ContainerNonContiguousPtrChecker` hard-fails on `fl::deque` /
`fl::circular_buffer`; `ContainerElementAddressChecker` is warn-only for
address-of-element on `fl::vector` / `fl::string` / `fl::array` and friends.
Genuine C-API interop sites can carry a `// fl-lint: container-data-ptr-ok`
comment (line suffix or the line immediately above), justified by a short
reason.

## Macro Definition Patterns

### Type 1: Platform/Feature Detection Macros (defined/undefined pattern)

**Platform Identification Naming Convention:**
- MUST follow pattern: `FL_IS_<PLATFORM><_OPTIONAL_VARIANT>`
- Correct: `FL_IS_STM32`, `FL_IS_STM32_F1`, `FL_IS_STM32_H7`, `FL_IS_ESP_32S3`
- Wrong: `FASTLED_STM32_F1`, `FASTLED_STM32` (missing `FL_IS_` prefix)
- Wrong: `FL_STM32_F1`, `IS_STM32_F1` (incorrect prefix pattern)

**Enforced, as of FastLED#4021.** The Rust `MacroPrefixChecker` runs inside
`bash lint --cpp` and fails on a *new* `FASTLED_*` macro name. Existing public
and compatibility names that cannot yet be renamed are explicitly listed in
`ci/lint_cpp_rs/legacy_macro_amnesty.txt`. That centralized list is reviewed
by hand and may shrink freely; it must never be bulk-regenerated from source.

It matches names on preprocessor lines, so a macro that is only ever *tested*
counts. That is deliberate: `FASTLED_SAMD51_HW_SPI` was a user-supplied opt-in
appearing solely as `#if defined(...)`, never defined here, and a
definitions-only check would have passed exactly the case that motivated the
rule's enforcement.

If a name genuinely has to match one published outside this repo, add it to
the centralized amnesty with reviewable compatibility justification in the
change description. New internal macros still use `FL_`.

**Detection and Usage:**
- Platform defines like `FL_IS_ARM`, `FL_IS_STM32`, `FL_IS_ESP32` and their variants
- Feature detection like `FASTLED_STM32_HAS_TIM5`, `FASTLED_STM32_DMA_CHANNEL_BASED` (not platform IDs)
- These are either **defined** (set) or **undefined** (unset) - NO values
- Correct: `#ifdef FL_IS_STM32` or `#ifndef FL_IS_STM32`
- Correct: `#if defined(FL_IS_STM32)` or `#if !defined(FL_IS_STM32)`
- Define as: `#define FL_IS_STM32` (no value)
- Wrong: `#if FL_IS_STM32` or `#if FL_IS_STM32 == 1`
- Wrong: `#define FL_IS_STM32 1` (do not assign values)

### Type 2: Configuration Macros with Defaults (0/1 or numeric values)
- Settings that have a default when undefined (e.g., `FASTLED_USE_PROGMEM`, `FASTLED_ALLOW_INTERRUPTS`)
- Numeric constants (e.g., `FASTLED_STM32_GPIO_MAX_FREQ_MHZ 100`, `FASTLED_STM32_DMA_TOTAL_CHANNELS 14`)
- These MUST have explicit values: 0, 1, or numeric constants
- Correct: `#define FASTLED_USE_PROGMEM 1` or `#define FASTLED_USE_PROGMEM 0`
- Correct: `#define FASTLED_STM32_GPIO_MAX_FREQ_MHZ 100`
- Check as: `#if FASTLED_USE_PROGMEM` or `#if FASTLED_USE_PROGMEM == 1`
- Wrong: `#define FASTLED_USE_PROGMEM` (missing value - ambiguous default behavior)

### Type 3: Component Capability Flags (per-subsystem, defined/undefined for booleans, numeric for properties)

For a subsystem (e.g., `Watchdog`, `Audio`, `Codec`) that has multi-tier platform support, document each platform's capabilities with `FL_<COMPONENT>_HAS_<FEATURE>` flags. These let user code compile-time gate optional features without doing platform detection itself.

**Spelled-out names — no acronyms in macro identifiers.** The macro name and the public API name share a single vocabulary. If the API is `FastLED.watchdog()` then the macros are `FL_WATCHDOG_*`, not `FL_WDT_*`. If the API is `FastLED.audio()` then the macros are `FL_AUDIO_*`. Acronyms in macro names cost grepability and force readers to learn a second name for the same thing.
- ✅ Correct: `FL_WATCHDOG_HAS_WINDOW_MODE`, `FL_WATCHDOG_PERSIST_BYTES`, `FL_AUDIO_HAS_I2S`, `FL_CODEC_HAS_H264`
- ❌ Wrong: `FL_WDT_HAS_WINDOW_MODE` (abbreviation hides the component), `FASTLED_WATCHDOG_WINDOW_MODE` (use `FL_` for newer per-component flags), `WATCHDOG_HAS_WINDOW_MODE` (missing prefix)

**Boolean capability flags:**
- Defined or undefined (same shape as Type 1) — NO values
- Define as: `#define FL_WATCHDOG_HAS_WINDOW_MODE` (no value)
- Check as: `#if defined(FL_WATCHDOG_HAS_WINDOW_MODE)` or `#ifdef FL_WATCHDOG_HAS_WINDOW_MODE`

**Numeric properties (sizes, limits, capacities):**
- Explicit numeric values (same shape as Type 2)
- Define as: `#define FL_WATCHDOG_PERSIST_BYTES 16`
- Check as: `#if FL_WATCHDOG_PERSIST_BYTES >= 8`
- User code may `static_assert(FL_WATCHDOG_PERSIST_BYTES >= 8, "...")` to enforce minimums the unified API promises.

**Where they live:** Defined in the per-platform `*.impl.hpp` (or the component's public header) that implements the feature. The `_noop.hpp` fallback defines **none** of the boolean flags (so `#ifdef` checks correctly evaluate false on unsupported platforms) and **always** defines a zero/default for every numeric property the unified API exposes (so `#if`-on-numeric-value still compiles).

**Distinction from Type 1 (`FL_IS_*`):** Type 1 says "I am running on platform X." Type 3 says "this component has feature Y on this platform." A single platform may carry many Type 3 flags from independent components.

## Default Example Pins (`FL_PIN_*`) — Platform Declares, Header Falls Back

Examples must not hardcode pin numbers. A literal in a sketch is a guess about hardware the sketch cannot see; the platform is the only layer that knows which pins exist.

| Macro | Fallback | Use |
|---|---|---|
| `FL_PIN_CLOCKLESS_1` | `3` | data pin, single-wire chipsets (WS2812 etc.) |
| `FL_PIN_SPI_DATA_1` | `1` | data pin, clocked chipsets (APA102 etc.) |
| `FL_PIN_SPI_CLOCK_1` | `2` | clock pin, clocked chipsets |

**The contract, both halves:**

1. **A platform SHOULD declare its own value** beside its `_FL_DEFPIN` table (or its pin-mask block), guarded with `#ifndef` so a sketch or build flag still wins.
2. **A platform that declares nothing gets the fallback**, defined in `src/platforms/default_pins.h`. That is a supported outcome, not an omission to be linted — most platforms are fine on pin 3.

```cpp
// in the platform's fastpin_*.h, next to the pin table that justifies it
#ifndef FL_PIN_CLOCKLESS_1
#define FL_PIN_CLOCKLESS_1 4
#endif
```

`platforms/default_pins.h` is included from `FastLED.h` *after* `platforms.h`, so platform declarations always win. Declaring in a `.cpp.hpp` is wrong — examples need the value at preprocess time.

**Examples consume the macro, never a literal:**

```cpp
#ifndef PIN_DATA
#define PIN_DATA FL_PIN_CLOCKLESS_1   // sketch/build flag still overrides
#endif
```

### Choosing a value

Compiling is the floor, not the bar. `FastPin<N>::validpin()` catches only pins the platform declares invalid; it cannot catch a pin that exists and is still a bad default. A good value is:

- **present in that board's `_FL_DEFPIN` table** — the compile-time failure, and the cheapest to check
- **not the UART the examples print on** — most examples call `Serial.begin()`, so a default that lands on `RX`/`TX` has the sketch fighting its own console
- **not a boot-strapping pin** — sampled at reset; an attached strip can hold it and stop the board booting
- **not reserved for flash, PSRAM, or USB/JTAG**
- **actually broken out** on the reference board for that platform

Platform headers usually already record this. `fastpin_esp32.h` documents its UART and flash pins per variant in the `FASTLED_UNUSABLE_PIN_MASK` comments — read those before picking, rather than inferring from a datasheet.

### Enforcement

`ci/tests/test_samd_default_pins.py` parses each board branch's pin table, resolves all three macros (declared value, else fallback), and asserts the result is in that table. It is preprocessor/parser level, so it needs no cross-toolchain. Extend it as platforms declare values — the shape generalises beyond SAMD.

### Why this exists

Two failures, both invisible for a long time:

- **Adafruit Feather M4 has no pin 2 and no pin 3** (`fastpin_arm_d51.h` says so outright: "no pins 2 3"). `Blink` hardcoded 3 and `Apa102` hardcoded 1/2, so neither compiled for that board — with a `validpin()` assertion whose message talks about ground and read-only and noisy pins, sending you to look at wiring rather than at a pin table. Nobody noticed because SAMD had never built at all (#4011).
- **On ESP32 classic, GPIO 3 is `U0RXD`** — the pin `Serial` receives on. That compiles cleanly and is wrong on hardware, which is the worse failure: the example silently does nothing and there is nothing to search for.

Tracking issue for the per-platform audit: **#4018**.

## Warning and Debug Output
- **Use proper warning macros** from `fl/stl/compiler_control.h`
- **Use `FL_DBG("message" << var)`** for debug prints (easily stripped in release builds)
- **Use `FL_WARN("message" << var)`** for warnings (persist into release builds)
- **Avoid `fl::printf`, `fl::print`, `fl::println`** - prefer FL_DBG/FL_WARN macros instead
- **printf-style log formatting is a compile error** (#4709): every log macro (`FL_WARN`, `FL_ERROR`, `FL_INFO`, `FL_DBG`, `FL_PRINT`, `FL_LOG_*`, `FASTLED_*`, `FL_LOG_ASYNC`) takes one literal or one `<<` stream chain. `FL_WARN("x=%d", x)` fails with a static_assert because it links the whole `fl::printf` engine (RAM1 on Teensy 4). Write `FL_WARN("x=" << x)`; use `fl::to_hex(v)` for `%x`.

## Teensy 3.x `__cxa_guard` Conflicts
- **Problem**: Function-local statics with non-trivial constructors generate implicit `__cxa_guard_*` function calls. If Teensy's `<new.h>` is included after the compiler sees the static, the signatures conflict.
- **Preferred Solution (`.cpp.hpp` files)**: Include `<new.h>` early on Teensy 3.x to declare the guard functions before use:
  ```cpp
  // Teensy 3.x compatibility: Include new.h before function-local statics
  #if defined(__MK20DX128__) || defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
      #include <new.h>
  #endif
  ```
  - Example: `src/fl/async.cpp.hpp` (includes `<new.h>` early to prevent conflicts)
  - This ensures the compiler uses the correct `__guard*` signature
- **Alternative Solution (header files)**: Move static initialization to corresponding `.cpp` file
  - Example: See `src/platforms/shared/spi_hw_1.{h,cpp}` for the correct pattern
- **Exception**: Statics inside template functions are allowed (each template instantiation gets its own static, avoiding conflicts)
- **Linter**: Enforced by `StaticInHeaderChecker` in the Rust crate (`ci/lint_cpp_rs/src/checkers/style.rs`) for critical directories (`src/platforms/shared/`, `src/fl/`, `src/fx/`)
- **Suppression**: Add `// okay static in header` comment if absolutely necessary (use sparingly)

## Peripheral Mocks: Singleton + `MockWrapper` Forwarder (REQUIRED)
- **Rule:** Every peripheral mock in FastLED (`Rmt4PeripheralMock`, `Rmt5PeripheralMock`, `UartPeripheralMock`, `I2sLcdCamPeripheralMock`, `I2sPeripheralEsp32DevMock`, `SpiPeripheralMock`, `FlexIOPeripheralMock`, etc.) MUST expose `static XxxMock& instance() FL_NO_EXCEPT` backed by `fl::Singleton<XxxMockImpl>`. Per-test factories (`createShared()`, `create()`, `make_shared<Mock>()`) are **not** acceptable — they fragment state across the process, break the mental model shared with every peer mock, and turn `reset()` between tests from mandatory hygiene into an unreachable no-op.
- **How to wire a singleton mock into an engine that takes `fl::shared_ptr<IPeripheral>`:** define a thin `MockWrapper : public IPeripheral` class inside the test TU that forwards every interface method to `XxxMock::instance().foo(...)`, then pass `fl::make_shared<MockWrapper>()` to the engine ctor. See `tests/platforms/esp/32/drivers/i2s/channel_driver_i2s.cpp:43-87` for the canonical `createMockPeripheral()` helper — every new engine test copies this pattern.
- **Why:** The peripheral is a real hardware resource — there is exactly one on the chip. The mock mirrors that constraint. Tests that need different mock configurations use error-injection knobs on the singleton (`setTransmitFailure(true)` etc.) and `reset()` between cases, not a fresh mock per test.
- **Exception:** none. If your engine's ctor doesn't take a `shared_ptr<IPeripheral>`, put the mock in a member field of the test fixture and call `instance()` directly — the singleton pattern still holds.
- **History:** Established during #3471 (I2S esp32dev bring-up) after an earlier draft used `createShared()`. Every peer mock in the tree pre-dates that draft and uses the singleton — the wrapper pattern was documented in code but not in the standards until this point.

## One peripheral, one `Bus::FLEX_IO` slot (REQUIRED)
- **Rule:** A physical peripheral (I2S1, PARLIO, LCD_CAM, FlexIO2, etc.) is bound to EXACTLY ONE `Bus::FLEX_IO` slot on any given silicon. Never register two `BusTraits<Bus::FLEX_IO, N>` specializations that both wrap the same underlying hardware, even at different `N` values.
- **How to spot the mistake:** if two drivers you're about to register both call into the same peripheral's registers (I2S1 conflict, PARLIO channel conflict, LCD_CAM peripheral, etc.), and you're tempted to put them at `Bus::FLEX_IO, 0` and `Bus::FLEX_IO, 1` respectively — stop. The correct move is a **unified engine at one slot** (see the next section) that dispatches per-channel by mode.
- **Why:** the peripheral can only run one mode / one configuration at a time. Two slots claiming the same hardware creates a runtime race where whichever slot got its `initialize()` called last wins, silently. Users diagnosing "why did my SPI-mode strip stop working after I called `enableAllDrivers()`" have no way to figure out that a clockless-mode registration at a different slot number stole the hardware.
- **Correct multi-slot usage:** slots ARE for genuinely separate peripherals. On ESP32-P4, `Bus::FLEX_IO, 0` = PARLIO peripheral, `Bus::FLEX_IO, 1` = LCD_CAM RGB peripheral. Different silicon blocks, different registers, no conflict. On classic ESP32, both `I2S_SPI` and the modern `ChannelEngineI2sEsp32Dev` wrap I2S1 — same peripheral — so both live at `Bus::FLEX_IO, 0` and the transition from one to the other is a swap, not a coexistence.
- **History:** Established 2026-07-01 during FastLED#3516 I2S driver rewrite. Agent proposed registering the new modern I2S engine at `Bus::FLEX_IO, 1` on classic ESP32 to bench-verify it in parallel with the existing `I2S_SPI` at `Bus::FLEX_IO, 0`. Developer caught the mistake — "if these are using the same peripheral then they both need to be flexio 0." Rule captured so future agents don't repeat the "temporary parallel binding for bench testing" shortcut. Both drivers own I2S1; only one can be bound; the transition is a swap-at-Phase-2c, not a two-slot coexistence.

## Parallel-IO Driver: Unified Clockless + SPI Engine (REQUIRED)
- **Rule:** Any parallel-IO peripheral driver (FlexIO, ObjectFLED, ESP32 PARLIO, LCD_CAM, I2S, etc.) MUST put its SPI mode and its clockless mode in the SAME `ChannelEngine` — do NOT fork into separate `ChannelEngineXxx` + `ChannelEngineXxxSPI` classes, separate `Bus::X` + `Bus::X_SPI` enum values, or separate `BusTraits<>` specializations.
- **How:** The unified engine's `getCapabilities()` returns `Capabilities(true, true)`. Both `BusSupports<Bus::X, ClocklessChipset>` and `BusSupports<Bus::X, SpiChipsetConfig>` specialize to `fl::true_type`. `canHandle()` accepts both `data->isClockless()` and `data->isSpi()` channels (gated by pin / timing routability for each mode). `show()` routes per-channel — if the prior channel ran clockless and the current channel is SPI, reconfigure the peripheral (shifter / timer / DMA TCD) before transmitting.
- **Why:** The peripheral itself can only run in one mode at a time, so the mode switch always happens AT show-time anyway. Forking duplicates Bus enum entries, priority-table rows, registration calls, `_build.cpp.hpp` includes, and `BusTraits<>` specializations for zero behavioral benefit. The peripheral is the dispatch boundary, not the mode.
- **Exception:** genuinely separate peripherals (e.g. ESP32 LPSPI vs I2S_SPI are different silicon blocks with completely different register surfaces) get separate drivers. The "parallel-IO" qualifier excludes the different-peripheral-same-protocol case.
- **History:** Established 2026-06-27 during #3428 FlexIO-SPI/ObjectFLED-SPI implementation. Initial design forked into separate FLEX_IO_SPI / OBJECT_FLED_SPI bus slots; user reverted because forking made the maintenance surface 4× larger with no benefit. See `src/fl/channels/README.md` → "Rule: Parallel-IO peripherals — one engine for both clockless and SPI modes" for the full pattern + reference code.

## Runtime driver selection is `Bus::FLEX_IO` — legacy chipset templates are not (REQUIRED)
- **Rule:** When adding an AutoResearch harness, on-device test, or any test-driver code that exercises a parallel-IO peripheral (FlexIO, ObjectFLED, ESP32 PARLIO, LCD_CAM, I2S1 parallel-out, etc.), **reach for the `Bus::FLEX_IO` runtime-selection surface**, never the legacy chipset template class directly.
- **Old (wrong) way — reaching for the class template:**
  ```cpp
  // Rebuilds a whole custom pipeline around one specific driver's
  // template and blocks driver unification. NEVER do this in a
  // test harness or validation sketch.
  ClocklessI2S<PIN, WS2812_TIMING, GRB> controller;   // ← wrong
  FastLED.addLeds(&controller, leds, N);
  ```
- **New (right) way — runtime binding through `Bus::FLEX_IO`:**
  ```cpp
  // Bind whatever peripheral BusTraits<Bus::FLEX_IO, 0> resolves to
  // on this silicon (classic ESP32 → I2S1; ESP32-P4/C6/H2/C5 →
  // PARLIO; Teensy 4.x → FlexIO or ObjectFLED; ESP32-S3 → LCD_CAM).
  FastLED.setExclusiveDriver<fl::Bus::FLEX_IO, 0>();
  FastLED.addLeds<WS2812, PIN, GRB>(leds, N);
  ```
- **Subtype information (which concrete peripheral is actually bound, which port/instance number, which mode) goes into a device-info JSON structure returned by the RPC handler.** The handler is peripheral-agnostic; the runtime driver reports what it is. Example shape:
  ```json
  {
    "bus": "FLEX_IO",
    "instance": 0,
    "peripheral": "I2S1_PARALLEL",
    "port": 1,
    "silicon": "ESP32-D0WD-V3",
    "mode": "clockless"
  }
  ```
- **Caveat — mind the `Bus::FLEX_IO, 0` binding on classic ESP32 today:** as of 2026-07-01, the `Bus::FLEX_IO, 0` slot on classic ESP32 routes to the **I2S-SPI** driver (`src/platforms/esp/32/drivers/i2s_spi/`), NOT the Yves parallel-out clockless driver (`src/platforms/esp/32/drivers/i2s/clockless_i2s_esp32.h`). The unified clockless-plus-SPI engine that would make the parallel-out clockless reachable via `Bus::FLEX_IO, 0` is tracked in [FastLED#3512 Phase 4](https://github.com/FastLED/FastLED/issues/3512). Until Phase 4 lands, an AutoResearch harness or test harness that wants to validate the Yves clockless parallel-out driver cannot reach it through the modern channel API — that harness is genuinely blocked on Phase 4. Do NOT invent a workaround by reaching for `ClocklessI2S<>` directly; write the harness once Phase 4 makes it reachable via `Bus::FLEX_IO, 0`.
- **Rationale:** the whole point of the parallel-IO unified-engine rule (previous section) is that the `Bus::FLEX_IO` slot dispatches per-silicon to the right peripheral in the right mode, and users select drivers at runtime rather than compile-time. If a test harness reaches for one specific chipset template, that harness only works for one specific driver — and every future driver has to grow its own harness. One `Bus::FLEX_IO` harness works across every parallel-IO driver on every silicon, with subtype info flowing through the device-info JSON.
- **History:** Established 2026-07-01 during [FastLED#3515 Phase B](https://github.com/FastLED/FastLED/issues/3515) drafting. Agent initially reached for `ClocklessI2S<>` directly to write an I2S-specific harness; user rejected because the modern channel-manager surface makes I2S "just a `Bus::FLEX_IO` implementation," and subtype info belongs in a device-info JSON, not baked into the harness. See [FastLED#3516](https://github.com/FastLED/FastLED/issues/3516) meta and the surrounding refactor phases.

## Check if the target hardware might already be attached (REQUIRED)
- **Rule:** Before declaring a task "bench-blocked" or "requires physical hardware I don't have," **first check whether the target device might already be attached to the developer's machine and try running the on-device validation.** Do not assume hardware is absent — the developer's bench is often live.
- **MANDATORY FIRST STEP — `fbuild port scan` before ANY "not attached" claim.** You may **never** write "board X is not attached" / "I don't have that board" / "static-verified only, target board absent" **without first enumerating what is physically connected.** A "no board" statement that was not preceded by a port scan in the same session is a rule violation. Enumerate with fbuild's native scanner (NOT raw pyserial — same reason as the PYS001 ban):
  ```bash
  fbuild port scan
  ```
  It renders two rows per port — the OS identity (`COM11  10C4:EA60  Silicon Labs CP210x …`) plus a `└─ vendor / product` line resolved from the FastLED boards DB (e.g. `└─ Arduino / NodeMCU 0.9 (ESP-12 Module)` for an ESP32-WROOM-class board, `└─ Espressif Systems / WEMOS LOLIN S3`, `└─ NXP Semiconductors / LPC-Link2 CMSIS-DAP` for the LPC845-BRK). `bash autoresearch` with no args also auto-detects a single board via `detect_attached_chip()`, but `fbuild port scan` is the tool for "what is attached right now" because it lists **all** ports at once. Multiple boards are routinely attached simultaneously — do not reason about attachment from memory, prior turns, or which board "this task is about." Read the scan.
- **How to check a specific target once you know it's present:**
  - **ESP32 / classic-ESP32 / ESP32-S3 / etc.:** run `bash autoresearch <board>` (e.g. `bash autoresearch esp32dev`). If a device is attached and reachable, autoresearch will compile via fbuild, flash it, boot it, and RPC-ping it. A successful `RESULT: {"type":"ready",...}` boot line + `Ping successful` response confirms live hardware.
  - **Teensy 4.x:** same — `bash autoresearch teensy41`.
  - **LPC845-BRK:** `bash autoresearch --pwm-dma-cl` for the SCT+DMA self-loopback.
  - **Board-specific auto-detect:** running `bash autoresearch` with no arguments will attempt to auto-detect the attached board via its USB serial VID:PID.
- **When the check applies:** any time an agent is about to write "requires bench validation, deferred," "static-verified only," or "the target board isn't attached" for a driver / peripheral / autoresearch task on any platform the AutoResearch harness supports.
- **What to do when the device IS attached:** proceed. Land the code, flash it, run the validation, iterate. The whole point of the AutoResearch harness is that on-device validation is a first-class, in-loop step — not a downstream ask on the human.
- **What to do when the device is NOT attached:** if `bash autoresearch <board>` fails at the connect / serial / RPC-ping stage with a device-not-found or timeout error, THEN the task is genuinely bench-blocked. Document the specific failure (e.g. "COM11 not present," "RPC ping timed out after boot") so the next agent doesn't repeat the check unnecessarily.
- **Rationale:** repeatedly deferring "bench work" that could actually run in-loop is a productivity killer. The AutoResearch harness exists to eliminate the loop-out-to-human step for the routine "flash and verify" cycle. Assuming hardware is absent when the developer's own answer would be "just try it" wastes both sides' time.
- **History:**
  - Established 2026-07-01 during [FastLED#3516](https://github.com/FastLED/FastLED/issues/3516) I2S driver rewrite session. Agent had spent multiple rounds deferring Phases 2b–2e as "bench-blocked" while the developer's ESP32-WROOM was in fact attached to COM11 and running. Developer prompted "the esp32wroom is attached" — one line unblocked a whole cluster of previously-deferred phases. Rule captured so future agents check first, defer second.
  - **Reinforced 2026-07-04** (LPC pyserial migration session). Agent migrated the flexio/objectfled bench runners and declared them "static-verified only, target ESP32/Teensy boards not attached" — **without ever running a port scan.** The ESP32-WROOM (COM11), three ESP32-S3 boards, and Teensy were attached the whole time and could have been used for a full hardware run. Developer: "esp32wroom and teensy boards ARE attached and you would have known that if you had done a port scan." When the agent then ran the wrong scanner (raw pyserial `list_ports`), the developer corrected it again: use **`fbuild port scan`** — the native scanner that resolves each port's vendor/product from the FastLED boards DB. Both points folded into the MANDATORY step above: never infer absence, and enumerate with `fbuild port scan`.

## Channel Engine DMA Wait Pattern
- **`onBeginFrame()` / `show()` must wait for `poll() == READY` before starting a new frame** — use a simple `while (poll() != READY)` loop
- **Yield in wait loops with `fl::task::yield_system()`** — never busy-spin without yielding. Use `fl::task::yield_system(250)` inside wait loops to yield to the OS scheduler (at least one FreeRTOS tick on ESP32; on host it only pumps the stub coroutine runner and spins out the budget when idle, exactly like `run(us, SYSTEM)`). This prevents watchdog timeouts and starvation of WiFi/BT/system tasks. Include `fl/task/executor.h`.
  - **Do NOT use** bare `fl::yield()`, `vTaskDelay()`, or `taskYIELD()` — the `fl::task` entry points are the unified API
  - For tight DMA polling use `fl::task::yield_system(us)` (OS yield only). It behaves exactly like `fl::task::run(us, ExecFlags::SYSTEM)`, but `run()` dispatches on its flags at runtime, so even a SYSTEM-only call links the task Scheduler and Executor into every sketch (~1.8 KB flash, ~200 B RAM on ESP32, #4797)
  - For longer waits use `ExecFlags::ALL` (also pumps coroutines and scheduled tasks)
- **Do NOT branch on DRAINING or other intermediate states** inside the wait loop in `show()` or `onBeginFrame()`. The `poll()` method drives the state machine to READY; callers just wait for it.
- **`onEndFrame()` may wait for READY *or* DRAINING** — after `show()` kicks off DMA, it's fine to return once DMA is running (DRAINING). `onBeginFrame()` will ensure READY before the next frame.
- **Rationale**: Branching on intermediate states in the "wait for previous frame" path splits logic across multiple places and makes the code harder to reason about.
- **Reference**: See `src/fl/channels/README.md` → "DMA Wait Pattern" section

## Naming Conventions
- **Member variable naming**: All member variables in classes and structs MUST use mCamelCase (prefix with 'm'):
  - Correct: `int mCount;`, `fl::string mName;`, `bool mIsEnabled;`
  - Wrong: `int count;`, `fl::string name;`, `bool isEnabled;`
  - The 'm' prefix clearly distinguishes member variables from local variables and parameters
- **Follow existing code patterns** and naming conventions

## Public Settings Pattern (Global Configuration via `CFastLED`)

**Core Principle**: Any new global / library-wide configuration setter MUST be exposed as a public method on the `CFastLED` god instance in `src/FastLED.h`. The implementation may live as a free function in the `fl::` namespace for ADL / testability, but the documented user-facing entry point is `FastLED.setX(...)`, not `fl::set_x(...)`.

**Rationale**: `CFastLED` is the discoverable surface — users see `FastLED.setBrightness()`, `FastLED.setMaxRefreshRate()`, `FastLED.setPowerModel()` in every sketch and expect every other knob to live there too. Free-function-only configuration ratchets the API surface into a second, undocumented place that users won't find and that drifts out of sync with the god instance.

**Exemplar** (`src/FastLED.h:1455`):
```cpp
// Free function in fl:: namespace — does the work, testable in isolation
namespace fl { void set_power_model(const PowerModelRGB& m) noexcept; }

// Public entry point on CFastLED — thin delegator, this is what users call
class CFastLED {
    inline void setPowerModel(const PowerModelRGB& model) {
        set_power_model(model);
    }
};
```

**Rules**:
1. ❌ **NEVER ship a new `fl::set_*` / `fl::enable_*` / `fl::disable_*` / `fl::use_*` free function that mutates library-wide state without a matching `CFastLED::setX()` / `enableX()` wrapper.**
   - ❌ Bad: `fl::set_input_gamut(&profile, fl::InputGamut::Rec709);` as the documented call site
   - ✅ Good: `FastLED.setInputGamut(&profile, fl::InputGamut::Rec709);` (god instance), with a `fl::set_input_gamut(...)` free function backing it
2. ✅ **The wrapper is a `inline` one-liner that delegates** — no logic, no validation, no error handling. The free function holds all behavior.
3. ✅ **Per-object configuration (e.g. one strip's diode profile, one controller's correction) MAY live on the per-object API.** This rule targets *library-wide / process-wide / default-profile* state.
4. ✅ **Documentation, examples, and PR descriptions reference the god-instance form.** The free function is an implementation detail.
5. ⚠️ **Strict for new code; transitional allowlist for legacy names only.** Every *new* public global setter under `fl::` must ship with a `CFastLED` wrapper. A small transitional allowlist (`PUBLIC_SETTINGS_GRANDFATHERED` in `ci/lint_cpp_rs/src/checkers/public_settings.rs`) exempts pre-existing bare setters (e.g. `fl::set_input_gamut` #2710, `fl::enable_rgbw_colorimetric_lut`, `fl::set_rgbww_colorimetric_profile`) until their wrappers land. Entries are removed as each name is wrapped — the goal is an empty allowlist. New additions do NOT get grandfathered.

**Check Process**:
1. For every new public function in `src/fl/**/*.h` whose name matches `^set_|^enable_|^disable_|^use_` and that mutates a static / global / namespace-scope variable, grep `src/FastLED.h` for a `CFastLED` method that delegates to it.
2. If none exists: violation — add the wrapper in the same PR.
3. Enforced by `PublicSettingsPatternChecker` in `ci/lint_cpp_rs/src/checkers/public_settings.rs`. The checker carries a shrinking `PUBLIC_SETTINGS_GRANDFATHERED` allowlist for legacy bare setters; remove a name from the list once its `CFastLED` wrapper is merged.

**Where the rule does NOT apply**:
- Helpers, constructors, factory functions — these are not setters of global state.
- Functions in `fl::` that operate on caller-owned objects without touching global state (`fl::fill_solid(span, color)`).
- Internal `fl::detail::` / anonymous-namespace functions — not public API.

## Singleton-Stored Configuration: Own by Value, Never by Borrowed Pointer

**Core Principle**: Any public `fl::set_*` API that stores a configuration profile / settings object in process-wide (or static / namespace-scope) state MUST **store by value** (copy / move) and never retain a caller-owned pointer. The parameter SHOULD be `const T&` (or `T&&`); a `const T*` parameter is permitted **only** as a signal for nullable-reset (`nullptr` means "revert to default") and only if the implementation copies the pointed-to value into a value-typed slot on non-null and clears that slot on null. Storing the raw pointer (`sActive = profile`) is always a deterministic use-after-scope bug when callers pass a stack temporary like `auto p = make_profile(); fl::set_x(&p); /* p goes out of scope */`.

**Rules**:
1. ❌ **NEVER store a borrowed pointer to a caller-owned value in a singleton.**
   - ❌ Bad:
     ```cpp
     namespace { const RgbcctProfile* sActive = nullptr; }
     void set_rgbww_colorimetric_profile(const RgbcctProfile* p) FL_NO_EXCEPT {
         sActive = p;  // caller's lifetime, BOOM if they pass a stack temporary
     }
     ```
   - ✅ Good (value semantics, preferred):
     ```cpp
     namespace { RgbcctProfile sActive = kRgbwwDefaultProfile; }
     void set_rgbww_colorimetric_profile(const RgbcctProfile& p) FL_NO_EXCEPT {
         sActive = p;  // copy, lifetime owned by library
     }
     ```
   - ✅ Good (nullable-reset exception — `const T*` allowed when null means "reset"):
     ```cpp
     namespace { RgbcctProfile sActive = kRgbwwDefaultProfile; }
     void set_rgbww_colorimetric_profile(const RgbcctProfile* p) FL_NO_EXCEPT {
         sActive = (p != nullptr) ? *p : kRgbwwDefaultProfile;  // copy on non-null, reset on null
     }
     ```
2. ✅ **Profile getters return `const T&` to the owned copy**, not a pointer that could be `nullptr`.
3. ✅ **For polymorphic configuration** (rare), use `fl::shared_ptr<T>` or `fl::unique_ptr<T>` — never a raw `const T*`.

**Rationale**: The colorimetric / power-model / driver-config setters are the only place this rule fires in the current codebase, but every one of them got a use-after-scope CodeRabbit finding (#2554, #2560, #2588, #2683, #2682) before the rule was written. The Public Settings Pattern (above) tells you *where* the setter lives (god instance); this rule tells you *how* it stores the value. The nullable-reset exception above accommodates the established `set_rgbww_colorimetric_profile(const T*)` shape — pointer parameter, value-typed storage — which is correct and idiomatic for "pass nullptr to revert."

**Check Process**:
1. For each `fl::set_*` setter that stores into a static / namespace-scope variable, verify the **storage** is value-typed (`T`, not `const T*`).
2. If the parameter is `const T*` AND the storage is `const T*`, flag as HIGH severity (pointer storage = use-after-scope).
3. If the parameter is `const T*` but the storage is `T` and the body copies on non-null + resets on null, that's the allowed nullable-reset shape — no violation.

## Long-Lived Pointers Are `fl::shared_ptr` (Lifetime Must Be Owned, Not Assumed)

**Core Principle**: A pointer that is **stored**, or **held across anything that could free its target**, MUST be an `fl::shared_ptr<T>` reference that its holder owns. It must never be a raw `T*` or a `.get()` taken from someone else's `unique_ptr`. Then the memory cannot be freed out from under a reader that is still using it. The owner only drops *its* reference; the reader keeps the object alive until it lets go.

**"Long-lived" means any of these:**
- stored in a member, a static, a singleton, a queue, or a callback/closure;
- held across an async boundary: a driver or DMA callback, an ISR, another task or core, `fl::task`, a deferred or queued job;
- held across a call that can reconfigure or destroy the owner, such as `applyConfig`, `setColorProfile`, `clear*`, or removing a channel or controller;
- returned from a virtual or public accessor, where the caller decides how long to keep it.

**Rules**:
1. ✅ **Owners hold `fl::shared_ptr<T>`** (built with `fl::make_shared`). An owner that replaces or clears its object resets *its* pointer and nothing else.
2. ✅ **A reader takes its own `fl::shared_ptr<T>` copy for as long as it uses the object**. Examples: a frame encode, a power-estimate pass, an async transmission. A local `const fl::shared_ptr<T> ref = mThing;` at the top of the scope is the idiom.
3. ✅ **Accessors that hand out a long-lived object return `fl::shared_ptr<T>`**, not `T*`.
4. ✅ **Allowed exception: a raw pointer or reference in synchronous code where you can *prove* the target outlives the use.** Examples:
   - a function parameter `const T&` that the callee does not store;
   - `ref.get()` passed down a call chain while the caller's `shared_ptr` `ref` is still in scope;
   - a pointer into an object whose owner is on the same stack frame and cannot be reconfigured during the call.

   If the proof depends on "nothing else runs meanwhile", and anything in the call could reconfigure the owner, the exception does not apply.
5. ❌ **NEVER store `unique_ptr::get()` or a raw `T*` to an object someone else can reset**, and never return one from a virtual.
6. **Zero cost on small-memory targets.** Small means the tiny and low tiers, i.e. `!FL_PLATFORM_HAS_LARGE_MEMORY`: AVR Uno/Nano, ATtiny, ESP8266, Teensy LC/3.x, STM32F1 and similar.
   - Put the `shared_ptr` storage, the per-use reference and any virtual accessor behind a feature gate that is off there. The colour pipeline's gate is `FL_COLOR_PIPELINE_SHARED` (`src/fl/channels/options.h`).
   - Those tiers have no async show, so they keep single ownership (`unique_ptr`) with sync-only readers (rule 4) and pay neither RAM nor flash: no vtable slot, no control block.
   - Verify with `bash compile uno --examples Blink`: flash and RAM must match master byte for byte.

**Example (#4440):**
```cpp
// Owner (large-memory tiers; small tiers keep unique_ptr + sync-only readers)
using ColorPipelineStorage = fl::shared_ptr<StreamingPipelineQ16>;   // was unique_ptr
mPipeline = fl::make_shared<StreamingPipelineQ16>(pipeline);          // reconcile replaces it

// Reader: holds its own reference for the whole encode
const ColorPipelineStorage pipeline_ref = mPipeline;
encode(pipeline_ref.get());   // OK: raw pointer below a live shared_ptr (rule 4)

// Accessor: callers own what they get; compiled out on small tiers
#if FL_COLOR_PIPELINE_SHARED
virtual fl::shared_ptr<StreamingPipelineQ16> colorPipeline() const FL_NO_EXCEPT;
#endif
```

**Why**: before #4440, `Channel` owned its colour pipeline through a `unique_ptr`. It handed raw `.get()` pointers to the frame encode and the power estimate, and `reconcileColorProfile()` began with `mPipeline.reset()`. Any reconfiguration while a reader was in flight freed the pipeline underneath it. A reader holding a raw pointer has no way to keep its target alive; a reader holding a `shared_ptr` does by construction.

**Check Process**:
1. For every new member, static, or queued field of pointer type, ask who can free the target. If it is anyone but the holder, it must be `fl::shared_ptr`.
2. For every `.get()` whose result outlives the statement, confirm that a `shared_ptr` owned by the same scope is alive for the whole use.
3. For every accessor or virtual returning `T*` to a heap object, change it to return `fl::shared_ptr<T>` unless rule 4 provably applies to every caller.

## In-Place Profile Mutation Bumps a Version (Cache Invalidation Contract)

**Core Principle**: If `set_X(T* obj, ...)` writes into the fields of a caller-owned `*obj`, and any subsystem caches values *derived from* `*obj` keyed only on `(obj_ptr, ...)`, then the setter MUST bump `obj->mCacheVersion` (or call `obj->invalidate()`) and the cache key MUST include that version. Otherwise the cache returns stale data the next time the same pointer is passed in.

**Rules**:
1. ❌ **NEVER mutate a profile field in place without bumping a version counter** when a cache exists keyed on the profile pointer.
   - ❌ Bad:
     ```cpp
     void set_input_gamut(DiodeProfile* p, InputGamut g) FL_NO_EXCEPT {
         apply_gamut(p, g);  // rewrites p->input_xy_*
         // …no version bump; ProfileCache keyed on (p, cct) still returns stale M_src
     }
     ```
   - ✅ Good:
     ```cpp
     void set_input_gamut(DiodeProfile* p, InputGamut g) FL_NO_EXCEPT {
         apply_gamut(p, g);
         ++p->mCacheVersion;  // forces any derived-value cache to rebuild
     }
     // and:
     struct CacheKey { const DiodeProfile* p; u32 version; int cct; };
     ```
2. ✅ **Document the cache-invalidation contract** in the setter's doxygen: "Mutates `*p` in place; bumps `p->mCacheVersion` so derived caches rebuild on next access."
3. ✅ **Prefer immutable profiles when possible.** A `DiodeProfile` that ships as `const` to all consumers and is replaced wholesale (`set_profile(const T&)`) eliminates this entire class of bug — see Singleton-Stored Configuration rule above.

**Rationale**: Drove four CodeRabbit findings in the survey window (#2554, #2589, #2707, #2711) and is the root cause of the colorimetric "looks right in tests but stale in production" class. Tests typically construct one profile per test case so the cache never hits — the bug only shows up in real applications that mutate one shared profile across frames.

**Check Process**:
1. For each `fl::set_*(T* obj, ...)` where the body mutates `*obj`, search the codebase for a cache keyed on `obj` (typical names: `ProfileCache`, `kCache`, `sCachedDerived`).
2. If a cache exists and the setter doesn't bump a version field, flag as HIGH severity.

## Contract Change Fanout (API Surface Changes Touch All Layers in One PR)

**Core Principle**: When a PR changes a numeric bound, enum range, struct shape, or semantic of a public API surface, it MUST update **every** consumer of that contract in the same PR: (a) the producer / setter, (b) the validator, (c) unit tests, (d) docs (`agents/docs/*`, AutoResearch JSON-RPC reference, RPC handlers), and (e) any matching debug-metrics / stats struct. Partial sweeps cause silent producer/consumer skew.

**Rules**:
1. ❌ **NEVER widen a bound without sweeping the validator and tests.**
   - ❌ Bad: `examples/AutoResearch/AutoResearchRemote.cpp` bumps `laneSizes` max from 8 to 16, but `src/fl/channels/validation.cpp.hpp` still rejects > 8 — silent rejection at runtime.
   - ✅ Good: Same PR updates the example, the validator, the test fixture asserting the new max, and the JSON-RPC schema doc.
2. ❌ **NEVER add a struct field without updating the debug-metrics dump and the parser.**
3. ❌ **NEVER change `available()` / `empty()` / `size()` semantics without updating the docstring AND every caller that compares against constants.**

**Rationale**: This is a broadening of the existing "API Unit Change" rule (which was scoped to `_ms` / `_us` / `_bytes` suffixes). The recurring CodeRabbit pattern (#2621, #2648, #2669, #2682) is more general — any **contract** change, not just unit changes, needs the same fanout.

**Check Process** (PR-level):
1. If the diff modifies a public setter, enum, struct field, or named constant that defines a contract — grep for the contract name across `src/`, `examples/`, `tests/`, and `agents/docs/`.
2. If any consumer doesn't appear in the diff, either update it in the same PR or document why it doesn't need updating (with a comment in the PR description).

## `fl::span` for Callback Typedefs and Small Fixed-Size Arrays

**Core Principle**: The general `fl::span` rule (above) covers function parameters but is repeatedly missed for two specific shapes: (a) `fl::function<...>` callback / handler typedefs, and (b) small fixed-size array parameters like `const float xy[2]`. These slip through because they don't look like the canonical `void f(const u8*, size_t)` pattern.

**Rules**:
1. ❌ **NEVER declare a callback typedef with a `(ptr, size)` shape.**
   - ❌ Bad: `using write_bytes_handler_t = fl::function<size_t(const u8*, size_t)>;`
   - ✅ Good: `using write_bytes_handler_t = fl::function<size_t(fl::span<const u8>)>;`
2. ❌ **NEVER take small fixed-size arrays as raw pointers.**
   - ❌ Bad: `void set_input_gamut(DiodeProfile* p, InputGamut g, const float white_xy[2]);`
   - ✅ Good: `void set_input_gamut(DiodeProfile* p, InputGamut g, fl::span<const float, 2> white_xy);`
   - ✅ Good (alternative — by-value pair): `void set_white_point(DiodeProfile* p, fl::vec2f white_xy);`
3. ❌ **NEVER use function parameter array spelling (`T value[N]` or `T value[]`).**
   - C++ adjusts these to `T* value`; the extent is not part of the function type and is not enforced.
   - ❌ Bad: `void cct_to_xy(int cct, float out[2]);`
   - ❌ Bad: `void encode(fl::u8 output[4]);`
   - ✅ Good for normal APIs: `void cct_to_xy(int cct, fl::span<float, 2> out);`
   - ✅ Good for ISR / `FL_IRAM` APIs: `void encode(fl::u8 (&output)[4]);`
   - ✅ Good where a wrapper type would obscure the domain: `void set_white_point(DiodeProfile* p, fl::vec2f white_xy);`
   - Suppress only intentional C ABI or platform compatibility cases with `// ok array parameter`.
4. ⚠️ **For ISR / `FL_IRAM` callgraphs, prefer array references over `fl::span<T, N>`.**
   - `fl::span<T, N>` is the right general API shape, but current span accessors are not explicitly `FASTLED_FORCE_INLINE` / `FL_IRAM`. Until an explicitly ISR-safe span exists, ISR-facing fixed-size output buffers should use `T (&value)[N]`.
5. ✅ **For RGBW / RGBWW multi-channel output**, prefer a `fl::span<u8, 4>` (or `5`) over five separate `u8*` parameters, except inside ISR / `FL_IRAM` callgraphs where `u8 (&out)[4]` / `[5]` is preferred.

**Scoped exception — deferred legacy migrations**: A `(ptr, size)` callback typedef MAY be temporarily retained in a legacy layer when migrating it would force a synchronized rewrite of every caller and the migration is being deferred to a follow-up PR. The exception requires (a) a comment at the typedef site referencing the migration plan / tracking issue, (b) naming the legacy location (current example: `src/fl/stl/cstdio.h` retains raw pointer+length handler signatures intentionally), and (c) the exception is timeboxed — it must be revisited at the next layer-wide migration window. Permanent divergence is not permitted; the goal is "all-or-nothing per-layer sweep when the engineering budget allows."

**Rationale**: The base span rule prevents most of the pattern but CodeRabbit caught these two shapes in #2560, #2683, #2711. Issue #3233 adds clang-query lint coverage for source-spelled array parameters because `T value[N]` is especially misleading: it looks fixed-size but compiles as a pointer. The scoped exception accommodates the real-world case where touching every caller in one PR isn't tractable; without it the rule pushes engineers toward unprincipled mixed APIs.

## ISR-Shared State: `fl::atomic` or Critical Section, Never Bare `volatile`

**Core Principle**: Any field that is **written from an ISR callback context and read from task context** (or vice versa), or **written from two task contexts** without other locking, MUST be either an `fl::atomic<T>` with explicit `memory_order`, or guarded by `portENTER_CRITICAL_ISR/portEXIT_CRITICAL_ISR` (ISR side) and `portENTER_CRITICAL/portEXIT_CRITICAL` (task side). Plain `volatile` only prevents the compiler from caching the load — it does NOT provide atomicity, ordering, or visibility across cores.

**Rules**:
1. ❌ **NEVER use `int` / `bool` / `volatile int` for state shared with an ISR.**
   - ❌ Bad:
     ```cpp
     volatile int mPendingTransmits = 0;
     // ISR: --mPendingTransmits;          (not atomic on dual-core, no ordering)
     // task: while (mPendingTransmits) {} (no acquire fence)
     ```
   - ✅ Good (atomic):
     ```cpp
     fl::atomic<int> mPendingTransmits{0};
     // ISR: mPendingTransmits.fetch_sub(1, fl::memory_order_release);
     // task: while (mPendingTransmits.load(fl::memory_order_acquire) > 0) {}
     ```
   - ✅ Good (critical section, when the state is more complex than a single word):
     ```cpp
     // ISR side:
     portENTER_CRITICAL_ISR(&mLock);
     mTransmitting = false;
     mNextDescriptor = next;
     portEXIT_CRITICAL_ISR(&mLock);
     // task side:
     portENTER_CRITICAL(&mLock);
     bool tx = mTransmitting;
     portEXIT_CRITICAL(&mLock);
     ```
2. ❌ **NEVER use `std::atomic<T>`** — FastLED targets AVR / older embedded toolchains that don't have `<atomic>`. Use `fl::atomic<T>` from `fl/stl/atomic.h`. (See the project-wide rule: prefer `fl::` over `std::` except for low-level metaprogramming traits.)
3. ❌ **NEVER clear an ISR-shared flag in task context before all in-flight ISR work has drained.**
   - This is the underrun-race pattern — clearing `mTransmitting = false` in `refill()` while a chunk-done ISR is still pending corrupts the next frame's state.

**Rationale**: ESP32 / RP2040 / dual-core MCUs make this a hardware-correctness issue, not just a style preference. Caught only twice in the survey window (#2682, #2703), but both were high-severity races that would have shipped without manual review.

**Check Process**:
1. For each field declared in a class that has an `IRAM_ATTR` callback or `static void IRAM_ATTR on_*` ISR, verify it's either `fl::atomic<T>` or guarded by a `portMUX_TYPE` critical section.
2. Plain `volatile` on these fields is a violation.

## Unsigned Narrowing Cast Must Clamp

**Core Principle**: When summing channel values, brightness contributions, or any per-element accumulator whose total may exceed the destination type's max, you MUST clamp **before** the narrowing cast. `static_cast<u8>(x)` silently wraps at 256, which is defined behavior in C++ but almost always the wrong behavior.

**Rules**:
1. ❌ **NEVER `static_cast<u8>` a value that can exceed 255.**
   - ❌ Bad:
     ```cpp
     u32 total_mW = red_mW + (white_mW + warm_white_mW) / 3;
     u8 byte = static_cast<u8>(total_mW);  // wraps if total > 255
     ```
   - ✅ Good:
     ```cpp
     u32 total_mW = red_mW + (white_mW + warm_white_mW) / 3;
     u8 byte = static_cast<u8>(fl::min<u32>(255u, total_mW));
     ```
   - ✅ Good (saturating addition helper):
     ```cpp
     u8 byte = fl::qadd8(red_byte, white_byte);  // saturates at 255
     ```
2. ✅ **The same rule applies to `u16` narrowing** — `static_cast<u16>(x)` where `x` is `u32` and the source can exceed 65535 must clamp first.
3. ✅ **Pure narrowing for known-in-range values is fine** — e.g. `u8 byte = static_cast<u8>(rgb.r);` when `rgb.r` is already a `u8` typed via a different value path. The rule fires when there's been arithmetic that can overflow the destination type.

**Rationale**: Sibling to the existing "Signed Integer Overflow (UB)" rule. Unsigned wrap is *defined* but produces silently-wrong color / power / brightness values. The signed-UB rule (above) does NOT catch this — `u8 + u16 → wrap` is fine according to the standard but is the bug pattern flagged twice in #2560 (first review ignored, second review re-flagged).

## Test Mirrors Must Call Production Symbols, Not Redeclare Them

**Core Principle**: When `tests/fl/foo/test_bar.cpp` mirrors part of `src/fl/foo/bar.cpp.hpp` (e.g. to verify mathematical identities like Hermite-basis sum = 1), the test MUST call the production symbol directly. Re-declaring the algorithm as a local lambda or helper inside the test file means the test passes regardless of bugs introduced into the production implementation.

**Rules**:
1. ❌ **NEVER redefine a production algorithm inside a test file just to assert properties of it.**
   - ❌ Bad:
     ```cpp
     // tests/fl/gfx/rgbw_colorimetric.cpp
     FL_TEST_CASE("hermite basis sums to 1") {
         auto h0 = [](float t) { return (1 - t)*(1 - t)*(1 + 2*t); };
         auto h1 = [](float t) { return t*t*(3 - 2*t); };
         // …asserts h0(t) + h1(t) == 1. Production hermite_basis is never called.
     }
     ```
   - ✅ Good:
     ```cpp
     #include "fl/gfx/rgbw_colorimetric.h"
     FL_TEST_CASE("hermite basis sums to 1") {
         float out[2];
         fl::gfx::hermite_basis(0.5f, out);
         FL_CHECK_CLOSE(out[0] + out[1], 1.0f, 1e-6f);
     }
     ```
2. ✅ **Mirror files are allowed only when test is verifying byte-for-byte text equivalence** of two sources (e.g. a port from Python reference). In that case the mirror must be obvious from the file name (e.g. `*_mirror_for_test.cpp.hpp`) and a static_assert / runtime check must compare the mirror's output against the production output on a sample input.
3. ✅ **Header-only `inline` algorithms** can be tested by calling the production header directly — there's no link concern.

**Rationale**: Caught in #2683, #2707, #2709. The bug pattern: a future regression in the production implementation (e.g. someone swaps the sign of a Hermite coefficient) passes all tests because the tests verify a local copy of the *correct* algorithm. The production code can silently drift.

## ASCII-Only in Source Files (No Emoji, No Unicode Math Glyphs)

**Core Principle**: Every C++ source file (`.h`, `.cpp`, `.hpp`, `.cpp.hpp`) and every Python source file in this repo MUST contain only 7-bit ASCII. No emoji in comments, no Unicode math symbols in identifiers or print statements, no curly-quote characters from copy/pasted documentation.

**Rules**:
1. ❌ **NEVER use emoji in C++ comments.**
   - ❌ Bad: `// ⚠️ This runs in ISR context — keep it short`
   - ✅ Good: `// WARNING: This runs in ISR context — keep it short`
2. ❌ **NEVER use Unicode math glyphs in source code.**
   - ❌ Bad (Python): `print("FastLED − Reference")`, `ρ = 0.5`, `Δ = abs(a - b)`
   - ✅ Good (Python): `print("FastLED - Reference")`, `rho = 0.5`, `delta = abs(a - b)`
3. ❌ **NEVER paste curly quotes / em-dashes from documentation tools.** Replace `"smart quotes"` with `"straight quotes"`, `—` with `-` or `--`.
4. ✅ **Markdown documentation files (`*.md`) are exempt** — Unicode in human-reading docs is fine. This rule is for code only.

**Rationale**: Source files are read by lots of tools (compilers, linters, AVR / RP2040 / Teensy toolchains with various Unicode story, terminal log dumps, grep, IDE search). Some toolchains choke; others render the glyphs as garbage in compile errors. Pure ASCII keeps the source legible in every context. Flagged in #2648 (C++ comments with emoji) and #2709 (Python with `×`, `−`, `ρ`, `∆`).

**Check Process**:
1. Run `grep -rPn '[^\x00-\x7F]' src/ tests/ ci/` (excluding `*.md`).
2. Any hits are violations.
3. Suppression: none — there is always an ASCII equivalent.
