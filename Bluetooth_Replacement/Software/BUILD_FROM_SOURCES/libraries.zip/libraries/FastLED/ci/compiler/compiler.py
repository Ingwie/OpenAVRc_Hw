#!/usr/bin/env python3
"""
Abstract Base Class for FastLED Compilers

Defines the interface that all FastLED compiler implementations must follow.
"""

from abc import ABC, abstractmethod
from concurrent.futures import Future
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class CompilerResult:
    """Base result class for compiler operations."""

    success: bool
    output: str
    build_dir: Path


@dataclass
class InitResult(CompilerResult):
    """Result from compiler initialization."""

    sketch_build_defines: list[str] = field(default_factory=list)

    @property
    def project_ini(self) -> Path:
        return self.build_dir / "platformio.ini"


@dataclass
class SketchResult(CompilerResult):
    """Result from sketch compilation."""

    example: str


class Compiler(ABC):
    """Abstract base class defining the interface for FastLED compilers."""

    def __init__(self) -> None:
        """Initialize the compiler."""
        pass

    @abstractmethod
    def build(
        self, examples: list[str], max_failures: int | None = None
    ) -> list[Future[SketchResult]]:
        """Build a list of examples with proper resource management.

        Args:
            examples: List of example names or paths to compile
            max_failures: Stop building further examples once this many have
                failed. None builds every example.

        Returns:
            List of Future objects containing SketchResult for each example
            that was attempted
        """
        pass

    @abstractmethod
    def clean(self) -> None:
        """Clean build artifacts for this platform."""
        pass

    @abstractmethod
    def clean_all(self) -> None:
        """Clean all build artifacts (local and global) for this platform."""
        pass

    @abstractmethod
    def deploy(
        self, example: str, upload_port: Optional[str] = None, monitor: bool = False
    ) -> SketchResult:
        """Deploy (upload) a specific example to the target device.

        Args:
            example: Name of the example to deploy
            upload_port: Optional specific port for upload
            monitor: If True, attach to device monitor after successful upload

        Returns:
            SketchResult indicating success/failure of deployment
        """
        pass

    @abstractmethod
    def cancel_all(self) -> None:
        """Cancel all currently running builds."""
        pass
