from ci.util.global_interrupt_handler import handle_keyboard_interrupt


#!/usr/bin/env python3
"""
Wrapper script for PCH compilation that fixes dependency file generation
and implements input-hash caching to avoid unnecessary mass rebuilds.

Problem 1: When compiling a PCH with `-MD -MF`, the compiler generates a depfile
that references a temporary .obj file in the compiler cache, not the PCH output file.
This causes Ninja to ignore the depfile and always rebuild the PCH.

Solution 1: After compilation, rewrite the depfile to reference the actual PCH
output file instead of the temporary object file.

Problem 2: Rebuilding the PCH triggers recompilation of ALL test DLLs (246+),
even when the PCH content is semantically unchanged (e.g., only a comment or
whitespace changed in a header). Clang PCH output is non-deterministic (embeds
timestamps), so output-hash comparison doesn't work.

Solution 2: Hash all input files listed in the saved depfile from the previous
build. If the input hash matches, skip compilation entirely. The ninja rule uses
`restat = 1`, so unchanged output triggers no downstream rebuilds. The depfile
is saved as `.d.cache` since ninja deletes the original after reading it.
All PCH producers and consumers run through zccache, which supplies private
header snapshots with the timestamps the PCH recorded. Shared source files
are never modified; real content or compiler flag changes rebuild the PCH.

Usage:
    python compile_pch.py <compiler> <args...>

The script expects:
    - '-o' flag followed by the PCH output path
    - '-MF' flag followed by the depfile path
"""

import hashlib
import re
import shutil
import sys
from pathlib import Path

from running_process import RunningProcess


def _find_depfile_separator(content: str) -> int:
    """Find the index of the target:dependency separator colon in depfile content.

    On Windows, paths contain drive-letter colons (e.g. ``C:\\path``).  A drive
    letter colon is a single alpha character immediately before the colon, at
    the start of a path token (position 0, or preceded by a non-alphanumeric
    such as a space).  We skip those and return the first ``": "`` that is NOT
    a drive-letter colon.

    Returns the index of the ``':'`` character, or ``-1`` if not found.
    """
    idx = 0
    while True:
        space_idx = content.find(": ", idx)
        if space_idx == -1:
            return -1

        # A Windows drive letter looks like  X:  where X is a single alpha
        # character at the start of a token (pos 0 or preceded by whitespace /
        # non-alphanumeric).
        if space_idx > 0:
            char_before = content[space_idx - 1]
            if char_before.isalpha() and (
                space_idx == 1 or not content[space_idx - 2].isalnum()
            ):
                # Looks like a drive letter — skip it.
                idx = space_idx + 1
                continue

        return space_idx


def fix_depfile(depfile_path: Path, pch_output_path: Path) -> None:
    r"""
    Rewrite the depfile to reference the PCH output instead of temporary obj file.

    The compiler-generated depfile has format:
        C:\path\to\temp.obj: \
          dep1.h \
          dep2.h

    We need to change it to:
        tests/output.pch: \
          dep1.h \
          dep2.h

    Args:
        depfile_path: Path to the .d dependency file
        pch_output_path: Path to the .pch output file
    """
    if not depfile_path.exists():
        return

    content = depfile_path.read_text(encoding="utf-8")
    separator_idx = _find_depfile_separator(content)

    if separator_idx == -1:
        return

    # Everything after the separator (including ": ") is the dependencies
    deps_str = content[separator_idx + 2 :]

    # Parse individual dependency paths
    dep_paths = _tokenize_depfile_deps(deps_str)

    # Normalize paths to absolute, then to forward slashes for Ninja compatibility.
    # The depfile may contain relative paths from where the compiler was invoked
    # (typically the project root), which need to be resolved to absolute paths before
    # normalization. This ensures the hash checking code can find the files.
    pch_output_str = Path(pch_output_path).as_posix()
    normalized_deps = []

    for p in dep_paths:
        path_obj = Path(p)
        # If the path is relative, resolve it relative to the current working directory
        # (which is the project root when Meson runs the compile_pch command)
        if not path_obj.is_absolute():
            path_obj = path_obj.resolve()
        # Convert to forward slashes and use the string representation
        normalized_deps.append(path_obj.as_posix())

    # Rebuild depfile in Make format
    # Escape spaces in paths for Make syntax
    escaped_deps = [d.replace(" ", "\\ ") for d in normalized_deps]
    new_content = pch_output_str + ": \\\n  " + " \\\n  ".join(escaped_deps) + "\n"

    depfile_path.write_text(new_content, encoding="utf-8")


def _tokenize_depfile_deps(deps_str: str) -> list[str]:
    r"""Tokenize the dependency portion of a Make-format depfile.

    Handles:
    - ``\<newline>`` line continuations (removed)
    - ``\ `` escaped spaces within paths (preserved as literal space)
    - Regular whitespace as token delimiters
    """
    # Remove line continuations first
    deps_str = deps_str.replace("\\\r\n", " ").replace("\\\n", " ")

    tokens: list[str] = []
    current: list[str] = []
    i = 0
    while i < len(deps_str):
        ch = deps_str[i]
        if ch == "\\" and i + 1 < len(deps_str) and deps_str[i + 1] == " ":
            # Escaped space — part of the current path token
            current.append(" ")
            i += 2
        elif ch in (" ", "\t", "\n", "\r"):
            # Unescaped whitespace — token delimiter
            if current:
                tokens.append("".join(current))
                current = []
            i += 1
        else:
            current.append(ch)
            i += 1
    if current:
        tokens.append("".join(current))
    return tokens


def parse_depfile_inputs(depfile_path: Path) -> list[Path]:
    """Parse the depfile and return a list of dependency file paths."""
    if not depfile_path.exists():
        return []

    content = depfile_path.read_text(encoding="utf-8")
    separator_idx = _find_depfile_separator(content)

    if separator_idx == -1:
        return []

    # Extract dependencies (everything after ": ")
    deps_str = content[separator_idx + 2 :]

    return [Path(t) for t in _tokenize_depfile_deps(deps_str) if t]


def hash_input_files(files: list[Path]) -> str:
    """Hash the content of all input files to detect changes.

    Always includes each file path in the hash so that different sets of
    missing files produce distinct digests (avoiding false cache hits).

    Note: compiler args are NOT included in this hash. Meson/Ninja already
    tracks compiler flag changes via build.ninja regeneration. Including
    args here caused a mismatch between compile_pch.py (which has args)
    and invalidate_stale_pch (which doesn't), making the staleness check
    always delete freshly-built PCH files.
    """
    h = hashlib.sha256()
    for f in sorted(str(p) for p in files):
        p = Path(f)
        h.update(f.encode("utf-8"))  # Always include path in hash
        if p.exists():
            h.update(b"\x01")  # sentinel: file exists
            with open(p, "rb") as fh:
                for chunk in iter(lambda: fh.read(65536), b""):
                    h.update(chunk)
        else:
            h.update(b"\x00")  # sentinel: file missing
    return h.hexdigest()


def hash_compile_flags(args: list[str]) -> str:
    """Hash the full compiler argument vector, byte for byte.

    Deliberately NOT normalized. Two spellings of the same include root --
    ``-IC:/x/src`` and ``-IC:\\x\\src`` -- must produce different digests,
    because a PCH built under one spelling cannot be reused under the other:
    clang canonicalizes header identity at PCH-build time, so the consuming
    TU re-parses headers the PCH already contains, ``#pragma once`` fails to
    dedupe, and the build dies with "redefinition of ...".

    Normalizing here would collapse exactly the difference we need to catch
    and reintroduce the stale-PCH bug this guards.

    Kept separate from :func:`hash_input_files` on purpose: that hash is also
    computed by :func:`invalidate_stale_pch`, which never sees the arguments.
    Mixing args into it made the two disagree and deleted every freshly built
    PCH.
    """
    h = hashlib.sha256()
    for arg in args:
        h.update(arg.encode("utf-8"))
        h.update(b"\x00")  # unambiguous separator: args may contain spaces
    return h.hexdigest()


def invalidate_stale_pch(pch_file: Path) -> None:
    """Delete a PCH file if its input files have changed since it was built.

    Uses the ``.d.cache`` and ``.input_hash`` files saved by previous builds
    to detect when a header dependency has been modified.  If the hash doesn't
    match, the PCH and hash file are removed so Ninja is forced to rebuild.

    This works around a Ninja limitation on Windows where backslash paths in
    depfiles can cause Ninja to miss dependency changes.
    """
    if not pch_file.exists():
        return

    saved_depfile = pch_file.with_name(pch_file.name.replace(".pch", ".d.cache"))
    hash_file = Path(str(pch_file) + ".input_hash")
    flags_file = Path(str(pch_file) + ".flags_hash")
    if not saved_depfile.exists() or not hash_file.exists() or not flags_file.exists():
        # Missing tracking files means we can't verify the PCH is fresh.
        # Delete it to force a safe rebuild rather than risking a stale-PCH
        # compiler error that would fail the entire build.
        #
        # flags_file is included so a PCH left behind by a build predating
        # flag hashing -- which may have been built under a different include
        # spelling -- is discarded rather than trusted.
        print(
            f"PCH tracking files missing — removing {pch_file.name} to force rebuild",
            file=sys.stderr,
        )
        pch_file.unlink(missing_ok=True)
        hash_file.unlink(missing_ok=True)
        flags_file.unlink(missing_ok=True)
        return

    try:
        input_files = parse_depfile_inputs(saved_depfile)
        if not input_files:
            print(
                f"PCH dependency tracking invalid — removing {pch_file.name} to force rebuild",
                file=sys.stderr,
            )
            pch_file.unlink(missing_ok=True)
            hash_file.unlink(missing_ok=True)
            return
        current_hash = hash_input_files(input_files)
        stored_hash = hash_file.read_text(encoding="utf-8").strip()
        if current_hash != stored_hash:
            print(
                f"PCH inputs changed — removing stale {pch_file.name} to force rebuild",
                file=sys.stderr,
            )
            pch_file.unlink(missing_ok=True)
            hash_file.unlink(missing_ok=True)
    except KeyboardInterrupt as ki:
        handle_keyboard_interrupt(ki)
        raise
    except Exception as e:
        print(f"WARNING: PCH staleness check failed: {e}", file=sys.stderr)


# Sidecars compile_pch.py writes next to a PCH. Removing them together with
# the .pch forces a clean rebuild of that PCH and nothing else.
PCH_SIDECAR_SUFFIXES = (
    ".pch.input_hash",
    ".pch.flags_hash",
    ".pch.inputs.json",  # Legacy local input manifest; cleanup only.
    ".pch.zccache-imports.json",
)

# The clang failure a stale PCH produces: the header is parsed a second time
# on top of the PCH copy because #pragma once no longer recognises it.
_PCH_REDEFINITION_RE = re.compile(
    r"(\S+?):\d+:\d+: error: "
    r"(?:redefinition of|template parameter redefines default argument)"
)


# Match zccache's explicit refusal, not arbitrary source text containing it.
_ZCCACHE_PCH_REBUILD_RE = re.compile(
    r"(?m)^zccache\[[^\]\r\n]+\]\[[^\]\r\n]+\]: "
    r"[^\r\n]*PCH input validation failed; rebuild the PCH: ([^\r\n]+)"
)


def pch_input_headers(build_dir: Path) -> set[Path]:
    """Every header any PCH under ``build_dir`` was built from (resolved)."""
    headers: set[Path] = set()
    for saved in build_dir.rglob("*.d.cache"):
        try:
            for dep in parse_depfile_inputs(saved):
                headers.add(dep.resolve())
        except OSError:
            continue
    return headers


def is_stale_pch_error(output: str, build_dir: Path) -> bool:
    """Recognize a Clang stale-header error or zccache refusal for this build.

    Legacy chained PCHs can lack zccache's import provenance. A content-hash
    match may preserve them across a cache upgrade, so the existing bounded
    purge/retry must also handle zccache's explicit request to rebuild.
    """
    refusals = _ZCCACHE_PCH_REBUILD_RE.findall(output)
    if refusals:
        for pch in build_dir.rglob("*.pch"):
            try:
                spellings = {str(pch), str(pch.resolve())}
            except (OSError, ValueError):
                continue
            for refusal in refusals:
                normalized = refusal.replace("\\", "/")
                if any(
                    normalized.startswith(spelling.replace("\\", "/") + ":")
                    for spelling in spellings
                ):
                    return True
    matches = _PCH_REDEFINITION_RE.findall(output)
    if not matches:
        return False
    headers = pch_input_headers(build_dir)
    for raw in matches:
        try:
            if Path(raw).resolve() in headers:
                return True
        except (OSError, ValueError):
            continue
    return False


def purge_pch_artifacts(build_dir: Path) -> int:
    """Delete every PCH under ``build_dir`` plus its sidecars. Returns the count."""
    removed = 0
    for pch in list(build_dir.rglob("*.pch")):
        targets = [pch, pch.with_name(pch.name.replace(".pch", ".d.cache"))]
        targets += [Path(str(pch) + s[len(".pch") :]) for s in PCH_SIDECAR_SUFFIXES]
        for t in targets:
            try:
                t.unlink()
                removed += 1
            except FileNotFoundError:
                continue
    return removed


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: compile_pch.py <compiler> <args...>", file=sys.stderr)
        return 1

    # Parse command line arguments to find -o and -MF flags
    args = sys.argv[1:]
    pch_output: Path | None = None
    depfile: Path | None = None

    i = 0
    while i < len(args):
        if args[i] == "-o" and i + 1 < len(args):
            pch_output = Path(args[i + 1])
            i += 2
        elif args[i] == "-MF" and i + 1 < len(args):
            depfile = Path(args[i + 1])
            i += 2
        else:
            i += 1

    # Input-hash caching: skip compilation if all input files are unchanged.
    # Ninja deletes the depfile after reading it (deps = gcc), so we use a
    # saved copy (.d.cache) from the previous successful build.
    saved_depfile = Path(str(depfile) + ".cache") if depfile else None
    hash_file = Path(str(pch_output) + ".input_hash") if pch_output else None
    flags_file = Path(str(pch_output) + ".flags_hash") if pch_output else None
    current_flags_hash = hash_compile_flags(args)
    if (
        pch_output
        and saved_depfile
        and hash_file
        and flags_file
        and pch_output.exists()
        # Only a PCH may be skipped on a hash match. wasm_build_library.py
        # also routes ordinary .o compiles through this wrapper; skipping one
        # of those would keep an object built against an older PCH.
        and pch_output.suffix == ".pch"
    ):
        if saved_depfile.exists() and hash_file.exists() and flags_file.exists():
            try:
                input_files = parse_depfile_inputs(saved_depfile)
                if input_files:
                    current_hash = hash_input_files(input_files)
                    stored_hash = hash_file.read_text(encoding="utf-8").strip()
                    stored_flags = flags_file.read_text(encoding="utf-8").strip()
                    # Both must match. The input hash alone cannot see a
                    # changed include spelling: the resolved dependency set is
                    # identical, so its digest is identical, and the PCH built
                    # under the old spelling gets reused and poisons the build.
                    if (
                        current_hash == stored_hash
                        and current_flags_hash != stored_flags
                    ):
                        print(
                            "PCH compiler flags changed - rebuilding",
                            file=sys.stderr,
                        )
                    elif current_hash == stored_hash:
                        print(
                            "PCH inputs unchanged (hash match) - skipping compilation",
                            file=sys.stderr,
                        )
                        return 0
            except KeyboardInterrupt as ki:
                handle_keyboard_interrupt(ki)
                raise
            except Exception as e:
                print(f"WARNING: PCH input hash check failed: {e}", file=sys.stderr)
                # Continue with normal compilation

    # Run the compiler
    from ci.meson.native_launchers import wrap_compiler_with_zccache

    result = RunningProcess.run(wrap_compiler_with_zccache(args), check=False)

    # Fix the depfile and save caching data if compilation succeeded
    if result.returncode == 0 and pch_output and depfile:
        try:
            fix_depfile(depfile, pch_output)
        except KeyboardInterrupt as ki:
            handle_keyboard_interrupt(ki)
            raise
        except Exception as e:
            print(f"ERROR fixing PCH depfile: {e}", file=sys.stderr)
            import traceback

            traceback.print_exc(file=sys.stderr)

        # Save depfile copy and input hash for next build's cache check
        if (
            pch_output.suffix == ".pch"
            and saved_depfile
            and hash_file
            and flags_file
            and depfile.exists()
        ):
            # Written before the input hash: if the process dies between the
            # two, the next run sees a flags sidecar with no input hash and
            # rebuilds. The reverse order would leave an input hash with no
            # flags sidecar, which is the state we treat as untrustworthy.
            flags_file.write_text(current_flags_hash, encoding="utf-8")
            try:
                shutil.copy2(str(depfile), str(saved_depfile))
                input_files = parse_depfile_inputs(saved_depfile)
                if input_files:
                    current_hash = hash_input_files(input_files)
                    hash_file.write_text(current_hash, encoding="utf-8")
            except KeyboardInterrupt as ki:
                handle_keyboard_interrupt(ki)
                raise
            except Exception:
                pass  # Non-critical: cache will be rebuilt next time

    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
