"""Build-on-change cache for the Rust ``fastled-lint`` binary.

Rebuilds the binary only when (a) it does not yet exist or (b) the Rust
crate's sources have changed since the last successful build. Otherwise the
cached binary is returned untouched, removing the per-invocation soldr/cargo
fingerprint-scan tax from the lint hot path.

Implementation notes
--------------------
The crate is small (~20 ``.rs`` files plus ``Cargo.toml``/``Cargo.lock``), so
the fingerprint is computed natively in Python with ``os.stat`` (mtime+size)
+ blake2b hashing — typically under 2ms on Windows and with no IPC/daemon
dependency. We deliberately avoid the ``zccache-fingerprint`` CLI here: that
infra is overkill for ~30 files and adds 300–800ms of broker latency on
Windows even on the cache-hit path.
"""

from __future__ import annotations

import hashlib
import os
import platform
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import cast

from running_process import RunningProcess
from running_process.command_render import list2cmdline

from ci.util.paths import PROJECT_ROOT


@dataclass(frozen=True)
class _BuildStreamResult:
    """Return type for :func:`_stream_build_cmd`.

    ``line_count`` = non-empty stdout lines observed. The soldr-shim fallback
    path in :func:`_run_build` treats ``returncode == 0`` combined with
    ``line_count == 0`` as evidence that the wrapper no-oped.
    """

    returncode: int
    line_count: int


RUST_CRATE_DIR = PROJECT_ROOT / "ci" / "lint_cpp_rs"
RUST_MANIFEST = RUST_CRATE_DIR / "Cargo.toml"
RUST_BINARY_NAME = "fastled-lint"

_FINGERPRINT_FILE = PROJECT_ROOT / ".cache" / "rust_lint_binary.fingerprint"
_FINGERPRINT_INPUTS = (
    # Discrete files (relative to PROJECT_ROOT) whose change requires a rebuild.
    # All `.rs` files under the crate's `src/` tree are picked up separately by
    # `_iter_source_files`. Add any new top-level input that affects rustc
    # output (e.g. `rust-toolchain.toml`, `build.rs`, `.cargo/config.toml`)
    # here when introduced — current crate has none of those.
    "ci/lint_cpp_rs/Cargo.toml",
    "ci/lint_cpp_rs/Cargo.lock",
    "ci/lint_cpp_rs/file_legal_policy.yaml",
    "ci/lint_cpp_rs/legacy_macro_amnesty.txt",
)
_SRC_DIR = RUST_CRATE_DIR / "src"


def _guess_host_triple() -> str | None:
    """Best-effort guess of the host's Rust target triple.

    Used to prioritize the matching ``target/<triple>/debug/`` directory
    when multiple cross-compile outputs exist. A miss is harmless — the
    function only influences ordering, never correctness.
    """
    machine = platform.machine().lower()
    arch = {
        "amd64": "x86_64",
        "x86_64": "x86_64",
        "x64": "x86_64",
        "arm64": "aarch64",
        "aarch64": "aarch64",
        "armv7l": "armv7",
    }.get(machine, machine)
    system = sys.platform
    if system == "win32":
        return f"{arch}-pc-windows-msvc"
    if system == "darwin":
        return f"{arch}-apple-darwin"
    if system.startswith("linux"):
        return f"{arch}-unknown-linux-gnu"
    return None


def _binary_candidate_paths() -> list[Path]:
    """Return candidate locations of the built fastled-lint binary.

    soldr drives cargo with ``CARGO_BUILD_TARGET`` pinned to the host triple,
    so the binary lands under ``target/<triple>/debug/`` rather than the
    plain ``target/debug/``. Ordering matters because the first existing
    candidate wins: prefer the explicitly-requested triple
    (``CARGO_BUILD_TARGET``), then the host triple, then the plain
    ``target/debug/``, then any other triple discovered on disk (sorted
    for determinism — never let directory-iteration order pick a binary
    silently on a multi-triple checkout).

    NOTE: this is the cargo ``dev`` profile, not ``release``. The lint
    binary is disk-I/O bound (it reads + parses source files); cargo dev
    runs are fast enough at runtime and cut cold-build wall time by an
    order of magnitude vs release.
    """
    suffix = ".exe" if os.name == "nt" else ""
    name = f"{RUST_BINARY_NAME}{suffix}"
    target_root = RUST_CRATE_DIR / "target"
    plain_debug = target_root / "debug" / name

    ordered: list[Path] = []
    seen: set[Path] = set()

    def _add(path: Path) -> None:
        if path not in seen:
            ordered.append(path)
            seen.add(path)

    env_target = os.environ.get("CARGO_BUILD_TARGET")
    if env_target:
        _add(target_root / env_target / "debug" / name)

    host_triple = _guess_host_triple()
    if host_triple:
        _add(target_root / host_triple / "debug" / name)

    _add(plain_debug)

    if target_root.is_dir():
        for triple_dir in sorted(target_root.iterdir(), key=lambda p: p.name):
            if not triple_dir.is_dir() or triple_dir.name == "debug":
                continue
            _add(triple_dir / "debug" / name)

    return ordered


def _binary_path() -> Path:
    """Return the path to an existing binary, or the default if none exists.

    Searches the fixed candidate list first (fast + deterministic ordering).
    If none of those exist but the binary was actually built somewhere else
    under ``target/`` (e.g. a soldr / cargo config we did not predict, a
    manually-set ``CARGO_TARGET_DIR``, or a non-standard triple that our
    ``_guess_host_triple`` heuristic missed), fall back to a recursive
    ``target/**/<name>`` walk so the "successful build but missing binary"
    RuntimeError only fires when the binary genuinely was not produced.
    """
    candidates = _binary_candidate_paths()
    for candidate in candidates:
        if candidate.exists():
            return candidate
    # Safety-net walk. Only reached on the "successful build, unknown output
    # location" path; cost is bounded by target/ size and only paid on the
    # slow path.
    suffix = ".exe" if os.name == "nt" else ""
    name = f"{RUST_BINARY_NAME}{suffix}"
    target_root = RUST_CRATE_DIR / "target"
    if target_root.is_dir():
        for hit in target_root.rglob(name):
            if hit.is_file():
                return hit
    return candidates[0]


def _iter_source_files() -> list[Path]:
    """Enumerate every Rust source file plus the discrete top-level inputs."""
    files: list[Path] = []
    if _SRC_DIR.is_dir():
        for path in _SRC_DIR.rglob("*.rs"):
            if path.is_file():
                files.append(path)
    for relative in _FINGERPRINT_INPUTS:
        candidate = PROJECT_ROOT / relative
        if candidate.is_file():
            files.append(candidate)
    files.sort()
    return files


def _compute_fingerprint() -> str:
    """Hash the (path, size, mtime_ns) of every fingerprint input.

    This is content-agnostic but very fast: ~20 ``os.stat`` calls. If any
    file is added, removed, or rewritten the digest changes.
    """
    hasher = hashlib.blake2b(digest_size=16)
    for path in _iter_source_files():
        st = path.stat()
        # Use the project-relative path so the fingerprint is stable across
        # checkouts in different locations.
        relative = path.resolve().relative_to(PROJECT_ROOT)
        hasher.update(str(relative).replace("\\", "/").encode("utf-8"))
        hasher.update(b"\0")
        hasher.update(str(st.st_size).encode("ascii"))
        hasher.update(b"\0")
        hasher.update(str(st.st_mtime_ns).encode("ascii"))
        hasher.update(b"\0")
    return hasher.hexdigest()


def _load_cached_fingerprint() -> str | None:
    try:
        return _FINGERPRINT_FILE.read_text(encoding="utf-8").strip() or None
    except FileNotFoundError:
        return None
    except OSError:
        return None


def _store_fingerprint(value: str) -> None:
    try:
        _FINGERPRINT_FILE.parent.mkdir(parents=True, exist_ok=True)
        # Atomic write: tmp file under the same dir, then os.replace. Prevents
        # a concurrent invocation (e.g. Stop hook racing manual `bash lint`)
        # from observing a torn read mid-write on Windows.
        tmp_path = _FINGERPRINT_FILE.with_suffix(_FINGERPRINT_FILE.suffix + ".tmp")
        tmp_path.write_text(value, encoding="utf-8")
        os.replace(tmp_path, _FINGERPRINT_FILE)
    except OSError as exc:
        print(
            f"warning: failed to persist Rust lint fingerprint to {_FINGERPRINT_FILE}: {exc}",
            file=sys.stderr,
        )


def _resolve_soldr() -> str:
    """Return the soldr executable path or raise if it is not installed."""
    soldr = shutil.which("soldr")
    if soldr is None:
        raise RuntimeError(
            "soldr not found on PATH — install via `uv sync` (soldr is pinned in "
            "pyproject.toml). soldr is required to build the Rust C++ linter."
        )
    return soldr


def _stream_build_cmd(cmd: list[str], label: str, verbose: bool) -> _BuildStreamResult:
    """Run ``cmd`` under Popen, prefix-stream its stdout, return the result.

    See :class:`_BuildStreamResult` for the returned fields and the reason
    ``line_count`` is exposed (soldr-shim fallback detection).
    """
    if verbose:
        print(
            f"    cwd: {PROJECT_ROOT}",
            file=sys.stderr,
            flush=True,
        )
        print(
            f"    cmd: {list2cmdline(cmd)}",
            file=sys.stderr,
            flush=True,
        )
    # capture=True with stderr left at its default merges stderr into the
    # combined stream, so line_iter() yields cargo's stdout and stderr in
    # arrival order.
    proc = RunningProcess(
        cmd,
        cwd=PROJECT_ROOT,
        capture=True,
        encoding="utf-8",
        errors="replace",
    )
    prefix = f"    [{label}] "
    line_count = 0
    for line in proc.line_iter(timeout=None):
        stripped = line.rstrip()
        if stripped:
            line_count += 1
        # Preserve the raw line (cargo emits progress bars via \r; strip
        # trailing whitespace only, don't collapse internal spacing).
        print(f"{prefix}{stripped}", file=sys.stderr, flush=True)
    returncode = cast(int, proc.wait())
    return _BuildStreamResult(returncode=returncode, line_count=line_count)


def _run_build(verbose: bool = True) -> None:
    """Invoke ``soldr cargo build`` for the fastled-lint binary.

    Uses the cargo ``dev`` profile (no ``--release``). The lint binary
    is disk-I/O bound; release-mode codegen does not measurably speed up
    runtime but costs ~10x cold-build wall time vs dev. The wrapper-level
    ``--no-cache`` avoids soldr/zccache protocol drift on hosted runners; the
    built binary is already cached separately by this module and CI.

    Streaming implementation
    ------------------------
    Uses a streaming ``RunningProcess`` (stderr merged into stdout) and a
    line-by-line reader loop so cargo output reaches ``sys.stderr`` as it
    is produced. This matters when the build is invoked from inside a
    ``concurrent.futures.ThreadPoolExecutor`` (as ``run_all_checkers.py``
    does): earlier code used a blocking run with inherited handles,
    but when the parent's stdout/stderr are indirectly captured (test
    runners, logging wrappers, CI harnesses), cargo's diagnostics
    disappear. The explicit stream + prefix makes every cargo line
    identifiable and visible even under those layers.

    Broken-shim fallback
    --------------------
    soldr 0.7.87 (current PyPI head) ships as a ~118 KB Windows shim that,
    on cold runners, exits 0 without invoking cargo or producing any
    stdout — see the empty ``[cargo]`` prefix stream in FastLED CI unit
    tests on windows-latest. When we detect that signature (rc == 0 AND
    zero output lines AND binary not produced), fall back to invoking
    ``cargo build`` directly. This loses soldr's cache assist but keeps
    lint functional; the outer binary-cache layer still avoids re-building
    on unchanged crate sources.
    """
    cargo_args = [
        "build",
        "--manifest-path",
        str(RUST_MANIFEST),
        "--bin",
        RUST_BINARY_NAME,
    ]

    if verbose:
        print(
            f"🔨 Building Rust C++ linter ({RUST_BINARY_NAME}) — this runs once "
            "until the crate sources change.",
            file=sys.stderr,
            flush=True,
        )

    soldr = _resolve_soldr()
    soldr_cmd = [soldr, "--no-cache", "cargo", *cargo_args]
    result = _stream_build_cmd(soldr_cmd, "cargo", verbose)

    if (
        result.returncode == 0
        and result.line_count == 0
        and not _binary_path().exists()
    ):
        # soldr shim exited 0 without invoking cargo. Fall back to bare
        # cargo so lint keeps working while soldr's Windows-shim regression
        # is being worked upstream.
        print(
            "    ⚠  soldr shim exited 0 with no cargo output and no binary "
            "produced — falling back to bare `cargo build`.",
            file=sys.stderr,
            flush=True,
        )
        cargo_cmd = ["cargo", *cargo_args]
        result = _stream_build_cmd(cargo_cmd, "cargo", verbose)

    if result.returncode != 0:
        raise RuntimeError(
            f"Rust C++ linter build failed (exit {result.returncode}); see "
            f"[cargo] lines above for the underlying error."
        )


def ensure_rust_lint_binary(verbose: bool = True) -> Path:
    """Return a path to a fresh ``fastled-lint`` binary.

    Rebuilds the binary if it does not yet exist or if the cached fingerprint
    over the crate's sources is stale. Otherwise the cached binary is returned
    without invoking soldr/cargo at all.
    """
    binary = _binary_path()
    current_fingerprint = _compute_fingerprint()
    cached_fingerprint = _load_cached_fingerprint()

    needs_rebuild = not binary.exists() or cached_fingerprint != current_fingerprint
    if needs_rebuild:
        _run_build(verbose=verbose)
        binary = _binary_path()
        # Recompute after the build so the persisted fingerprint reflects any
        # generated/touched files that participate in the input set.
        _store_fingerprint(_compute_fingerprint())

    if not binary.exists():
        target_root = RUST_CRATE_DIR / "target"
        actually_present = []
        if target_root.is_dir():
            suffix = ".exe" if os.name == "nt" else ""
            name = f"{RUST_BINARY_NAME}{suffix}"
            actually_present = sorted(
                str(p) for p in target_root.rglob(name) if p.is_file()
            )
        raise RuntimeError(
            "Rust C++ linter binary missing after successful build.\n"
            f"    fastled-lint crate: {RUST_CRATE_DIR}\n"
            f"    checked candidates: {[str(p) for p in _binary_candidate_paths()]}\n"
            f"    target/ walk found: {actually_present or '(none — cargo did not produce the binary)'}\n"
            "    See [cargo] lines above for what cargo actually reported."
        )
    return binary


def main() -> int:
    """CLI: print the path to the (built-if-needed) binary."""
    try:
        path = ensure_rust_lint_binary(verbose=True)
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print(str(path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
