// Single-line regex bans ported from the Python checker fleet
// (FastLED #3297 follow-up to #3288). Each struct here mirrors its
// Python counterpart's `should_process_file` + `check_file_content`
// semantics. Block comments are stripped before matching so visible code on
// either side of a multiline comment boundary is still inspected.

// --- BareNoInlineChecker -----------------------------------------------------
//
// Bans bare `__attribute__((noinline))` / `__declspec(noinline)` in src/.
// Origin: ci/lint_cpp/bare_noinline_checker.py (FastLED #2773 item 2.1).

const BARE_NOINLINE_EXEMPT_SUFFIXES: &[&str] = &[
    "fl/stl/compiler_control.h",
    "fl/stl/compiler_control.cpp.hpp",
    "platforms/arm/nrf52/led_sysdefs_arm_nrf52.h",
    "platforms/arm/teensy/coroutine_teensy.impl.hpp",
];

struct BareNoInlineChecker;

impl FileContentChecker for BareNoInlineChecker {
    fn name(&self) -> &'static str {
        "BareNoInlineChecker"
    }

    fn should_process_file(&self, file_path: &str, _project_root: &Path) -> bool {
        // Covers src/, examples/ and tests/ -- a bare noinline is the same smell
        // in an example or a benchmark as in library code.
        let in_scope = is_under_dir(file_path, "src")
            || is_under_dir(file_path, "examples")
            || is_under_dir(file_path, "tests");
        if !in_scope {
            return false;
        }
        if !ends_with_any(file_path, &[".cpp", ".h", ".hpp"]) {
            return false;
        }
        let normalized = normalize_path(file_path);
        if BARE_NOINLINE_EXEMPT_SUFFIXES
            .iter()
            .any(|suffix| normalized.ends_with(suffix))
        {
            return false;
        }
        !normalized.contains("/third_party/")
    }

    fn check_file_content(&self, file_content: &FileContent) -> Vec<(usize, String)> {
        const SUPPRESS: &str = "// ok noinline";
        let mut violations = Vec::new();
        let mut in_block_comment = CommentScanState::default();
        for (index, line) in file_content.lines.iter().enumerate() {
            let visible = strip_block_comments_from_line(line, &mut in_block_comment);
            if visible.trim_start().starts_with("//") || visible.contains(SUPPRESS) {
                continue;
            }
            let code = split_line_comment(&visible);
            if regex_bare_noinline().is_match(code) {
                violations.push((index + 1, line.trim_end().to_string()));
            }
        }
        violations
    }
}

// --- BareSnprintfChecker -----------------------------------------------------
//
// Bans bare C ::snprintf / ::printf / ::sprintf family in src/, and bans the
// removed fl::sprintf API. Bounded fl::snprintf is the only buffer formatter.
// Origin: ci/lint_cpp/bare_snprintf_checker.py (FastLED #2773 item 1.5).

const BARE_SNPRINTF_EXEMPT_SUFFIXES: &[&str] = &[
    "fl/stl/stdio.h",
    "fl/stl/stdio.cpp.hpp",
    "fl/stl/cstdio.h",
    "fl/stl/cstdio.cpp.hpp",
];

struct BareSnprintfChecker;

impl FileContentChecker for BareSnprintfChecker {
    fn name(&self) -> &'static str {
        "BareSnprintfChecker"
    }

    fn should_process_file(&self, file_path: &str, _project_root: &Path) -> bool {
        if !is_under_dir(file_path, "src") {
            return false;
        }
        if !ends_with_any(file_path, &[".cpp", ".h", ".hpp"]) {
            return false;
        }
        let normalized = normalize_path(file_path);
        if BARE_SNPRINTF_EXEMPT_SUFFIXES
            .iter()
            .any(|suffix| normalized.ends_with(suffix))
        {
            return false;
        }
        if normalized.contains("/third_party/") {
            return false;
        }
        // Host-only unit-test watchdog scaffolding never links into ESP32
        // firmware, so the binary-size argument doesn't apply.
        !normalized.ends_with("/run_unit_test.hpp")
    }

    fn check_file_content(&self, file_content: &FileContent) -> Vec<(usize, String)> {
        const SUPPRESS: &str = "// ok snprintf";
        let mut violations = Vec::new();
        let mut in_block_comment = CommentScanState::default();
        for (index, line) in file_content.lines.iter().enumerate() {
            let visible = strip_block_comments_from_line(line, &mut in_block_comment);
            if visible.trim_start().starts_with("//") || visible.contains(SUPPRESS) {
                continue;
            }
            let code = split_line_comment(&visible);
            for mat in regex_bare_snprintf().find_iter(code) {
                if printf_family_has_qualifier_prefix(code, mat.start()) {
                    let prefix = code[..mat.start()].trim_end();
                    if mat.as_str().starts_with("sprintf")
                        && prefix.ends_with("fl::")
                    {
                        violations.push((index + 1, line.trim_end().to_string()));
                    }
                    continue;
                }
                violations.push((index + 1, line.trim_end().to_string()));
                break;
            }
        }
        violations
    }
}

// --- BareLibmChecker ---------------------------------------------------------
//
// Bans bare libm calls (sin/cos/sqrtf/atan2/ldexpf/...) in src/.
// Origin: ci/lint_cpp/bare_libm_checker.py (FastLED #3002 / #3012).

const BARE_LIBM_EXEMPT_SUFFIXES: &[&str] = &["fl/math/math.cpp.hpp", "fl/math/math.h"];

const BARE_LIBM_EXEMPT_PREFIXES: &[&str] = &[
    "fl/audio/",
    "fl/fx/",
    "fl/gfx/",
    "fl/math/fixed_point",
    "fl/math/line_simplification",
    "fl/math/screenmap",
    "fl/math/transform",
    "platforms/esp/",
    "platforms/wasm/",
];

struct BareLibmChecker;

impl FileContentChecker for BareLibmChecker {
    fn name(&self) -> &'static str {
        "BareLibmChecker"
    }

    fn should_process_file(&self, file_path: &str, _project_root: &Path) -> bool {
        if !is_under_dir(file_path, "src") {
            return false;
        }
        if !ends_with_any(file_path, &[".cpp", ".h", ".hpp"]) {
            return false;
        }
        let normalized = normalize_path(file_path);
        if BARE_LIBM_EXEMPT_SUFFIXES
            .iter()
            .any(|suffix| normalized.ends_with(suffix))
        {
            return false;
        }
        if normalized.contains("/third_party/") {
            return false;
        }
        for prefix in BARE_LIBM_EXEMPT_PREFIXES {
            if normalized.contains(&format!("/src/{prefix}")) || normalized.starts_with(prefix) {
                return false;
            }
        }
        true
    }

    fn check_file_content(&self, file_content: &FileContent) -> Vec<(usize, String)> {
        const SUPPRESS: &str = "// ok libm";
        let mut violations = Vec::new();
        let mut in_block_comment = CommentScanState::default();
        for (index, line) in file_content.lines.iter().enumerate() {
            let visible = strip_block_comments_from_line(line, &mut in_block_comment);
            if visible.trim_start().starts_with("//") || visible.contains(SUPPRESS) {
                continue;
            }
            let code = split_line_comment(&visible);
            for mat in regex_bare_libm().find_iter(code) {
                if libm_has_qualifier_prefix(code, mat.start()) {
                    continue;
                }
                violations.push((index + 1, line.trim_end().to_string()));
                break;
            }
        }
        violations
    }
}

// --- FlNoUnderscoreChecker ---------------------------------------------------
//
// Enforces the FL_NO_<WORD> macro-naming convention; bans bare FL_NO<WORD>.
// Origin: ci/lint_cpp/fl_no_underscore_checker.py (FastLED #3283).

const FL_NO_UNDERSCORE_WHITELIST: &[&str] = &["FL_NOP", "FL_NOP2"];
const FL_NO_UNDERSCORE_SKIP_PREFIXES: &[&str] = &["FL_NOT_"];

struct FlNoUnderscoreChecker;

impl FileContentChecker for FlNoUnderscoreChecker {
    fn name(&self) -> &'static str {
        "FlNoUnderscoreChecker"
    }

    fn should_process_file(&self, file_path: &str, _project_root: &Path) -> bool {
        if !is_under_dir(file_path, "src") {
            return false;
        }
        if !ends_with_any(
            file_path,
            &[".cpp", ".h", ".hpp", ".cc", ".hh", ".inl", ".ino"],
        ) {
            return false;
        }
        let normalized = normalize_path(file_path);
        !normalized.contains("/third_party/")
    }

    fn check_file_content(&self, file_content: &FileContent) -> Vec<(usize, String)> {
        const SUPPRESS: &str = "// ok no-underscore";
        let mut violations = Vec::new();
        let mut in_block_comment = CommentScanState::default();
        for (index, line) in file_content.lines.iter().enumerate() {
            let visible = strip_block_comments_from_line(line, &mut in_block_comment);
            if visible.trim_start().starts_with("//") || visible.contains(SUPPRESS) {
                continue;
            }
            let code = split_line_comment(&visible);
            for mat in regex_fl_no_underscore().find_iter(code) {
                let token = mat.as_str();
                if FL_NO_UNDERSCORE_WHITELIST.contains(&token) {
                    continue;
                }
                if FL_NO_UNDERSCORE_SKIP_PREFIXES
                    .iter()
                    .any(|prefix| token.starts_with(prefix))
                {
                    continue;
                }
                violations.push((index + 1, line.trim_end().to_string()));
                break;
            }
        }
        violations
    }
}

// --- LegacyLogMacroChecker ---------------------------------------------------
//
// Rejects the obsolete `_F` spelling of FastLED logging macros in src/. The
// unified unsuffixed macros select stream or printf behavior by argument count.
// Origin:
// ci/lint_cpp/legacy_log_macro_checker.py.

struct LegacyLogMacroChecker;

impl FileContentChecker for LegacyLogMacroChecker {
    fn name(&self) -> &'static str {
        "LegacyLogMacroChecker"
    }

    fn should_process_file(&self, file_path: &str, project_root: &Path) -> bool {
        if !is_under_dir(file_path, "src") {
            return false;
        }
        if !ends_with_any(file_path, &[".cpp", ".h", ".hpp"]) {
            return false;
        }
        let normalized = normalize_path(file_path);
        if normalized.contains("/third_party/") {
            return false;
        }
        // log.h itself defines the macros — exempt it.
        let log_header_suffix = "fl/log/log.h";
        if normalized.ends_with(log_header_suffix) {
            return false;
        }
        // Belt-and-suspenders: also catch the absolute path form when a
        // non-canonical project_root is supplied (mirrors the Python
        // Path.resolve() == LOG_HEADER comparison).
        let project_normalized = normalize_path(&path_to_string(project_root));
        let absolute = format!("{project_normalized}/src/{log_header_suffix}");
        normalized != absolute
    }

    fn check_file_content(&self, file_content: &FileContent) -> Vec<(usize, String)> {
        let mut violations = Vec::new();
        let mut in_block_comment = CommentScanState::default();
        for (index, line) in file_content.lines.iter().enumerate() {
            // Skip line comments and the original macro definitions after
            // removing block comments. No suppression exists by design.
            let visible = strip_block_comments_from_line(line, &mut in_block_comment);
            let trimmed = visible.trim();
            if trimmed.starts_with("//") || trimmed.starts_with("#define") {
                continue;
            }
            let code = split_line_comment(&visible);
            let Some(captures) = regex_legacy_log_macro().captures(code) else {
                continue;
            };
            let macro_name = captures.get(1).map(|m| m.as_str()).unwrap_or("");
            let replacement = legacy_log_replacement(macro_name);
            violations.push((
                index + 1,
                format!(
                    "{}  [use {replacement} instead of {macro_name}]",
                    line.trim_end()
                ),
            ));
        }
        violations
    }
}

fn legacy_log_replacement(macro_name: &str) -> String {
    macro_name.replacen("_F", "", 1)
}

// --- IwyuPragmaPrivateChecker -----------------------------------------------
//
// Ensures every header in `src/platforms/<subdir>/...` carries an IWYU pragma
// marker so include-what-you-use treats it as a private implementation detail.
// Root-level files in `src/platforms/` are public by default and don't need
// the marker. Origin: ci/lint_cpp/iwyu_pragma_check.py.

struct IwyuPragmaPrivateChecker;

impl FileContentChecker for IwyuPragmaPrivateChecker {
    fn name(&self) -> &'static str {
        "IwyuPragmaPrivateChecker"
    }

    fn should_process_file(&self, file_path: &str, project_root: &Path) -> bool {
        if !ends_with_any(file_path, &[".h", ".hpp"]) {
            return false;
        }
        let normalized = normalize_path(file_path);
        let project_normalized = normalize_path(&path_to_string(project_root));
        let platforms_root = format!("{project_normalized}/src/platforms");
        let platforms_relative_prefix = "src/platforms";

        // Must be under src/platforms/ (absolute or repo-relative form).
        let under_platforms = normalized.starts_with(&format!("{platforms_root}/"))
            || normalized.starts_with(&format!("{platforms_relative_prefix}/"));
        if !under_platforms {
            return false;
        }

        // Skip root-level files directly under src/platforms/. Python's
        // `file.parent != platforms_dir` check is equivalent to "the path
        // under src/platforms/ has at least one more `/` separator".
        let relative_to_platforms = normalized
            .strip_prefix(&format!("{platforms_root}/"))
            .or_else(|| normalized.strip_prefix(&format!("{platforms_relative_prefix}/")))
            .unwrap_or("");
        relative_to_platforms.contains('/')
    }

    fn check_file_content(&self, file_content: &FileContent) -> Vec<(usize, String)> {
        // Python's check is a flat `"IWYU pragma:" in content` substring scan.
        // Mirror it exactly so binary / unicode-decode-error files behave
        // the same (Rust's read_to_string would have already failed earlier
        // and the file would be silently skipped by the dispatcher).
        if file_content.content.contains("IWYU pragma:") {
            return Vec::new();
        }
        vec![(
            0,
            "Should be marked: // IWYU pragma: private".to_string(),
        )]
    }
}

// --- BareDigitSeparatorChecker ----------------------------------------------
//
// Bans C++14 digit separators (e.g. `999'999'999`) in src/. Some downstream
// Some board environments (LPC8xx in particular, see FastLED #3329) still
// default to `-std=gnu++11`. Under gnu++11 the compiler reads the single
// quote as a character-literal delimiter, so a literal like `999'999'999`
// becomes `'999'` + stray digits — fatal parse error. Keep src/ portable
// across C++11/14/17 by spelling out the digits.
//
// Comments are stripped before matching (via the shared block-comment
// stripper) so doxygen comments that mention
// the formula in pseudocode (`// = (ns * hz + 999'999'999) / 1'000'000'000`)
// stay legal — the compiler never sees them.
//
// Suppression: append `// ok digit-separator` at end of the line.

struct BareDigitSeparatorChecker;

impl FileContentChecker for BareDigitSeparatorChecker {
    fn name(&self) -> &'static str {
        "BareDigitSeparatorChecker"
    }

    fn should_process_file(&self, file_path: &str, _project_root: &Path) -> bool {
        if !is_under_dir(file_path, "src") {
            return false;
        }
        if !ends_with_any(file_path, &[".cpp", ".h", ".hpp", ".cpp.hpp"]) {
            return false;
        }
        let normalized = normalize_path(file_path);
        !normalized.contains("/third_party/")
    }

    fn check_file_content(&self, file_content: &FileContent) -> Vec<(usize, String)> {
        const SUPPRESS_TAIL: &str = "ok digit-separator";
        let mut violations = Vec::new();
        let mut in_block_comment = CommentScanState::default();
        for (index, line) in file_content.lines.iter().enumerate() {
            // Strip all `/* ... */` block comments (single-line AND multi-line),
            // advancing in_block_comment across line boundaries. This is what
            // makes inline doxygen `/* note 9'9 */` skip cleanly.
            let stripped = strip_block_comments_from_line(line, &mut in_block_comment);
            // Blank double-quoted string contents BEFORE splitting on `//` so
            // that a literal like `"http://..."` can't fool the comment split,
            // and so the SUPPRESS check never matches text that lives inside
            // a string. Single-quoted CHARs are left alone (the shared
            // `strip_string_literals` blanks those too, which would eat the
            // very digit-separator we want to flag).
            let no_strings = strip_double_quoted_strings(&stripped);
            let (code_no_strings, comment_tail) = no_strings
                .split_once("//")
                .map_or((no_strings.as_str(), ""), |(code, comment)| (code, comment));
            // Trailing `// ok digit-separator` opts the line out.
            if comment_tail.contains(SUPPRESS_TAIL) {
                continue;
            }
            if regex_bare_digit_separator().is_match(code_no_strings) {
                violations.push((
                    index + 1,
                    format!(
                        "{}  [C++14 digit separator — use plain digits for gnu++11 portability \
(suppress with `// ok digit-separator` if intentional)]",
                        line.trim_end()
                    ),
                ));
            }
        }
        violations
    }
}

fn strip_double_quoted_strings(code: &str) -> String {
    // Replace the contents of every `"..."` literal with empty space while
    // preserving the surrounding code positions. Unlike the shared
    // `strip_string_literals`, single-quoted char literals are left alone so
    // a digit separator like `'9'` inside `999'999'999ULL` still surfaces.
    let mut out = String::with_capacity(code.len());
    let mut in_string = false;
    let mut escaped = false;
    for ch in code.chars() {
        if in_string {
            if escaped {
                escaped = false;
                continue;
            }
            if ch == '\\' {
                escaped = true;
                continue;
            }
            if ch == '"' {
                in_string = false;
                out.push('"');
                continue;
            }
            continue;
        }
        if ch == '"' {
            in_string = true;
        }
        out.push(ch);
    }
    out
}

// `\b` in Rust regex covers identifier-char boundary, but it ALSO allows `:`
// and `.` as the preceding non-word char. The Python lookbehind excluded
// those too, so we manually re-check after the regex finds a match.
fn printf_family_has_qualifier_prefix(code: &str, start: usize) -> bool {
    if start == 0 {
        return false;
    }
    let preceding = &code[..start];
    preceding.ends_with(':') || preceding.ends_with('.')
}

// BareLibm allows an OPTIONAL `::` prefix as part of the match (Python
// `(?:::)?<func>`). The lookbehind only excluded identifier-chars and `:`,
// so `obj.sqrtf(...)` does match in Python (and is therefore flagged).
// We mirror that: only the `:` and identifier-char preceding chars suppress
// the match. The leading `::` of a global-qualified call is consumed by the
// regex itself.
fn libm_has_qualifier_prefix(code: &str, start: usize) -> bool {
    if start == 0 {
        return false;
    }
    let preceding = &code[..start];
    // Strip the optional `::` that's part of our own match.
    let preceding = preceding.trim_end_matches(':');
    // After stripping `::`, an identifier-char or another `:` preceding it
    // means this was a member / qualified call — skip.
    let Some(last) = preceding.chars().last() else {
        return false;
    };
    last.is_ascii_alphanumeric() || last == '_' || last == ':'
}
