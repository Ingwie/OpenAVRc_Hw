/*
 * Ppm_Smode.ino
 * ------------------------------------------------------------
 * SLAVE MODE - PPM INPUT READER
 *
 * This module captures a real PPM (CPPM) signal coming from a
 * radio transmitter acting as the SLAVE (trainer/student radio).
 *
 * Functional role in the project:
 * - Listens to a PPM input pin using an interrupt on rising edges.
 * - Measures pulse intervals to reconstruct channel values.
 * - Detects frame synchronization gaps.
 * - Makes decoded channel data available to higher layers
 *   (typically for conversion and forwarding via ESPNOW).
 *
 * This file DOES NOT:
 * - Generate PPM output
 * - Perform SBUS decoding
 * - Handle UART / HC05 communication
 *
 * Timing critical code runs in ISR context.
 * ------------------------------------------------------------
 */

#include "Ppm_Smode.h"
#include "Ppm_Link.h"

// Uses existing globals/functions from main sketch (same translation unit, Arduino concatenates .ino)
extern const int UART_RX; // pin 4 in your design

static volatile uint16_t ppmS_chUs[8] = {1500,1500,1500,1500,1500,1500,1500,1500};
static volatile uint8_t  ppmS_idx = 0;
static volatile uint32_t ppmS_lastRiseUs = 0;
static volatile bool     ppmS_frameReady = false;

static uint8_t ppmS_seq = 0;
static bool ppmS_inited = false;

// If time between rising edges exceeds this, it's a sync gap (new frame)
static const uint16_t PPM_S_SYNC_US = 3000;

// Rising-edge capture (assumes positive pulses)
  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static void IRAM_ATTR ppmS_isr() {
  uint32_t now = (uint32_t)micros();
  uint32_t dt  = now - ppmS_lastRiseUs;
  ppmS_lastRiseUs = now;

  if (dt > PPM_S_SYNC_US) {
    ppmS_idx = 0;
    return;
  }

  if (ppmS_idx < 8) {
    // dt is channel time (typically 1000..2000us)
    uint8_t idx = ppmS_idx;
    ppmS_idx = (uint8_t)(ppmS_idx + 1);
    ppmS_chUs[idx] = (uint16_t)dt;
    if (ppmS_idx >= 8) {
      ppmS_frameReady = true;
    }
  }
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmSlaveBegin() {
  if (cfg_role != 0) return;
  if (cfg_Smode != CPPM_SLAVE) return;

  // Ensure UART is not consuming this pin in PPM mode (processUART is already gated in main)
  pinMode(UART_RX, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(UART_RX), ppmS_isr, RISING);

  ppmS_inited = true;
  if (dbg_bt) Serial.println("[PPM-S] init: PPM IN on UART_RX, sending PKT_PPM");
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmSlaveTask() {
  if (!ppmS_inited) return;
  if (!ppmS_frameReady) return;

  ppmS_frameReady = false;

  PpmBinPayload pb{};
  pb.magic = 0xA5;
  pb.seq   = ppmS_seq++;

  noInterrupts();
  for (int i = 0; i < 8; i++) pb.ch_us[i] = ppmS_chUs[i];
  interrupts();

  pb.crc = ppm_crc16_ccitt((const uint8_t*)&pb, sizeof(pb) - 2);

  // Route like your other data: prefer linked peer, else bound
  if (linked_peer_set) sendPkt(linked_peer_mac, PKT_PPM, &pb, sizeof(pb));
  else if (bound_peer_set) sendPkt(bound_peer_mac, PKT_PPM, &pb, sizeof(pb));

  if (dbg_bt) {
    Serial.print("[PPM-S->ESPNOW] seq=");
    Serial.print(pb.seq);
    Serial.print(" ch1=");
    Serial.println(pb.ch_us[0]);
  }
}