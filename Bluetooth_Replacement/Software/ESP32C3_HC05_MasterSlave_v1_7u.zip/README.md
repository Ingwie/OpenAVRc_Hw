# ESP32C3 HC05 / SBUS / PPM Bridge – Architecture

## Objectif du projet
Créer un lien maître/élève entre deux radios RC hétérogènes à l’aide de deux ESP32‑C3,
en remplaçant le module Bluetooth HC‑05 par une émulation logicielle et en permettant
plusieurs types d’entrées/sorties radio : HC05, SBUS et PPM.

Le transport interne entre ESP32 repose sur ESPNOW.

---

## Concepts clés

### Rôles
- **SLAVE** : lit les signaux provenant de la radio élève
- **MASTER** : génère les signaux vers la radio maître

### Modes d’entrée / sortie
Chaque côté peut fonctionner indépendamment selon son mode.

**Modes SLAVE (entrée radio)**
- `HC05_SLAVE` : lecture trames `tf` depuis OpenAVRc
- `SBUS_SLAVE` : lecture SBUS réel
- `CPPM_SLAVE` : lecture PPM réel

**Modes MASTER (sortie radio)**
- `HC05_MASTER` : injection trames `tf` vers OpenAVRc
- `SBUS_MASTER` : génération SBUS
- `CPPM_MASTER` : génération PPM

---

## Flux de données générique

```
Radio SLAVE
   ↓
[Interface SLAVE]
   ↓
(trame tf ou canaux)
   ↓
ESPNOW
   ↓
(trame tf ou canaux)
   ↓
[Interface MASTER]
   ↓
Radio MASTER
```

Le format transporté sur ESPNOW dépend du couple de modes :
- ASCII `tf` (héritage OpenAVRc)
- binaire canaux (PPM → PPM, extensible)

---

## Philosophie logicielle

- Un **fichier = une responsabilité**
- Les modules (`Ppm_*`, `Sbus_*`) ne se parlent pas entre eux
- Le fichier principal orchestre uniquement :
  - configuration
  - sélection de modes
  - routage

Le code temps réel (ISR, timers) est strictement isolé dans les modules dédiés.

---

## Évolutions prévues
- CRC sur tous les paquets binaires
- Failsafe par timeout ESPNOW
- Mapping voies configurable
- Support multi‑trames (16ch, 24ch)

