#pragma once
#include <Arduino.h>

// SBUS output (MASTER) driven from incoming OpenAVRc trainer "tf ..." frames.
// Enabled only when cfg_role==1 (MASTER role) and cfg_Mmode==SBUS_MASTER.

void SbusMasterBegin();
void SbusMasterFeed(const uint8_t* data, int len);
void SbusMasterTask();
