#pragma once
#include <Arduino.h>

// PPM input (SLAVE) -> send PKT_PPM (binary + CRC) over ESPNOW.
// Enabled only when cfg_role==SLAVE and cfg_Smode==CPPM_SLAVE.

void PpmSlaveBegin();
void PpmSlaveTask();
