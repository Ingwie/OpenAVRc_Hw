/*
 * Ppm_Mmode.ino
 * ------------------------------------------------------------
 * MASTER MODE - PPM OUTPUT GENERATOR
 *
 * This module is responsible for generating a PPM (CPPM) signal
 * on the MASTER side, intended to be injected into a trainer
 * port or equivalent PPM input of a radio transmitter.
 *
 * Functional role in the project:
 * - Receives channel data from ESPNOW (typically originating
 *   from a SLAVE device).
 * - Converts channel values into PPM pulse timings.
 * - Uses a hardware timer and ISR to generate a continuous,
 *   frame-based PPM signal on a GPIO pin.
 *
 * This file DOES NOT:
 * - Parse tf frames
 * - Communicate over UART, SBUS, or ESPNOW directly
 *
 * It only exposes a minimal API used by the main sketch to:
 * - Initialize PPM output
 * - Update channel values atomically
 *
 * IMPORTANT:
 * This file must remain independent from SBUS and HC05 logic.
 * ------------------------------------------------------------
 */

#include "Ppm_Mmode.h"

// Provided by main sketch
extern uint8_t cfg_role;   // 0 slave, 1 master
extern uint8_t cfg_Mmode;  // 0=PPM, 1=SBUS, 2=HC05
extern bool    dbg_bt;

// Pin is the TX pin of the "BT" UART (same as UART_TX in main)
extern const int UART_TX;

// -----------------------------------------------------------------------------
// PPM parameters (classic CPPM)
// -----------------------------------------------------------------------------
static const uint8_t  PPM_CH_COUNT   = 8;
static const uint32_t PPM_FRAME_US   = 20000;   // 20ms frame
static const uint16_t PPM_PULSE_US   = 300;     // fixed pulse width
static const uint16_t PPM_MIN_US     = 1000;    // channel min (after mapping)
static const uint16_t PPM_MAX_US     = 2000;    // channel max
static const bool     PPM_POLARITY_HIGH_PULSE = true; // pulse level

// Channel values in microseconds (1000..2000)
static volatile uint16_t ppmUs[PPM_CH_COUNT] = {1500,1500,1500,1500,1500,1500,1500,1500};

// Timer ISR state
static hw_timer_t* timer = nullptr;
static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
static volatile uint8_t  curCh = 0;
static volatile bool     inPulse = false;
static volatile uint32_t accUs = 0;
static bool inited = false;

// Trainer line reassembly (fragment tolerant)
static char tfLine[96];
static uint8_t tfPos = 0;
static bool tfActive = false;

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static inline uint16_t clampU16(uint16_t v, uint16_t lo, uint16_t hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

// Map 11-bit (0..2047) to microseconds (1000..2000)
  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static inline uint16_t map11ToUs(uint16_t v11) {
  // scale: 0->1000, 2047->2000
  // us = 1000 + v11 * 1000 / 2047
  uint32_t us = 1000UL + (uint32_t)v11 * 1000UL / 2047UL;
  return (uint16_t)clampU16((uint16_t)us, PPM_MIN_US, PPM_MAX_US);
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static bool parseTfLine(const char* line) {
  if (!line) return false;
  if (line[0] != 't' || line[1] != 'f' || line[2] != ' ') return false;

  int found = 0;
  const char* p = line;

  while (*p && found < PPM_CH_COUNT) {
    if (*p == 's') {
      if (isxdigit((unsigned char)p[1]) && isxdigit((unsigned char)p[2]) && isxdigit((unsigned char)p[3])) {
        char h[4] = {p[1], p[2], p[3], 0};
        uint16_t v11 = (uint16_t)strtoul(h, nullptr, 16) & 0x07FF;

        uint16_t us = map11ToUs(v11);

        portENTER_CRITICAL(&mux);
        ppmUs[found] = us;
        portEXIT_CRITICAL(&mux);

        found++;
        p += 4;
        continue;
      }
    }
    p++;
  }

  if (dbg_bt) {
    Serial.print("[PPM] tf->ch: ");
    Serial.print(found);
    Serial.print("  ch1(us)=");
    Serial.println(ppmUs[0]);
  }

  return (found > 0);
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static void IRAM_ATTR onTimer() {
  // This ISR schedules alternating pulse and gap durations.
  // PPM scheme (high pulse): HIGH for PPM_PULSE_US, then LOW for (chUs - PPM_PULSE_US).
  // After last channel, LOW for sync such that total frame length is PPM_FRAME_US.
  uint32_t nextUs = 0;

  portENTER_CRITICAL_ISR(&mux);

  if (!inPulse) {
    // Start pulse
    if (PPM_POLARITY_HIGH_PULSE) {
      gpio_set_level((gpio_num_t)UART_TX, 1);
    } else {
      gpio_set_level((gpio_num_t)UART_TX, 0);
    }
    inPulse = true;
    nextUs = PPM_PULSE_US;
  } else {
    // End pulse -> gap
    if (PPM_POLARITY_HIGH_PULSE) {
      gpio_set_level((gpio_num_t)UART_TX, 0);
    } else {
      gpio_set_level((gpio_num_t)UART_TX, 1);
    }
    inPulse = false;

    if (curCh < PPM_CH_COUNT) {
      uint16_t chUsLocal = ppmUs[curCh];
      if (chUsLocal < PPM_PULSE_US) chUsLocal = PPM_PULSE_US;
      nextUs = (uint32_t)chUsLocal - PPM_PULSE_US;
      accUs += chUsLocal;
      curCh++;
    } else {
      // Sync gap
      uint32_t syncUs = (accUs < PPM_FRAME_US) ? (PPM_FRAME_US - accUs) : 3000;
      // We already spent the last pulse width inside accUs accounting via channels,
      // so sync is the remaining LOW time.
      nextUs = syncUs;
      // Reset frame
      curCh = 0;
      accUs = 0;
    }
  }

  // Program next alarm (timer tick is 1us)
  timerAlarm(timer, nextUs, false, 0);

  portEXIT_CRITICAL_ISR(&mux);
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmMasterBegin() {
  if (cfg_role != 1) return;          // only on MASTER
  if (cfg_Mmode != 0) return;         // 0 == CPPM_MASTER

  pinMode(UART_TX, OUTPUT);

  // idle level is LOW if high-pulse; HIGH if low-pulse
  if (PPM_POLARITY_HIGH_PULSE) digitalWrite(UART_TX, LOW);
  else                         digitalWrite(UART_TX, HIGH);

  // init timer at 1MHz (1 tick = 1us)
  if (!timer) {
    timer = timerBegin(1000000); // 1MHz (1 tick = 1us) on ESP32 core 3.x // 80MHz/80 = 1MHz on ESP32
    timerAttachInterrupt(timer, &onTimer);
  }

  // Reset state
  portENTER_CRITICAL(&mux);
  curCh = 0;
  inPulse = false;
  accUs = 0;
  portEXIT_CRITICAL(&mux);

  timerAlarm(timer, 1000, false, 0);

  inited = true;

  if (dbg_bt) {
    Serial.print("[PPM] OUT init on GPIO ");
    Serial.print(UART_TX);
    Serial.println(" (BT TX pin).");
  }
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmMasterFeed(const uint8_t* data, int len) {
  if (!inited) return;
  if (!data || len <= 0) return;

  for (int i = 0; i < len; i++) {
    char c = (char)data[i];

    if (!tfActive) {
      if (c == 't') { tfActive = true; tfPos = 0; tfLine[tfPos++] = 't'; }
      continue;
    }

    if (tfPos < (sizeof(tfLine) - 1)) tfLine[tfPos++] = c;

    if (c == '\r' || c == '\n') {
      tfLine[tfPos] = 0;

      if (tfLine[0] == 't' && tfLine[1] == 'f' && tfLine[2] == ' ') {
        parseTfLine(tfLine);
      }

      tfActive = false;
      tfPos = 0;
      continue;
    }

    // resync if not "tf "
    if (tfPos == 2 && tfLine[1] != 'f') { tfActive = false; tfPos = 0; }
    if (tfPos == 3 && tfLine[2] != ' ') { tfActive = false; tfPos = 0; }

    if (tfPos >= (sizeof(tfLine) - 1)) { tfActive = false; tfPos = 0; }
  }
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmMasterTask() {
  // nothing: ISR drives waveform
}


  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmMasterSetChannelsUs(const uint16_t* ch, int n) {
  if (!ch) return;
  if (n > 8) n = 8;
  portENTER_CRITICAL(&mux);
  for (int i = 0; i < n; i++) {
    ppmUs[i] = ch[i];
  }
  portEXIT_CRITICAL(&mux);
}