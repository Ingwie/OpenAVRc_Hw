/*
 * Sbus_Mmode.ino
 * ------------------------------------------------------------
 * MASTER MODE - SBUS OUTPUT GENERATOR
 *
 * This module is responsible for generating a valid SBUS stream
 * on the MASTER side, typically to drive a radio transmitter
 * that accepts SBUS input instead of PPM or HC05.
 *
 * Functional role in the project:
 * - Receives channel data (usually from tf frames via ESPNOW).
 * - Encodes channel values into the SBUS binary protocol.
 * - Outputs SBUS frames at the correct baud rate and format.
 *
 * This file DOES NOT:
 * - Decode incoming SBUS
 * - Handle ESPNOW reception directly
 * - Parse ASCII tf frames
 *
 * The SBUS protocol implementation here is write-only.
 * ------------------------------------------------------------
 */

#include "Sbus_Mmode.h"

// These are defined in the main .ino
extern HardwareSerial BT;
extern uint8_t cfg_role;   // 0 slave, 1 master
extern uint8_t cfg_Mmode;  // CPPM_MASTER / SBUS_MASTER / HC05_MASTER
extern bool    dbg_bt;

//
// -----------------------------------------------------------------------------
// SBUS parameters
// -----------------------------------------------------------------------------
static const uint32_t SBUS_BAUD = 100000;
static const uint8_t  SBUS_FRAME_LEN = 25;
static const uint8_t  SBUS_STARTBYTE = 0x0F;
static const uint8_t  SBUS_ENDBYTE   = 0x00;

// NOTE: SBUS is usually inverted (logical). ESP32 core may or may not support TX inversion API.
// Keep software inversion OFF here; use external inverter if needed.
// If your core supports inversion, you can enable it in the main sketch or here.
static const bool SBUS_TX_INVERT_HINT = true;

static uint16_t sbusCh[16];               // 0..2047
static uint8_t  sbusFrame[SBUS_FRAME_LEN];
static uint32_t lastSendMs = 0;
static bool sbusInited = false;

// Trainer line reassembly (handles fragmented ESPNOW payloads)
static char sbusTfLine[96];
static uint8_t sbusTfPos = 0;
static bool sbusTfActive = false;         // currently inside a "tf " line

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static inline uint16_t clamp11(uint16_t v) { return (v > 2047) ? 2047 : v; }

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static void sbusPackAndSend() {
  // Start/end bytes
  sbusFrame[0]  = SBUS_STARTBYTE;
  sbusFrame[24] = SBUS_ENDBYTE;

  uint16_t ch[16];
  for (int i = 0; i < 16; i++) ch[i] = clamp11(sbusCh[i]);

  // Pack 16x11bit into bytes 1..22
  sbusFrame[1]  = (uint8_t)( ch[0]       & 0xFF);
  sbusFrame[2]  = (uint8_t)((ch[0] >> 8) | (ch[1] << 3));
  sbusFrame[3]  = (uint8_t)((ch[1] >> 5) | (ch[2] << 6));
  sbusFrame[4]  = (uint8_t)((ch[2] >> 2) & 0xFF);
  sbusFrame[5]  = (uint8_t)((ch[2] >>10) | (ch[3] << 1));
  sbusFrame[6]  = (uint8_t)((ch[3] >> 7) | (ch[4] << 4));
  sbusFrame[7]  = (uint8_t)((ch[4] >> 4) | (ch[5] << 7));
  sbusFrame[8]  = (uint8_t)((ch[5] >> 1) & 0xFF);
  sbusFrame[9]  = (uint8_t)((ch[5] >> 9) | (ch[6] << 2));
  sbusFrame[10] = (uint8_t)((ch[6] >> 6) | (ch[7] << 5));
  sbusFrame[11] = (uint8_t)((ch[7] >> 3) & 0xFF);
  sbusFrame[12] = (uint8_t)( ch[8]       & 0xFF);
  sbusFrame[13] = (uint8_t)((ch[8] >> 8) | (ch[9] << 3));
  sbusFrame[14] = (uint8_t)((ch[9] >> 5) | (ch[10] << 6));
  sbusFrame[15] = (uint8_t)((ch[10]>> 2) & 0xFF);
  sbusFrame[16] = (uint8_t)((ch[10]>>10) | (ch[11] << 1));
  sbusFrame[17] = (uint8_t)((ch[11]>> 7) | (ch[12] << 4));
  sbusFrame[18] = (uint8_t)((ch[12]>> 4) | (ch[13] << 7));
  sbusFrame[19] = (uint8_t)((ch[13]>> 1) & 0xFF);
  sbusFrame[20] = (uint8_t)((ch[13]>> 9) | (ch[14] << 2));
  sbusFrame[21] = (uint8_t)((ch[14]>> 6) | (ch[15] << 5));
  sbusFrame[22] = (uint8_t)((ch[15]>> 3) & 0xFF);

  // Flags byte: no digital channels, no failsafe encoding for now
  sbusFrame[23] = 0x00;

  BT.write(sbusFrame, SBUS_FRAME_LEN);
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static bool sbusParseTfLine(const char* line) {
  // Expected: "tf sXXXsXXXsXXXsXXXsXXXsXXXsXXXsXXX:CC" (+ optional CR)
  if (!line) return false;
  if (line[0] != 't' || line[1] != 'f' || line[2] != ' ') return false;

  int found = 0;
  const char* p = line;

  while (*p && found < 8) {
    if (*p == 's') {
      if (isxdigit((unsigned char)p[1]) && isxdigit((unsigned char)p[2]) && isxdigit((unsigned char)p[3])) {
        char h[4] = {p[1], p[2], p[3], 0};
        uint16_t v = (uint16_t)strtoul(h, nullptr, 16) & 0x07FF;
        sbusCh[found] = v;
        found++;
        p += 4;
        continue;
      }
    }
    p++;
  }

  // For now, fill remaining channels to neutral.
  for (int i = found; i < 16; i++) sbusCh[i] = 1024;

  if (dbg_bt) {
    Serial.print("[SBUS] tf->ch: ");
    Serial.print(found);
    Serial.print("  ch1=");
    Serial.println(sbusCh[0]);
  }
  return (found > 0);
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void SbusMasterBegin() {
  if (cfg_role != 1) return;            // only on MASTER device
  if (cfg_Mmode != SBUS_MASTER) return; // only when selected

  // Init UART on BT pins but as SBUS output
  BT.begin(SBUS_BAUD, SERIAL_8E2);

  // Initialize channels to neutral
  for (int i = 0; i < 16; i++) sbusCh[i] = 1024;

  sbusInited = true;

  // Note about inversion (hardware dependent)
  if (dbg_bt) {
    Serial.print("[SBUS] OUT init 100000 8E2. Inversion usually required. Hint=");
    Serial.println(SBUS_TX_INVERT_HINT ? "invert" : "normal");
  }
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void SbusMasterFeed(const uint8_t* data, int len) {
  if (!sbusInited) return;
  if (!data || len <= 0) return;

  // Reassemble lines; only care about lines starting with "tf "
  for (int i = 0; i < len; i++) {
    char c = (char)data[i];

    if (!sbusTfActive) {
      // look for 't','f',' '
      if (c == 't') { sbusTfActive = true; sbusTfPos = 0; sbusTfLine[sbusTfPos++] = 't'; }
      continue;
    }

    // sbusTfActive: collect until CR/LF
    if (sbusTfPos < (sizeof(sbusTfLine) - 1)) sbusTfLine[sbusTfPos++] = c;

    if (c == '\r' || c == '\n') {
      sbusTfLine[sbusTfPos] = 0;

      // Validate prefix quickly (handle fragmentation: ensure "tf ")
      if (sbusTfLine[0] == 't' && sbusTfLine[1] == 'f' && sbusTfLine[2] == ' ') {
        sbusParseTfLine(sbusTfLine);
      }

      sbusTfActive = false;
      sbusTfPos = 0;
      continue;
    }

    // If we started with 't' but not a tf line, drop and resync
    if (sbusTfPos == 2 && sbusTfLine[1] != 'f') { sbusTfActive = false; sbusTfPos = 0; }
    if (sbusTfPos == 3 && sbusTfLine[2] != ' ') { sbusTfActive = false; sbusTfPos = 0; }

    // Safety: overflow resets
    if (sbusTfPos >= (sizeof(sbusTfLine) - 1)) { sbusTfActive = false; sbusTfPos = 0; }
  }
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void SbusMasterTask() {
  if (!sbusInited) return;

  uint32_t now = millis();
  // Typical SBUS period ~9-15ms; use 15ms
  if ((now - lastSendMs) >= 15) {
    lastSendMs = now;
    sbusPackAndSend();
  }
}