#pragma once
#include <Arduino.h>

// CPPM/PPM output (MASTER) driven from incoming OpenAVRc trainer "tf ..." frames.
// Enabled only when cfg_role==1 (MASTER role) and cfg_Mmode==CPPM_MASTER (0).

void PpmMasterBegin();
void PpmMasterFeed(const uint8_t* data, int len);
void PpmMasterTask();
void PpmMasterSetChannelsUs(const uint16_t* ch, int n);

