#include <ESP32_PPM.h>

// PPM generator instance (from external ESP32_PPM library)
//static ESP32_PPM Cppm32;

/*
 * Ppm_Mmode.ino
 * ------------------------------------------------------------
 * MASTER MODE - PPM OUTPUT GENERATOR
 *
 * This module is responsible for generating a PPM (CPPM) signal
 * on the MASTER side, intended to be injected into a trainer
 * port or equivalent PPM input of a radio transmitter.
 *
 * Functional role in the project:
 * - Receives channel data from ESPNOW (typically originating
 *   from a SLAVE device).
 * - Converts channel values into PPM pulse timings.
 * - Uses a hardware timer and ISR to generate a continuous,
 *   frame-based PPM signal on a GPIO pin.
 *
 * This file DOES NOT:
 * - Parse tf frames
 * - Communicate over UART, SBUS, or ESPNOW directly
 *
 * It only exposes a minimal API used by the main sketch to:
 * - Initialize PPM output
 * - Update channel values atomically
 *
 * IMPORTANT:
 * This file must remain independent from SBUS and HC05 logic.
 * ------------------------------------------------------------
 */

#include "Ppm_Mmode.h"

// Provided by main sketch
extern uint8_t cfg_role;   // 0 slave, 1 master
extern uint8_t cfg_Mmode;  // 0=PPM, 1=SBUS, 2=HC05
extern bool    dbg_bt;

// Pin is the TX pin of the "BT" UART (same as UART_TX in main)
extern const int UART_TX;

// -----------------------------------------------------------------------------
// PPM parameters (classic CPPM)
// -----------------------------------------------------------------------------
static const uint8_t  PPM_CH_COUNT   = 8;
static const uint32_t PPM_FRAME_US   = 20000;   // 20ms frame
static const uint16_t PPM_PULSE_US   = 300;     // fixed pulse width
static const uint16_t PPM_MIN_US     = 1000;    // channel min (after mapping)
static const uint16_t PPM_MAX_US     = 2000;    // channel max
static const bool     PPM_POLARITY_HIGH_PULSE = true; // pulse level

// Channel values in microseconds (1000..2000)
static volatile uint16_t ppmUs[PPM_CH_COUNT] = {1500,1500,1500,1500,1500,1500,1500,1500};

// Timer ISR state
static volatile uint8_t  curCh = 0;
static volatile bool     inPulse = false;
static volatile uint32_t accUs = 0;
static bool PpmInited = false;

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static inline uint16_t clampU16(uint16_t v, uint16_t lo, uint16_t hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

// Map 11-bit (0..2047) to microseconds (1000..2000)
  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static inline uint16_t map11ToUs(uint16_t v11) {
  // scale: 0->1000, 2047->2000
  // us = 1000 + v11 * 1000 / 2047
  uint32_t us = 1000UL + (uint32_t)v11 * 1000UL / 2047UL;
  return (uint16_t)clampU16((uint16_t)us, PPM_MIN_US, PPM_MAX_US);
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static bool parseTfLineToPpm(const char* line) {
  // Expected: "tf sXXXsXXXsXXXsXXXsXXXsXXXsXXXsXXX:CC" (+ optional CR)
  if (!line) return false;
  if (line[0] != 't' || line[1] != 'f' || line[2] != ' ') return false;

  int found = 0;
  const char* p = line;

  while (*p && found < PPM_CH_COUNT) {
    if (*p == 's') {
      if (isxdigit((unsigned char)p[1]) && isxdigit((unsigned char)p[2]) && isxdigit((unsigned char)p[3])) {
        char h[4] = {p[1], p[2], p[3], 0};
        uint16_t v11 = (uint16_t)strtoul(h, nullptr, 16) & 0x07FF;

        uint16_t us = map11ToUs(v11);
        ppmUs[found] = us;
        found++;
        p += 4;
        continue;
      }
    }
    p++;
  }

  if (dbg_bt) {
    Serial.print("[PPM] tf->ch: ");
    Serial.print(found);
    Serial.print("  ch1(us)=");
    Serial.println(ppmUs[0]);
  }

  return (found > 0);
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmMasterBegin() {
  if (cfg_role != 1) return;          // only on MASTER
  if (cfg_Mmode != 0) return;         // 0 == CPPM_MASTER

  // External PPM generator (ESP32_PPM library).
  // cfg_ppm selects polarity: CPPM_GEN_POS_MOD (positive) or CPPM_GEN_NEG_MOD (negative).
  if (!PpmInited) {
    Cppm32.begin((cfg_ppm == CPPM_GEN_POS_MOD) ? CPPM_GEN_POS_MOD : CPPM_GEN_NEG_MOD,
                 8, 22500, 300, UART_TX);
    PpmInited = true;
  }

  // Push current channels into the generator
  for (uint8_t i = 0; i < 8; i++) {
    Cppm32.width_us(i + 1, ppmUs[i]);
  }
}


  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmMasterFeed(const uint8_t* data, int len) {
  if (!PpmInited) return;
  if (!data || len <= 0) return;

  for (int i = 0; i < len; i++) {
    char c = (char)data[i];

    if (!tfActive) {
      if (c == 't') { tfActive = true; tfPos = 0; tfLine[tfPos++] = 't'; }
      continue;
    }

    if (tfPos < (sizeof(tfLine) - 1)) tfLine[tfPos++] = c;

    if (c == '\r' || c == '\n') {
      tfLine[tfPos] = 0;

      if (tfLine[0] == 't' && tfLine[1] == 'f' && tfLine[2] == ' ') {
        parseTfLineToPpm(tfLine);
      }

      tfActive = false;
      tfPos = 0;
      continue;
    }

    // resync if not "tf "
    if (tfPos == 2 && tfLine[1] != 'f') { tfActive = false; tfPos = 0; }
    if (tfPos == 3 && tfLine[2] != ' ') { tfActive = false; tfPos = 0; }

    if (tfPos >= (sizeof(tfLine) - 1)) { tfActive = false; tfPos = 0; }
  }
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmMasterTask() {
  // nothing: ISR drives waveform
}


  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void PpmMasterSetChannelsUs(const uint16_t* ch, int n) {
  if (!ch) return;
  if (n > 8) n = 8;

  for (int i = 0; i < n; i++) {
    ppmUs[i] = ch[i];
  }

  if (PpmInited) {
    for (int i = 0; i < n; i++) {
      Cppm32.width_us((uint8_t)(i + 1), ppmUs[i]);
    }
  }
}

// ---------------------------------------------------------------------------
// PPM: suspension temporaire pendant OTA
// Objectif: libérer CPU/IRQ/timing pour que ArduinoOTA.handle() réponde vite.
// ---------------------------------------------------------------------------
static bool ppmSuspendedByOta = false;

void PpmMasterSuspendForOta(bool suspend)
{
  if (suspend) {
    if (ppmSuspendedByOta) return;
    ppmSuspendedByOta = true;

    // Stopper la génération PPM de façon simple et sûre :
    // 1) Si tu as une fonction "PpmMasterEnd()" existante -> utilise-la
    // 2) Sinon on met la pin en INPUT (tri-state) pour arrêter le signal
#ifdef UART_TX
    pinMode(UART_TX, INPUT);
#endif
    return;
  }

  // Resume
  if (!ppmSuspendedByOta) return;
  ppmSuspendedByOta = false;

  // Relancer seulement si on est dans un mode qui doit générer du PPM.
  // (on évite de redémarrer si le mode n'est pas PPM)
  if (cfg_role == 1 && (cfg_Mmode == CPPM_MASTER || cfg_Mmode == PPM2PPM_MASTER)) {
    PpmMasterBegin();
  }
}

void PpmMasterSuspend(bool en) {
  static bool suspended = false;
  if (en) {
    if (suspended) return;
    suspended = true;

    // Also release the pin
    pinMode(UART_TX, INPUT);
    return;
  }

  // resume
  if (!suspended) return;
  suspended = false;

  // Only resume if this board is actually in MASTER PPM mode
  if (cfg_role == 1 && cfg_Mmode == 0) {
    PpmMasterBegin();
  }
}