#pragma once
// WiFi / CTRL / FileTransfer (TCP<->UART) module
// Extracted from ESP32C3_HC05_MasterSlave_v1_7x.ino to keep the main sketch readable.
//
// Notes:
// - This file only declares symbols; implementation is in Wifi_Tabs.ino
// - Do not rename these symbols: they are used from the main sketch.

#include <Arduino.h>

// Keep the same enum values as the original sketch
enum FtMode : uint8_t { FT_OFF=0, FT_AP=1, FT_STA=2 };

// Exposed state used by OLED/status and console
extern FtMode    ft_mode;
extern bool      wifi_ft;

extern String    ft_sta_ssid;
extern String    ft_sta_pass;

extern bool      xferActive;
extern uint32_t  xferLastMs;
extern uint32_t  xferForceUntilMs;
extern uint32_t  ftTcp2Uart;
extern uint32_t  ftUart2Tcp;
extern uint32_t  ftLastPrintMs;

// API used by main sketch
void ftPrintIp();

void wifiFtStartAP(String ssid, String pass);
bool wifiFtStartSTA(const String& ssid, const String& pass);
void wifiFtStop();

void wifiFtTask(HardwareSerial &bt);
void ctrlTask();

// Called from setup() to pre-connect STA (if creds exist) and bring up CTRL server
void wifiCtrlBootInit();
