#pragma once

#if USE_HEADTRACKER

#include "MPU9250.h"
static uint32_t debugHeadTracker = 0;

// an MPU9250 object with the MPU-9250 sensor on I2C bus 0 with address 0x68
MPU9250 IMU(Wire,0x68);
extern int HeadtrackerStatus;

void Headtracker_begin();

void Headtracker_Task();

#endif