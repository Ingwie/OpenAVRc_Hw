/*
Advanced_I2C.ino
Brian R Taylor
brian.taylor@bolderflight.com

Copyright (c) 2017 Bolder Flight Systems

Permission is hereby granted, free of charge, to any person obtaining a copy of this software 
and associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, 
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or 
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING 
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#if USE_HEADTRACKER
#include "Headtracker.h"

void Headtracker_begin() {
  // start communication with IMU 
  HeadtrackerStatus = IMU.begin();
  if (HeadtrackerStatus < 0) {
    Dbg.println("IMU initialization unsuccessful");
    Dbg.println("Check IMU wiring or try cycling power");
    Dbg.print("Status: ");
    Dbg.println(HeadtrackerStatus);
    return;
  }
  // setting the accelerometer full scale range to +/-8G 
  IMU.setAccelRange(MPU9250::ACCEL_RANGE_8G);
  // setting the gyroscope full scale range to +/-500 deg/s
  IMU.setGyroRange(MPU9250::GYRO_RANGE_500DPS);
  // setting DLPF bandwidth to 20 Hz
  IMU.setDlpfBandwidth(MPU9250::DLPF_BANDWIDTH_20HZ);
  // setting SRD to 19 for a 50 Hz update rate
  IMU.setSrd(19);
}

void Headtracker_Task() {
  // read the sensor
  IMU.readSensor();

  // display the data
#if 0
  if (millis() - debugHeadTracker >= 1000) {
    Dbg.print("oooO Debug Heatracker Oooo\r\n");
    Dbg.print(IMU.getAccelX_mss(),6);
    Dbg.print("\t");
    Dbg.print(IMU.getAccelY_mss(),6);
    Dbg.print("\t");
    Dbg.print(IMU.getAccelZ_mss(),6);
    Dbg.print("\t");
    Dbg.print(IMU.getGyroX_rads(),6);
    Dbg.print("\t");
    Dbg.print(IMU.getGyroY_rads(),6);
    Dbg.print("\t");
    Dbg.print(IMU.getGyroZ_rads(),6);
    Dbg.print("\t");
    Dbg.print(IMU.getMagX_uT(),6);
    Dbg.print("\t");
    Dbg.print(IMU.getMagY_uT(),6);
    Dbg.print("\t");
    Dbg.print(IMU.getMagZ_uT(),6);
    Dbg.print("\t");
    Dbg.println(IMU.getTemperature_C(),6);
  }
#endif
}

#endif
