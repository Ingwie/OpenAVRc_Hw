#pragma once
#if (USE_ESP32 == ESP32S3)

#include <Arduino.h>

// Simple non-blocking joystick learning helper.
// Learns which raw HID report offsets correspond to 4 primary axes (CH1..CH4)
// by asking the user to move each control in sequence. Stores a small profile in NVS.
//
// Commands (handled by usbHandleCmd in main):
//   joylearn 1        -> start learning wizard
//   joylearn 0        -> stop/cancel
//   joylearn status   -> print current wizard status
//   joylearn save     -> save learned profile to NVS (also auto-saves at the end)
//   joylearn clear    -> erase stored profile
//
// Notes:
// - This is intentionally minimal and safe. It does NOT change the existing
//   joystick decoding logic until you explicitly decide to apply the profile.

// ---------------- Profile stored in NVS ----------------
struct JoyLearnProfile {
  uint32_t magic;        // 'JLY1'
  uint16_t reportLen;    // last seen report length
  uint8_t  axisOff[4];   // offsets for int16 LE axes
  int16_t  center[4];    // center values captured at start of each step
  uint8_t  valid;        // 1 if profile completed
  uint8_t  reserved[7];  // padding
};
// ---------------- FRAM JoyProf storage (MB85RC256V) ----------------
// Types are declared in the header on purpose: the Arduino preprocessor may
// auto-generate prototypes before Joystick_Learner.ino is parsed, so these
// structs must be visible early.

#ifndef JOYPROF_FRAM_ADDR
#define JOYPROF_FRAM_ADDR 0x50
#endif

#define JOYPROF_SLOTS     8
#define JOYPROF_NAME_LEN  20

// FRAM layout
static const uint16_t JPF_HDR_ADDR   = 0x0000;
static const uint16_t JPF_SLOT_ADDR  = 0x0100;

// Header (small)
struct JpfHeader {
  uint32_t magic;      // 'JPF1'
  uint8_t  version;    // 1
  uint8_t  slots;      // 8
  uint16_t recSize;    // sizeof(JpfRecord)
  uint16_t crc;        // CRC16 over bytes [0..(sizeof-2)]
  uint16_t reserved;
};

// One record per slot
struct JpfRecord {
  uint32_t recMagic;                 // 'JPR1'
  uint16_t seq;                      // increment each save
  uint8_t  valid;                    // 1=valid
  uint8_t  reserved0;
  char     name[JOYPROF_NAME_LEN+1]; // 0-terminated
  JoyLearnProfile prof;              // your profile
  uint16_t profCrc;                  // CRC16 of prof bytes
  uint16_t recCrc;                   // CRC16 over record bytes excluding recCrc
};

void JoyLearnBegin();
void JoyLearnStop();
void JoyLearnTick();
bool JoyLearnIsActive();
void JoyLearnHandleCmd(const String& rest);

// JSON export/import of the learned profile (copy/paste via console)
void JoyProfExportAll();          // prints JSON to Dbg
void JoyProfBeginImport();        // enter import mode (paste JSON then END)
void JoyProfHandleImportLine(const String& line);
bool JoyProfIsImporting();


// JoyProf commands (NVS + FRAM)
void JoyProfHandleCmd(const String& rest);
#endif
