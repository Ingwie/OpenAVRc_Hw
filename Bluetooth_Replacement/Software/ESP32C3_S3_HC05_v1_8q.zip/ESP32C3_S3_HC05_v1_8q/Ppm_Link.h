#pragma once
#include <Arduino.h>

// Binary PPM packet over ESPNOW (PPM->PPM direct) with CRC16.
// Payload is carried inside Packet.payload with type PKT_PPM.

struct __attribute__((packed)) PpmBinPayload {
  uint8_t  magic;      // 0xA5
  uint8_t  seq;        // increments each frame
  uint16_t ch_us[8];   // 1000..2000us typical
  uint16_t crc;        // CRC16-CCITT over bytes [0..sizeof-3]
};

static inline uint16_t ppm_crc16_ccitt(const uint8_t* data, size_t len) {
  uint16_t crc = 0xFFFF;
  for (size_t i = 0; i < len; i++) {
    crc ^= (uint16_t)data[i] << 8;
    for (int b = 0; b < 8; b++) {
      crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021) : (uint16_t)(crc << 1);
    }
  }
  return crc;
}
