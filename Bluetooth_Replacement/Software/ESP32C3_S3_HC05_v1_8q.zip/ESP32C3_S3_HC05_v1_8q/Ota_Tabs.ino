// ============================================================================
// Ota_Tabs.ino
// ----------------------------------------------------------------------------
// OTA (Over-The-Air) update support for ESP32-C3.
//
// This module provides a time-limited OTA "window" that can be enabled by:
//   - Console command:  ota 1   (enable for default duration, see main sketch)
//   - Long-press button shortcut (implemented in main sketch)
//   - Potential future UI actions
//
// While the OTA window is active, the main sketch can temporarily suspend
// time-critical signal generators (PPM/SBUS) and/or data forwarding so that
// ArduinoOTA.handle() can run frequently and reliably during upload.
//
// IMPORTANT:
// - OTA requires WiFi STA connectivity on the same LAN as the PC running espota.
// - OTA is only *handled* while the OTA window is active (OtaWindowIsActive()).
// - When the OTA window expires, the module automatically stops WiFi if it was
//   started specifically for OTA.
//
// This file intentionally does not change any non-OTA behavior.
// ============================================================================

#include <Arduino.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <ESPmDNS.h>
#include <ArduinoOTA.h>


// Forward declarations (Arduino concatenates all .ino files into one compilation unit)
static void espnowStop();
static void espnowStart();
void PpmMasterSuspendForOta(bool suspend);
void SbusMasterSuspendForOta(bool suspend);
void PpmSlaveSuspendForOta(bool suspend);
void SbusSlaveSuspendForOta(bool suspend);
extern uint8_t cfg_role;   // 1=MASTER, 0=SLAVE


#include "Ota_Tabs.h"
#include "Wifi_Tabs.h"   // wifiFtStop()

#if USE_OTA

// These are provided by the main sketch
extern String cfg_name;
extern bool   wifi_ft;

// OTA window state
static bool     otaWindowActive   = false;
static bool     otaInited         = false;
static bool otaNeedBegin = false;   // delay ArduinoOTA.begin() until WiFi is connected
static bool     otaStartedFt      = false;   // true if we started WiFi-STA/FT just for OTA
static uint32_t otaWindowMs       = 0;
static uint32_t otaWindowStartMs  = 0;
// True once we've suspended runtime I/O (ESPNOW/PPM/SBUS) for an OTA window.
// Prevents double suspend/resume calls.
static bool     otaDidSuspend     = false;

// Defaults that match the Arduino IDE espota.exe parameters seen in the logs.
// If you change these, the "Network Port" entry in Arduino IDE may also change.
static const uint16_t OTA_PORT = 3232;

// OTA password (must match espota.exe --auth=...)
// Set to "" to disable password.
static const char* OTA_PASSWORD = "oavrc";

// Dedicated OTA handling task (calls ArduinoOTA.handle() frequently)
static TaskHandle_t otaTaskHandle = NULL;

static void OtaLoopTask(void* pv) {
  (void)pv;
  for (;;) {
    if (otaWindowActive && otaInited) {
      ArduinoOTA.handle();
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

static void OtaStartTaskOnce() {
  if (otaTaskHandle) return;
  xTaskCreatePinnedToCore(OtaLoopTask, "OtaLoop", 4096, NULL, 2, &otaTaskHandle, 0);
}


static void otaInitOnce() {
  if (otaInited) return;
  if (WiFi.status() != WL_CONNECTED) return;

  // Use the module name as hostname when possible (nice for discovery).
  // Keep it short and safe: ArduinoOTA hostname must be <= 32 chars.
  String host = cfg_name;
  if (host.length() == 0) host = "OAVRC";
  if (host.length() > 24) host = host.substring(0, 24);
  host += "-OTA";

  ArduinoOTA.setHostname(host.c_str());
  ArduinoOTA.setPort(OTA_PORT);

  if (OTA_PASSWORD && OTA_PASSWORD[0] != '\0') {
    ArduinoOTA.setPassword(OTA_PASSWORD);
  } else {
    ArduinoOTA.setPassword(NULL);
  }

  ArduinoOTA
    .onStart([]() {
      Dbg.println("[OTA] Start");
    })
    .onEnd([]() {
      Dbg.println("[OTA] End");
    })
    .onProgress([](unsigned int progress, unsigned int total) {
      // Lightweight progress indicator (avoid spamming too much)
      static uint32_t last = 0;
      uint32_t now = millis();
      if (now - last > 500) {
        last = now;
        uint32_t pct = (total == 0) ? 0 : (progress * 100UL) / total;
        Dbg.printf("[OTA] %lu%%\r\n", (unsigned long)pct);
      }
    })
    .onError([](ota_error_t error) {
      Dbg.printf("[OTA] Error[%u]\r\n", (unsigned int)error);
    });

  ArduinoOTA.begin();
  otaInited = true;

  // ArduinoOTA.getHostname().c_str() can be String or const char* depending on core.
  // Use a String to keep Dbg.printf() happy.
  String hn = ArduinoOTA.getHostname().c_str();
  Dbg.printf("[OTA] Ready: host=%s ip=%s port=%u\r\n",
                hn.c_str(),
                WiFi.localIP().toString().c_str(),
                (unsigned)OTA_PORT);

  if (OTA_PASSWORD && OTA_PASSWORD[0] != '\0') Dbg.println("[OTA] Auth: ENABLED");
  else                                         Dbg.println("[OTA] Auth: NONE");
}

bool OtaWindowIsActive() {
  return otaWindowActive;
}

void OtaEnableWindowMs(uint32_t ms, bool startedFt) {
  otaWindowActive  = true;
  otaStartedFt     = startedFt;
  otaNeedBegin     = true;  // start ArduinoOTA.begin() once WiFi is connected
  OtaStartTaskOnce();
  // Suspend all time-critical radio/transport tasks during OTA so the network stack can respond quickly.
  // (ESP-NOW shares the WiFi radio; PPM/SBUS may use timers/interrupts that can starve OTA on some setups.)
  if (!otaDidSuspend) {
    espnowStop();
    PpmMasterSuspendForOta(true);
    SbusMasterSuspendForOta(true);
    PpmSlaveSuspendForOta(true);
    SbusSlaveSuspendForOta(true);
    otaDidSuspend = true;
  }
  otaWindowMs      = ms;
  otaWindowStartMs = millis();
}

void OtaDisableWindow() {
  otaWindowActive = false;
  otaNeedBegin = false;

  // Stop WiFi only if it was started specifically for this OTA window.
  if (otaStartedFt) {
    wifiFtStop();
  }
  otaStartedFt = false;
  // Resume suspended tasks
  if (otaDidSuspend) {
    PpmMasterSuspendForOta(false);
    SbusMasterSuspendForOta(false);
    PpmSlaveSuspendForOta(false);
    SbusSlaveSuspendForOta(false);
    otaDidSuspend = false;

    // Re-enable ESP-NOW only when WiFi FT is not active (STA mode keeps ESP-NOW stopped)
    if (!wifi_ft) {
      espnowStart();
    }
  }
}

void OtaTask() {
  if (!otaWindowActive) return;

  // Start ArduinoOTA once WiFi is connected (begin() too early can lead to no response)
  if (otaNeedBegin && WiFi.status() == WL_CONNECTED) {
    otaInitOnce();
    otaNeedBegin = false;
  }

  // Window timeout
  if (otaWindowMs && (millis() - otaWindowStartMs >= otaWindowMs)) {
    Dbg.println("[OTA] window timeout");
    OtaDisableWindow();
    return;
  }
}

#endif // USE_OTA
