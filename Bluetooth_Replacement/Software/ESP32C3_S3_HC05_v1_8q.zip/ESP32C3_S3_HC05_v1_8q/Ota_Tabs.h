#pragma once
#include <Arduino.h>

#if USE_OTA
// OTA support is isolated from the main application.
// It can run in two cases:
//  1) wifi_ft == true  (existing FileTransfer WiFi mode)
//  2) a temporary "OTA window" enabled from console (ota 1), typically for 60s.
//
// Main sketch must call OtaTask() frequently from loop().
void OtaTask();

// True while an explicit OTA window (console: ota 1) is active.
// Useful to temporarily pause other activities (FT bridge / ESPNOW data path)
// to keep ArduinoOTA.handle() responsive during an upload.
bool OtaWindowIsActive();

// Enable OTA handling for a limited time window (ms).
// If startedFt==true, the caller started WiFi-STA/FT specifically for OTA;
// when the window ends, OtaTask() will stop that WiFi mode automatically.
void OtaEnableWindowMs(uint32_t ms, bool startedFt);

// Disable any active OTA window (and stop WiFi if it was started by ota-window).
void OtaDisableWindow();
#else
// OTA compiled out
inline void OtaTask() {}
inline bool OtaWindowIsActive() { return false; }
inline void OtaEnableWindowMs(uint32_t, bool) {}
inline void OtaDisableWindow() {}
#endif
