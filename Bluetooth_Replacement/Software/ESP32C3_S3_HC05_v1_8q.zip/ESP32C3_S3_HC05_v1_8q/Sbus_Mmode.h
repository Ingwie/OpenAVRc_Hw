#pragma once
#include <Arduino.h>

// SBUS output (MASTER) driven from incoming OpenAVRc trainer "tf ..." frames.
// Enabled only when cfg_role==1 (MASTER role) and cfg_Mmode==SBUS_MASTER.

void SbusMasterBegin();
void SbusMasterFeed(const uint8_t* data, int len);
void SbusMasterTask();

// Suspend/resume SBUS output (used for OTA window). When suspended, frames are not sent.
void SbusMasterSuspend(bool en);

// Backward-compatible name used by the main sketch (OTA suspend/resume).
void SbusMasterSuspendForOta(bool suspend);
