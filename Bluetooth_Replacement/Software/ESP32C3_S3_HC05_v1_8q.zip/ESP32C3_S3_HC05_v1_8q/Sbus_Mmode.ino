#include "Sbus_Mmode.h"

// SBUS-master library ("SBUS-master" zip)
//
// Why we use it here:
// - It configures HardwareSerial to SBUS standard (100000 baud, 8E2)
// - It optionally enables inversion on ESP32 (SBUS is typically inverted)
// - It packs the 16x11-bit channel values into a valid 25-byte SBUS frame
//
// In this file we keep the existing OpenAVRc "tf ..." line reassembly and
// channel extraction, and simply call SBUS::write() at 15ms period.
#include <SBUS.h>

// These are defined in the main .ino
extern HardwareSerial BT;
extern uint8_t cfg_role;   // 0 slave, 1 master
extern uint8_t cfg_Mmode;  // CPPM_MASTER / SBUS_MASTER / HC05_MASTER
extern bool    dbg_bt;

// -----------------------------------------------------------------------------
// SBUS parameters
// -----------------------------------------------------------------------------
static const uint32_t SBUS_BAUD = 100000;
// Frame length/start/end are managed by SBUS::write() from the library.

// NOTE: SBUS is usually inverted (logical). ESP32 core may or may not support TX inversion API.
// Keep software inversion OFF here; use external inverter if needed.
// If your core supports inversion, you can enable it in the main sketch or here.
static const bool SBUS_TX_INVERT_HINT = true;

static uint16_t sbusCh[16];               // 0..2047 (raw SBUS channel values)
static SBUS     sbus(BT);                 // SBUS TX engine (library)
static uint32_t lastSendMs = 0;
static bool     SbusInited = false;
static bool     SbusSuspended = false;       // true during OTA window to stop SBUS output


static inline uint16_t clamp11(uint16_t v) { return (v > 2047) ? 2047 : v; }

static void sbusPackAndSend() {
  // Library handles packing + 25-byte framing.
  uint16_t ch[16];
  for (int i = 0; i < 16; i++) ch[i] = clamp11(sbusCh[i]);
  sbus.write(ch);
}

static bool sbusSuspendedByOta = false;

void SbusMasterSuspendForOta(bool suspend)
{
  if (suspend) {
    if (sbusSuspendedByOta) return;
    sbusSuspendedByOta = true;

    // Stop simple : on met la pin TX en INPUT pour couper la sortie SBUS
#ifdef UART_TX
    pinMode(UART_TX, INPUT);
#endif
    return;
  }

  if (!sbusSuspendedByOta) return;
  sbusSuspendedByOta = false;

  if (cfg_role == 1 && cfg_Mmode == SBUS_MASTER) {
    SbusMasterBegin();   // ou la fonction d’init SBUS que tu as
  }
}

static bool parseTfLineToSbus(const char* line) {
  // Expected: "tf sXXXsXXXsXXXsXXXsXXXsXXXsXXXsXXX:CC" (+ optional CR)
  if (!line) return false;
  if (line[0] != 't' || line[1] != 'f' || line[2] != ' ') return false;

  int found = 0;
  const char* p = line;

  while (*p && found < 8) {
    if (*p == 's') {
      if (isxdigit((unsigned char)p[1]) && isxdigit((unsigned char)p[2]) && isxdigit((unsigned char)p[3])) {
        char h[4] = {p[1], p[2], p[3], 0};
        uint16_t v = (uint16_t)strtoul(h, nullptr, 16) & 0x07FF;
        sbusCh[found] = v;
        found++;
        p += 4;
        continue;
      }
    }
    p++;
  }

  // For now, fill remaining channels to neutral.
  for (int i = found; i < 16; i++) sbusCh[i] = 1024;

  // Inject link quality derived from the latest ESPNOW RSSI into channel 8.
  // Channels 1..4 are used for trainer control; channel 8 is free for EdgeTX widget/script use.
  if (found >= 8) {
#if defined (USE_ESPNOW_WIDGET)
    sbusCh[7] = linkStateRssiToSbus(getLinkStateCh8(), (int)last_rssi_dbm);
    //sbusCh[7] = linkStateRssiToSbus(getLinkStateCh8(), (int)-70);
#endif
  }

  if (dbg_bt) {
    Dbg.print("[SBUS] tf->ch: ");
    Dbg.print(found);
    Dbg.print("  ch1=");
    Dbg.print(sbusCh[0]);
    Dbg.print("  last_rssi_dbm=");
    Dbg.print((int)last_rssi_dbm);
#if not defined (USE_ESPNOW_WIDGET)
    Dbg.println();
#else
    int st = getLinkStateCh8();
    uint16_t ch8us = linkStateRssiToUs(st, (int)last_rssi_dbm);
    uint16_t ch8raw = linkStateRssiToSbus(st, (int)last_rssi_dbm);
    Dbg.print("  state=");
    Dbg.print((st == LINK_STATE_CONNECTED) ? "CONNECTED" : "CONNECTING");
    Dbg.print("  ch8_us=");
    Dbg.print(ch8us);
    Dbg.print("  ch8_raw=");
    Dbg.print(ch8raw);
    Dbg.print("  sbusCh8=");
    Dbg.println(sbusCh[7]);
#endif
  }
  return (found > 0);
}

void SbusMasterBegin() {
  if (cfg_role != 1) return;            // only on MASTER device
  if (cfg_Mmode != SBUS_MASTER) return; // only when selected

  // Init UART on BT pins but as SBUS output.
  // NOTE: SBUS is usually *inverted*. If your receiver expects inversion and
  // your hardware does not provide it, set SBUS_TX_INVERT_HINT accordingly or
  // use an external inverter.
  //
  // On ESP32, the SBUS-master library lets us select pins + inversion.
  // UART_RX/UART_TX are provided by the main sketch (typically 4/7).
  sbus.begin(UART_RX, UART_TX, SBUS_TX_INVERT_HINT, SBUS_BAUD);

  // Initialize channels to neutral
  for (int i = 0; i < 16; i++) sbusCh[i] = 1024;

  SbusInited = true;

  // Note about inversion (hardware dependent)
  if (dbg_bt) {
    Dbg.print("[SBUS] OUT init 100000 8E2. Inversion usually required. Hint=");
    Dbg.println(SBUS_TX_INVERT_HINT ? "invert" : "normal");
  }
}

void SbusMasterFeed(const uint8_t* data, int len) {
  if (!SbusInited) return;
  if (!data || len <= 0) return;

  // Reassemble lines; only care about lines starting with "tf "
  for (int i = 0; i < len; i++) {
    char c = (char)data[i];

    if (!tfActive) {
      // look for 't','f',' '
      if (c == 't') { tfActive = true; tfPos = 0; tfLine[tfPos++] = 't'; }
      continue;
    }

    // tfActive: collect until CR/LF
    if (tfPos < (sizeof(tfLine) - 1)) tfLine[tfPos++] = c;

    if (c == '\r' || c == '\n') {
      tfLine[tfPos] = 0;

      // Validate prefix quickly (handle fragmentation: ensure "tf ")
      if (tfLine[0] == 't' && tfLine[1] == 'f' && tfLine[2] == ' ') {
        parseTfLineToSbus(tfLine);
      }

      tfActive = false;
      tfPos = 0;
      continue;
    }

    // If we started with 't' but not a tf line, drop and resync
    if (tfPos == 2 && tfLine[1] != 'f') { tfActive = false; tfPos = 0; }
    if (tfPos == 3 && tfLine[2] != ' ') { tfActive = false; tfPos = 0; }

    // Safety: overflow resets
    if (tfPos >= (sizeof(tfLine) - 1)) { tfActive = false; tfPos = 0; }
  }
}

void SbusMasterTask() {
  if (SbusSuspended) return;
  if (!SbusInited) return;

  uint32_t now = millis();
  // Typical SBUS period ~9-15ms; use 15ms
  if ((now - lastSendMs) >= 15) {
    lastSendMs = now;
    sbusPackAndSend();
  }
}

