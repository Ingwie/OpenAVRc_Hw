#if defined(ARDUINO_ARCH_ESP32)
#include "RCState.h"
#include <Preferences.h>

void RCState::init()
{
	elevator = CENTER_VALUE;
	rudder = CENTER_VALUE;
	aileron = CENTER_VALUE;

	throttle = FAIL_SAFE_VALUE;
 
  channel5_mode = FAIL_SAFE_VALUE;
	flight_mode = FAIL_SAFE_VALUE;
  
	//auto_center = false;

	camera_pitch = CENTER_VALUE;
	camera_yaw = CENTER_VALUE;

  // Load user preferences (camera mode + auto-center).
  // This mirrors the original EEPROM behavior on AVR.
  RCState::loadRcMode();

}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
void RCState::loadRcMode() { 
  Preferences prefs;
  // Read-only session
  if (!prefs.begin("rcmode", true)) {
    // Safe defaults if NVS not ready
    cam_mode = 0;
    camera_mode = CAMERA_MODES::exponent;
    auto_center = false;
    return;
  }

  uint8_t cm = prefs.getUChar("cam_mode", 0);
  bool ac = prefs.getBool("auto_center", false);
  prefs.end();

  cam_mode = (cm <= 2) ? cm : 0;
  switch (cam_mode) {
    case 0: camera_mode = CAMERA_MODES::exponent; break;
    case 1: camera_mode = CAMERA_MODES::slow;     break;
    case 2: camera_mode = CAMERA_MODES::max_min;  break;
  }
  auto_center = ac;
}

// ===========================================================================
// Function role:
// - See header comment for global responsibilities
// - This function participates in system coordination
// - Must not be renamed or refactored without full impact analysis
// ===========================================================================
void RCState::saveRcMode() {
  Preferences prefs;
  if (!prefs.begin("rcmode", false)) return;
  prefs.putUChar("cam_mode", cam_mode);
  prefs.putBool("auto_center", auto_center);
  prefs.end();
}

void RCState::data_updated() {
	if (is_connected == false) {
		throttle = FAIL_SAFE_VALUE;
	}

#if 0
	if (update_iteration > 0) {
		update_iteration = 0;
		hat_tick();
		// Dbg.print("elevator ");
		// Dbg.print(elevator);
		// Dbg.print(" aileron ");
		// Dbg.print(aileron);
		// Dbg.print(" rudder ");
		// Dbg.print(rudder);
		// Dbg.print(" throttle ");
		// Dbg.print(throttle);
		// Dbg.print(" flight mode ");
		// Dbg.print((int)flight_mode);
		// Dbg.print(" channel5 ");
		// Dbg.print(channel5);
		// Dbg.print(" camera_mode ");
		// Dbg.print((int)camera_mode);
		// Dbg.print(" auto-center ");
		// Dbg.print(auto_center);
		// Dbg.print(" camera yaw ");
		// Dbg.print(camera_yaw);
		// Dbg.print(" camera pitch ");
		// Dbg.print(camera_pitch);
		// Dbg.println("");
	}
	else {
		update_iteration++;
	}
#endif
}

void RCState::button_changed(uint8_t but_id) {
	if ((button_state_change_time[but_id] > 100) && (button_state[but_id] == false)) {
		switch (but_id) {
  		case 2: 
  		  channel5_mode = FAIL_SAFE_VALUE;
        flight_mode   = FAIL_SAFE_VALUE;
  		  break;
     
  		//channel 5
    	case 8: channel5_mode = 1000; break;
  		case 10: channel5_mode = 1500; break;
  		case 12: channel5_mode = 2000; break;
     //channel 6
  		case 7: flight_mode = 1000; break;
  		case 9: flight_mode = 1500; break;
  		case 11: flight_mode = 2000; break;

      //channel 7&8
  		case 1: camera_yaw = CENTER_VALUE;camera_pitch = CENTER_VALUE;break;
  		case 6: auto_center = !auto_center;break;
		case 5: camera_mode = CAMERA_MODES::exponent; cam_mode = 0; break;
		case 3: camera_mode = CAMERA_MODES::max_min;  cam_mode = 2; break;
		case 4: camera_mode = CAMERA_MODES::slow;     cam_mode = 1; break;
		}

	}
//  Dbg.print("Button is: ");Dbg.print(but_id);
//  Dbg.print(" Fly Mode is: ");Dbg.print(flight_mode);
//  Dbg.print(" Camera Mode is: ");Dbg.println((uint8_t)camera_mode);
}

void RCState::hat_changed(HAT_POSITION current_hat_position) {
	//Dbg.println("hat_changed");
 
	if ((hat_position == HAT_POSITION::Down || hat_position == HAT_POSITION::DownLeft || hat_position == HAT_POSITION::DownRight) ||
		(hat_position == HAT_POSITION::Up || hat_position == HAT_POSITION::UpLeft || hat_position == HAT_POSITION::UpRight)) {
		up_down_changed = millis();
		//Dbg.println("hat_changed up/down");
	}

	if ((hat_position == HAT_POSITION::Left|| hat_position == HAT_POSITION::DownLeft || hat_position == HAT_POSITION::UpLeft) ||
		(hat_position == HAT_POSITION::Right || hat_position == HAT_POSITION::DownRight|| hat_position == HAT_POSITION::DownLeft)) {
		left_right_changed = millis();
		//Dbg.println("hat_changed left/right");
	}

	if (hat_position == HAT_POSITION::Center) {
		//Dbg.println("hat_changed center");
		up_down_changed = 0;
		left_right_changed = 0;
	}

	hat_position = current_hat_position;
}

void RCState::hat_tick() {
	//Dbg.println("hat_tick");
	/*if (!auto_center && (up_down_changed == 0 || left_right_changed == 0)) {
		return;
	}*/

	bool move_left = (hat_position == HAT_POSITION::Left || hat_position == HAT_POSITION::DownLeft || hat_position == HAT_POSITION::UpLeft) ? true : false;
	bool move_right = (hat_position == HAT_POSITION::Right || hat_position == HAT_POSITION::DownRight || hat_position == HAT_POSITION::UpRight) ? true : false;
	
	bool move_up = (hat_position == HAT_POSITION::Up|| hat_position == HAT_POSITION::UpLeft || hat_position == HAT_POSITION::UpRight) ? true : false;
	bool move_down = (hat_position == HAT_POSITION::Down || hat_position == HAT_POSITION::DownLeft || hat_position == HAT_POSITION::DownRight) ? true : false;

	/*Dbg.print("hat tick left: ");
	Dbg.print(move_left);
	Dbg.print(" right: ");
	Dbg.print(move_right);
	Dbg.print(" up: ");
	Dbg.print(move_up);
	Dbg.print(" down: ");
	Dbg.print(move_down);
	Dbg.println("");*/

	/*Dbg.print("Mode: ");
	Dbg.print((int)camera_mode);

	Dbg.print(" Current camera Pitch: ");
	Dbg.print(camera_pitch);
	Dbg.print(" Yaw: ");
	Dbg.print(camera_yaw);

	Dbg.print(" Step size: ");
	Dbg.print((millis() - up_down_changed) / TIME_STEP_DIVIDER);

	Dbg.println("");*/
	
	//Dbg.println((int)camera_mode);
	switch (camera_mode) {
	case CAMERA_MODES::exponent://0
    //Dbg.println("0");
		//if up, add exponent from millis
		if (move_up) { camera_pitch += (millis() - up_down_changed) / TIME_STEP_DIVIDER; if (camera_pitch > MAX_VALUE) { camera_pitch = MAX_VALUE; } }
		//if down, substract exponent from millis
		if (move_down) { camera_pitch -= (millis() - up_down_changed) / TIME_STEP_DIVIDER; if (camera_pitch < MIN_VALUE) { camera_pitch = MIN_VALUE; } }
		//if left, substract exponen from millis
		if (move_left) { camera_yaw-= (millis() - left_right_changed) / TIME_STEP_DIVIDER; if (camera_yaw < MIN_VALUE) { camera_yaw = MIN_VALUE; } }
		//if right, add exponent from millis
		if (move_right) { camera_yaw += (millis() - left_right_changed) / TIME_STEP_DIVIDER; if (camera_yaw > MAX_VALUE) { camera_yaw = MAX_VALUE; } }
		//if none, aim toward center from millis on both
    //Dbg.println(camera_pitch);
		if (auto_center) {

			if (!move_up && !move_down) {
				if (camera_pitch > CENTER_VALUE) { camera_pitch -= abs(camera_pitch - CENTER_VALUE) / 4; }
				if (camera_pitch < CENTER_VALUE) { camera_pitch += abs(camera_pitch - CENTER_VALUE) / 4;}
			}

			if (!move_left && !move_right) {
				if (camera_yaw > CENTER_VALUE) { camera_yaw -= abs(camera_yaw - CENTER_VALUE) / 4; }
				if (camera_yaw < CENTER_VALUE) { camera_yaw += abs(camera_yaw - CENTER_VALUE) / 4; }
			}
		}
		break;
	case CAMERA_MODES::max_min://2
		//if up, set to max_value
		if (move_up) { camera_pitch = MAX_VALUE; }
		//if down, set to min_value
		if (move_down) { camera_pitch = MIN_VALUE; }
		//if left, set to min_value
		if (move_left) { camera_yaw = MIN_VALUE; }
		//if right, set to max_value
		if (move_right) { camera_yaw = MAX_VALUE; }
		//if none, set to center both

		if (auto_center) {

			if (!move_up && !move_down) { camera_pitch = CENTER_VALUE; }
			if (!move_left && !move_right) { camera_yaw = CENTER_VALUE; }
		}
		break;
	case CAMERA_MODES::slow://1
		//if up, add exponent from constant
		if (move_up) { camera_pitch += SLOW_INCREMENT; if (camera_pitch > MAX_VALUE) { camera_pitch = MAX_VALUE; } }
		//if down, substract exponent from constant
		if (move_down) { camera_pitch -= SLOW_INCREMENT; if (camera_pitch < MIN_VALUE) { camera_pitch = MIN_VALUE; } }
		//if left, substract exponen from constant
		if (move_left) { camera_yaw -= SLOW_INCREMENT; if (camera_yaw < MIN_VALUE) { camera_yaw = MIN_VALUE; } }
		//if right, add exponent from constant
		if (move_right) { camera_yaw += SLOW_INCREMENT; if (camera_yaw > MAX_VALUE) { camera_yaw = MAX_VALUE; } }
		//if none, aim toward center from constant on both

		if (auto_center) {
			if (!move_up && !move_down) {
				if (camera_pitch > CENTER_VALUE) { camera_pitch -= SLOW_INCREMENT; }
				if (camera_pitch < CENTER_VALUE) { camera_pitch += SLOW_INCREMENT; }
			}

			if (!move_left && !move_right) {
				if (camera_yaw > CENTER_VALUE) { camera_yaw -= SLOW_INCREMENT; }
				if (camera_yaw < CENTER_VALUE) { camera_yaw += SLOW_INCREMENT; }
			}
		}
		break;
	}

	/*Dbg.print("new camera pitch ");
	Dbg.print(camera_pitch);
	Dbg.print(" yaw ");
	Dbg.print(camera_yaw);
	Dbg.println("");*/
}

void RCState::OnButtonUp(uint8_t but_id) {
  button_state[but_id] = false;
    const uint32_t now = millis();
  button_state_change_time[but_id] = (uint32_t)(now - button_state_changed[but_id]);
  button_state_changed[but_id] = millis();
  button_changed(but_id);
  if (but_id != 0)
  {
//    Dbg.print("Up: ");
//    Dbg.println(but_id, DEC);    
  }

}

void RCState::OnButtonDn(uint8_t but_id) {
  button_state[but_id] = true;
    const uint32_t now = millis();
  button_state_change_time[but_id] = (uint32_t)(now - button_state_changed[but_id]);
  button_state_changed[but_id] = millis();
  button_changed(but_id);

  if (but_id != 0)
  {
//    Dbg.print("Dn: ");
//    Dbg.println(but_id, DEC);    
  }
}
#endif