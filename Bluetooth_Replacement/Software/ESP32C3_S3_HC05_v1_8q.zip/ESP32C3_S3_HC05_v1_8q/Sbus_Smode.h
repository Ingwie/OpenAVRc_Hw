#pragma once
#include <Arduino.h>

// SBUS input (SLAVE) -> build OpenAVRc trainer "tf ..." line -> send to ESPNOW.
// Enabled only when cfg_role==0 (SLAVE) and cfg_Smode==SBUS_SLAVE.

void SbusSlaveBegin();
void SbusSlaveTask();
