#if (USE_ESP32 == ESP32S3)
/*
  Joystick_HID_S3.ino (using ESP32_USB_Host_HID library, core 3.0.7)
  https://github.com/esp32beans/ESP32_USB_Host_HID
  
  This file:
  - Keeps the SAME API your main project already calls:
      JoystickHidBegin()
      JoystickHidTask()
      JoystickHidGetChannelsUs()
      JoystickHidSetDebugPrint()
  - Uses the ESP32_USB_Host_HID library (no embedded driver sources).
  - Does NOT send ESPNOW itself: it only updates rcs + JoystictOut[].
    Main code keeps full control of sending.

  Requirements:
  - Install the library folder "ESP32_USB_Host_HID" into your Arduino libraries.
  - Make sure you DON'T have another hid_host.h elsewhere (name collision).
*/

#include <Arduino.h>
#include "Joystick_HID_S3.h"
#include "RCState.h"
#include "JoystickConfig.h"

#include "esp_err.h"
#include "usb/usb_host.h"

// IMPORTANT: angle brackets -> Arduino library include search
#include <hid_host.h>

// --- IMPORTANT (Arduino .ino preprocessor) ---
// Arduino IDE 1.8.x auto-generates function prototypes and can place them
// before our includes, which breaks types like hid_host_device_handle_t.
// Providing explicit forward declarations here prevents that.
static void driver_cb(hid_host_device_handle_t dev, const hid_host_driver_event_t event, void *arg);
static void iface_cb (hid_host_device_handle_t dev, const hid_host_interface_event_t event, void *arg);
static void usb_lib_task(void* arg);
static bool fetchRaw(uint8_t* out, size_t outMax, size_t* outLen);

const char * CH_STR[]  = {"DIR", "PROF", "MOT", "AIL","HAT","GUN","POUCE"};


// ---------------- Status flags (OLED/debug) ----------------
volatile bool     g_usb_host_started = false;
volatile bool     g_usb_dev_mounted  = false;
volatile uint32_t g_usb_report_count = 0;

static bool g_joy_dbg_print = false;
void JoystickHidSetDebugPrint(bool en) { g_joy_dbg_print = en; }

// ---------------- Channel cache (us) ----------------
static uint16_t g_ch_us[16];
static volatile bool g_new = false;
static portMUX_TYPE g_mux = portMUX_INITIALIZER_UNLOCKED;


// ---------------- Last raw HID input report (for learning/debug) ----------------
static uint8_t g_last_report[128];
static size_t  g_last_report_len = 0;

bool JoystickHidGetLastReport(uint8_t* out, size_t outMax, size_t* outLen) {
  if (outLen) *outLen = 0;
  if (!out || outMax == 0) return false;
  bool ok = false;
  portENTER_CRITICAL(&g_mux);
  size_t n = g_last_report_len;
  if (n > 0) {
    if (n > outMax) n = outMax;
    memcpy(out, g_last_report, n);
    if (outLen) *outLen = n;
    ok = true;
  }
  portEXIT_CRITICAL(&g_mux);
  return ok;
}

static void setDefaults() {
  portENTER_CRITICAL(&g_mux);
  for (int i = 0; i < 16; i++) g_ch_us[i] = 1500;
  g_ch_us[2] = 1000;
  g_new = false;
  portEXIT_CRITICAL(&g_mux);
}

static inline uint16_t map_u8_to_us(uint8_t v, bool invert=false) {
  uint32_t x = v;
  if (invert) x = 255 - x;
  return (uint16_t)(1000 + (x * 1000U) / 255U);
}
static inline uint16_t map_u10_to_us(uint16_t v, bool invert=false) {
  uint32_t x = v & 0x03FF;
  if (invert) x = 1023 - x;
  return (uint16_t)(1000 + (x * 1000U) / 1023U);
}
static inline uint16_t map_u14_to_us(uint16_t v, bool invert=false) {
  uint32_t x = v & 0x3FFF;
  if (invert) x = 16383 - x;
  return (uint16_t)(1000 + (x * 1000U) / 16383U);
}
static inline uint16_t map_hat_to_us(uint8_t hat) {
  if (hat == 8) return 1500;
  if (hat == 1 || hat == 2 || hat == 3) return 2000;
  if (hat == 5 || hat == 6 || hat == 7) return 1000;
  return 1500;
}

static void decodeJoyReport(const uint8_t* rep, size_t len) {
  if (!rep || len == 0) return;

  // Skip Report ID if present (common)
  if ((len == 9 || len == 10 || len == 8) && rep[0] <= 3) {
    rep += 1;
    len -= 1;
  }

  uint16_t ch[16];
  for (int i = 0; i < 16; i++) ch[i] = 1500;

  if (len == 9) {
    typedef struct __attribute__((packed)) {
      uint16_t buttons;
      uint8_t  hat;
      uint16_t x;
      uint16_t y;
      uint8_t  z;
      uint8_t  throttle;
    } t16k_t;

    const t16k_t* joy = (const t16k_t*)rep;
    ch[0] = map_u14_to_us(joy->x, false);
    ch[1] = map_u14_to_us(joy->y, true);
    ch[2] = map_u8_to_us (joy->throttle, true);
    ch[3] = map_u8_to_us (joy->z, true);
    ch[4] = map_hat_to_us(joy->hat & 0x0F);
    for (int b = 0; b < 11; b++) ch[5 + b] = ((joy->buttons >> b) & 1U) ? 2000 : 1000;
  }
  else if (len == 7) {
    typedef struct __attribute__((packed)) {
      uint32_t x   : 10;
      uint32_t y   : 10;
      uint32_t hat : 4;
      uint32_t z   : 8;
      uint8_t  buttons_a;
      uint8_t  throttle;
      uint8_t  buttons_b;
    } le3dp_t;

    const le3dp_t* joy = (const le3dp_t*)rep;
    ch[0] = map_u10_to_us((uint16_t)joy->x, false);
    ch[1] = map_u10_to_us((uint16_t)joy->y, true);
    ch[2] = map_u8_to_us (joy->throttle, true);
    ch[3] = map_u8_to_us ((uint8_t)joy->z, true);
    ch[4] = map_hat_to_us((uint8_t)joy->hat);
    uint16_t buttons = (uint16_t)joy->buttons_a | ((uint16_t)joy->buttons_b << 8);
    for (int b = 0; b < 11; b++) ch[5 + b] = ((buttons >> b) & 1U) ? 2000 : 1000;
  }
  else if (len >= 8) {
    ch[0] = map_u8_to_us(rep[0], false);
    ch[1] = map_u8_to_us(rep[1], true);
    ch[3] = map_u8_to_us(rep[2], true);
    ch[2] = map_u8_to_us(rep[3], true);
    ch[4] = map_hat_to_us(rep[4] & 0x0F);

    uint32_t buttons = 0;
    buttons |= (uint32_t)rep[5];
    buttons |= (uint32_t)rep[6] << 8;
    buttons |= (uint32_t)rep[7] << 16;
    for (int b = 0; b < 11; b++) ch[5 + b] = ((buttons >> b) & 1U) ? 2000 : 1000;
  } else {
    return;
  }

  portENTER_CRITICAL(&g_mux);
  for (int i = 0; i < 16; i++) g_ch_us[i] = ch[i];
  g_new = true;
  portEXIT_CRITICAL(&g_mux);
}

bool JoystickHidGetChannelsUs(uint16_t* outUs, int maxCh) {
  if (!outUs || maxCh <= 0) return false;
  const int n = (maxCh > 16) ? 16 : maxCh;
  portENTER_CRITICAL(&g_mux);
  for (int i = 0; i < n; i++) outUs[i] = g_ch_us[i];
  portEXIT_CRITICAL(&g_mux);
  return true;
}

// ---------------- USB/HID event handling ----------------
static TaskHandle_t usb_lib_task_h = nullptr;
static QueueHandle_t hid_q = nullptr;
static hid_host_device_handle_t g_dev = nullptr;

typedef struct {
  hid_host_device_handle_t dev;
  bool is_iface;
  hid_host_driver_event_t drv_evt;
  hid_host_interface_event_t if_evt;
} evt_t;

static void driver_cb(hid_host_device_handle_t dev, const hid_host_driver_event_t event, void *arg) {
  (void)arg;
  evt_t e{};
  e.dev = dev;
  e.is_iface = false;
  e.drv_evt = event;
  if (hid_q) xQueueSend(hid_q, &e, 0);
}

static void iface_cb(hid_host_device_handle_t dev, const hid_host_interface_event_t event, void *arg) {
  (void)arg;
  evt_t e{};
  e.dev = dev;
  e.is_iface = true;
  e.if_evt = event;
  if (hid_q) xQueueSend(hid_q, &e, 0);
}

static bool fetchRaw(uint8_t* out, size_t outMax, size_t* outLen) {
  if (!g_dev) return false;
  size_t n = 0;
  esp_err_t err = hid_host_device_get_raw_input_report_data(g_dev, out, outMax, &n);
  if (err != ESP_OK || n == 0) return false;
  *outLen = n;
  return true;
}

static void usb_lib_task(void* arg) {
  (void)arg;
  while (true) {
    uint32_t event_flags = 0;
    esp_err_t err = usb_host_lib_handle_events(portMAX_DELAY, &event_flags);
    if (err != ESP_OK) {
      if (g_joy_dbg_print) Dbg.printf("[USB] lib_handle_events err=%s\r\n", esp_err_to_name(err));
      vTaskDelay(pdMS_TO_TICKS(100));
      continue;
    }
    if (event_flags & USB_HOST_LIB_EVENT_FLAGS_NO_CLIENTS) {
      usb_host_device_free_all();
    }
  }
}

void JoystickHidBegin() {
  setDefaults();

  if (!hid_q) hid_q = xQueueCreate(16, sizeof(evt_t));

  usb_host_config_t host_cfg = {};
  host_cfg.skip_phy_setup = false;
  host_cfg.intr_flags = ESP_INTR_FLAG_LEVEL1;

  esp_err_t err = usb_host_install(&host_cfg);
  if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
    g_usb_host_started = false;
    if (g_joy_dbg_print) Dbg.printf("[USB] host_install FAIL (%s)\r\n", esp_err_to_name(err));
    return;
  }
  g_usb_host_started = true;

  if (!usb_lib_task_h) {
    xTaskCreatePinnedToCore(usb_lib_task, "usb_lib", 4096, nullptr, 20, &usb_lib_task_h, 0);
  }

  hid_host_driver_config_t cfg = {};
  cfg.create_background_task = true;
  cfg.task_priority = 5;
  cfg.stack_size = 6 * 1024;
  cfg.core_id = tskNO_AFFINITY;
  cfg.callback = driver_cb;
  cfg.callback_arg = nullptr;

  err = hid_host_install(&cfg);
  if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
    if (g_joy_dbg_print) Dbg.printf("[HID] install FAIL (%s)\r\n", esp_err_to_name(err));
  }

  g_usb_dev_mounted = false;
}

void JoystickHidTask() {
  // --- joydbg: continuous channel visualization (even if joystick doesn't move) ---
  static uint32_t _joydbg_lastPrint = 0;
  const uint32_t _joydbg_now = millis();
  if (g_joy_dbg_print && (uint32_t)(_joydbg_now - _joydbg_lastPrint) >= 200) {
    _joydbg_lastPrint = _joydbg_now;
    // Print the current trainer outputs (last known values)
    Dbg.printf("[JOY CH] AIL:%u PROF:%u MOT:%u DIR:%u HAT:%u GUN:%u POUCE:%u %u\r\n",
               (unsigned)JoystictOut[0], (unsigned)JoystictOut[1], (unsigned)JoystictOut[2], (unsigned)JoystictOut[3],
               (unsigned)JoystictOut[4], (unsigned)JoystictOut[5], (unsigned)JoystictOut[6], (unsigned)JoystictOut[7]);
  }


  // Drain HID events
  evt_t e{};
  while (hid_q && xQueueReceive(hid_q, &e, 0)) {
    if (!e.is_iface) {
      if (e.drv_evt == HID_HOST_DRIVER_EVENT_CONNECTED) {
        g_dev = e.dev;

        hid_host_device_config_t devcfg = {};
        devcfg.callback = iface_cb;
        devcfg.callback_arg = nullptr;

        esp_err_t err = hid_host_device_open(g_dev, &devcfg);
        if (err == ESP_OK) err = hid_host_device_start(g_dev);

        if (err == ESP_OK) {
          g_usb_dev_mounted = true;
          if (g_joy_dbg_print) Dbg.println("[HID] CONNECTED");
        } else {
          g_usb_dev_mounted = false;
          g_dev = nullptr;
          if (g_joy_dbg_print) Dbg.printf("[HID] open/start FAIL (%s)\r\n", esp_err_to_name(err));
        }
      }
    } else {
      if (e.if_evt == HID_HOST_INTERFACE_EVENT_INPUT_REPORT) {
        uint8_t buf[64];
        size_t n = 0;
        if (fetchRaw(buf, sizeof(buf), &n)) {
          // keep a copy of last raw report for learner/debug
          portENTER_CRITICAL(&g_mux);
          size_t nn = n;
          if (nn > sizeof(g_last_report)) nn = sizeof(g_last_report);
          memcpy(g_last_report, buf, nn);
          g_last_report_len = nn;
          portEXIT_CRITICAL(&g_mux);

          decodeJoyReport(buf, n);
          portENTER_CRITICAL(&g_mux);
          g_usb_report_count = g_usb_report_count + 1;
          portEXIT_CRITICAL(&g_mux);
        }
      } else if (e.if_evt == HID_HOST_INTERFACE_EVENT_DISCONNECTED) {
        g_usb_dev_mounted = false;
        g_dev = nullptr;
        if (g_joy_dbg_print) Dbg.println("[HID] DISCONNECTED");
        setDefaults();
      }
    }
  }

  // Update rcs + JoystictOut[] like your current code expects
  uint16_t joyUs[16];
  if (!JoystickHidGetChannelsUs(joyUs, 16)) return;

  rcs.aileron  = (int)joyUs[0];
  rcs.elevator = (int)joyUs[1];
  rcs.throttle = (int)joyUs[2];
  rcs.rudder   = (int)joyUs[3];

  for (int i = 0; i < 8; i++) JoystictOut[i] = 1500;

  JoystictOut[AileronNbChannel]  = (uint16_t)rcs.aileron;
  JoystictOut[ElevatorNbChannel] = (uint16_t)rcs.elevator;
  JoystictOut[ThrottleNbChannel] = (uint16_t)rcs.throttle;
  JoystictOut[RudderNbChannel]   = (uint16_t)rcs.rudder;

  JoystictOut[4] = joyUs[4];
  JoystictOut[5] = joyUs[5];
  JoystictOut[6] = joyUs[6];
  JoystictOut[7] = joyUs[7];

  // ---- Send TF frame (like cmdSg), based on real joystick channels ----
  if (linked_peer_set || bound_peer_set) {

    tfMute = false;   // like cmdSg()

    static uint32_t gen_last_ms = 0;
    uint32_t now = millis();
    if ((uint32_t)(now - gen_last_ms) >= 20) {   // 50 Hz
      gen_last_ms = now;

      char frame[80];
      buildTfFrame(JoystictOut, frame, sizeof(frame));

      const uint8_t* dst = linked_peer_set ? linked_peer_mac : bound_peer_mac;
      sendPkt(dst, PKT_DATA, frame, (uint16_t)strlen(frame));

      if (dbg_bt) {
        Dbg.print("[DATA-TX] ");
        Dbg.println(frame);
      }
    }
  }

}

// ----------------------------------------------------------------------------
// Proper shutdown (used by 'joy 0')
// ----------------------------------------------------------------------------
void JoystickHidEnd(bool powerOffVbus)
{
  // Best-effort: stop device first
  if (g_dev) {
    // Stop/close may fail if not started; ignore errors
    hid_host_device_stop(g_dev);
    hid_host_device_close(g_dev);
    g_dev = nullptr;
  }

  // Uninstall HID host driver (ignore INVALID_STATE)
  esp_err_t err = hid_host_uninstall();
  (void)err;

  // Stop USB library task
  if (usb_lib_task_h) {
    vTaskDelete(usb_lib_task_h);
    usb_lib_task_h = nullptr;
  }

  // Delete event queue
  if (hid_q) {
    vQueueDelete(hid_q);
    hid_q = nullptr;
  }

  // Uninstall USB host stack (ignore INVALID_STATE)
  usb_host_uninstall();

  // Optional: cut VBUS to force joystick power-down/disconnect
  if (powerOffVbus) {
  #ifdef VBUS_EN
    pinMode(VBUS_EN, OUTPUT);
    digitalWrite(VBUS_EN, LOW);
  #endif
  }
	  

  // Reset status flags + channel defaults so OLED shows OFF/NO
  g_usb_host_started = false;
  g_usb_dev_mounted  = false;
  g_usb_report_count = 0;
  setDefaults();
}

#endif