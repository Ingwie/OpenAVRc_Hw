#pragma once
#include <Arduino.h>

// Must be visible before Arduino auto-generated function prototypes.
struct __attribute__((packed)) HelloInfo {
  uint8_t role;      // 0=SLAVE, 1=MASTER
  uint8_t mmode;     // cfg_Mmode (MASTER output mode)
  uint8_t smode;     // cfg_Smode (SLAVE input mode)
  uint8_t flags;     // reserved (bit0 can be used for PPM2PPM, etc.)
  uint8_t crc8;      // XOR checksum over bytes [0..3]
};

static inline uint8_t crc8_xor4(uint8_t a, uint8_t b, uint8_t c, uint8_t d) {
  return (uint8_t)(a ^ b ^ c ^ d);
}
