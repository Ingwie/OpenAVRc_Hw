/*
 * Sbus_Smode.ino
 * ------------------------------------------------------------
 * SLAVE MODE - SBUS INPUT DECODER
 *
 * This module reads a real SBUS signal from a SLAVE radio
 * (e.g. EdgeTX / TX16S) and converts it into internal channel
 * values usable by the rest of the system.
 *
 * Functional role in the project:
 * - Configures a UART in SBUS mode (100kbaud, 8E2).
 * - Reads and validates SBUS frames.
 * - Extracts channel values and normalizes them.
 * - Makes the decoded channels available for conversion
 *   into tf frames or other formats.
 *
 * This file DOES NOT:
 * - Generate SBUS output
 * - Handle PPM
 * - Perform ESPNOW transmission directly
 *
 * Robust frame validation is critical here.
 * ------------------------------------------------------------
 */

#include "Sbus_Smode.h"

// Provided by main sketch (same translation unit)
extern HardwareSerial BT;
extern uint8_t cfg_role;    // 0 slave, 1 master
extern uint8_t cfg_Smode;   // CPPM_SLAVE / SBUS_SLAVE / HC05_SLAVE
extern const int UART_RX;
extern const int UART_TX;
extern bool dbg_bt;

// from main
static void buildTfFrame(const uint16_t ch[8], char* out, size_t outSz);
static void sendPkt(const uint8_t mac[6], uint8_t type, const void* data, uint16_t len, uint8_t flags);

// link state from main
extern bool linked_peer_set;
extern bool bound_peer_set;
extern uint8_t linked_peer_mac[6];
extern uint8_t bound_peer_mac[6];

static const uint32_t SBUS_S_BAUD = 100000;
static const bool     SBUS_S_INVERT_RX = true;   // set false if you have external inversion
static const uint8_t  SBUS_S_FRAME_LEN = 25;
static const uint8_t  SBUS_S_STARTBYTE = 0x0F;
static const uint8_t  SBUS_S_ENDBYTE   = 0x00;

static uint8_t sbusS_buf[SBUS_S_FRAME_LEN];
static uint8_t sbusS_pos = 0;
static uint32_t sbusS_lastByteMs = 0;
static bool sbusS_inited = false;
static bool sbusS_suspendedByOta = false; // OTA window: temporarily stop SBUS input decoding


static uint16_t sbusS_ch11[16];
static bool sbusS_failsafe = false;
static bool sbusS_frameLost = false;

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static inline uint16_t sbusS_clampU16(uint16_t v, uint16_t lo, uint16_t hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

// Map 11-bit (0..2047) to microseconds (1000..2000)
  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static inline uint16_t sbusS_map11ToUs(uint16_t v11) {
  uint32_t us = 1000UL + (uint32_t)v11 * 1000UL / 2047UL;
  return (uint16_t)sbusS_clampU16((uint16_t)us, 1000, 2000);
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static bool sbusS_decodeFrame(const uint8_t *f) {
  if (f[0] != SBUS_S_STARTBYTE) return false;
  if (f[24] != SBUS_S_ENDBYTE)  return false;

  sbusS_ch11[0]  = ((f[1]    | f[2]  << 8)                         & 0x07FF);
  sbusS_ch11[1]  = ((f[2]>>3 | f[3]  << 5)                         & 0x07FF);
  sbusS_ch11[2]  = ((f[3]>>6 | f[4]  << 2 | f[5]  << 10)           & 0x07FF);
  sbusS_ch11[3]  = ((f[5]>>1 | f[6]  << 7)                         & 0x07FF);
  sbusS_ch11[4]  = ((f[6]>>4 | f[7]  << 4)                         & 0x07FF);
  sbusS_ch11[5]  = ((f[7]>>7 | f[8]  << 1 | f[9]  << 9)            & 0x07FF);
  sbusS_ch11[6]  = ((f[9]>>2 | f[10] << 6)                         & 0x07FF);
  sbusS_ch11[7]  = ((f[10]>>5| f[11] << 3)                         & 0x07FF);
  sbusS_ch11[8]  = ((f[12]   | f[13] << 8)                         & 0x07FF);
  sbusS_ch11[9]  = ((f[13]>>3| f[14] << 5)                         & 0x07FF);
  sbusS_ch11[10] = ((f[14]>>6| f[15] << 2 | f[16] << 10)           & 0x07FF);
  sbusS_ch11[11] = ((f[16]>>1| f[17] << 7)                         & 0x07FF);
  sbusS_ch11[12] = ((f[17]>>4| f[18] << 4)                         & 0x07FF);
  sbusS_ch11[13] = ((f[18]>>7| f[19] << 1 | f[20] << 9)            & 0x07FF);
  sbusS_ch11[14] = ((f[20]>>2| f[21] << 6)                         & 0x07FF);
  sbusS_ch11[15] = ((f[21]>>5| f[22] << 3)                         & 0x07FF);

  uint8_t flags = f[23];
  sbusS_frameLost = (flags & (1 << 2)) != 0;
  sbusS_failsafe  = (flags & (1 << 3)) != 0;
  return true;
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
static bool sbusS_feed(uint8_t b) {
  uint32_t now = millis();
  if (sbusS_pos && (now - sbusS_lastByteMs) > 4) sbusS_pos = 0; // gap resync
  sbusS_lastByteMs = now;

  if (sbusS_pos == 0) {
    if (b != SBUS_S_STARTBYTE) return false;
    sbusS_buf[sbusS_pos++] = b;
    return false;
  }

  sbusS_buf[sbusS_pos++] = b;
  if (sbusS_pos >= SBUS_S_FRAME_LEN) {
    sbusS_pos = 0;
    return sbusS_decodeFrame(sbusS_buf);
  }
  return false;
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void SbusSlaveBegin() {
  if (cfg_role != 0) return;
  if (cfg_Smode != SBUS_SLAVE) return;

  // Configure BT UART pins as SBUS input
  BT.begin(SBUS_S_BAUD, SERIAL_8E2, UART_RX, UART_TX);
  // RX inversion is supported on ESP32 core 3.x via setRxInvert(bool)
  BT.setRxInvert(SBUS_S_INVERT_RX);

  sbusS_inited = true;

  if (dbg_bt) {
    Dbg.println("[SBUS-S] init: 100000 8E2 on BT UART, building tf->ESPNOW");
  }
}

  // ------------------------------------------------------------
  // Function purpose:
  // - See module header for high-level behavior.
  // - This function is part of the public or internal API
  //   of this module and must not be renamed or moved.
  // ------------------------------------------------------------
void SbusSlaveTask() {
  if (!sbusS_inited) return;

  if (sbusS_suspendedByOta) return; // OTA window

  while (BT.available()) {
    uint8_t b = (uint8_t)BT.read();
    if (sbusS_feed(b)) {
      // Convert CH1..CH8 to microseconds and build tf frame
      uint16_t chUs[8];
      for (int i = 0; i < 8; i++) chUs[i] = sbusS_map11ToUs(sbusS_ch11[i]);

      char tf[64];
      buildTfFrame(chUs, tf, sizeof(tf));

      // Send via ESPNOW to peer (same routing as UART autoFlush)
      uint16_t n = (uint16_t)strnlen(tf, sizeof(tf));
      if (n) {
        if (linked_peer_set) sendPkt(linked_peer_mac, PKT_DATA, tf, n);
        else if (bound_peer_set) sendPkt(bound_peer_mac, PKT_DATA, tf, n);
      }

      if (dbg_bt) {
        Dbg.print("[SBUS-S->ESPNOW] ");
        Dbg.write((const uint8_t*)tf, n);
        Dbg.print(sbusS_failsafe ? " FS" : "");
        Dbg.print(sbusS_frameLost ? " FL" : "");
        Dbg.println();
      }
    }
  }
}

// ------------------------------------------------------------
// Suspend/resume SBUS SLAVE input decoding (used for OTA window)
// - We only gate the task (no UART reconfiguration) to avoid side effects.
// ------------------------------------------------------------
void SbusSlaveSuspendForOta(bool suspend)
{
  sbusS_suspendedByOta = suspend;
  if (!suspend) {
    // If we are still in SBUS_SLAVE, ensure init is done
    if (cfg_role == 0 && cfg_Smode == SBUS_SLAVE) {
      SbusSlaveBegin();
    }
  }
}
