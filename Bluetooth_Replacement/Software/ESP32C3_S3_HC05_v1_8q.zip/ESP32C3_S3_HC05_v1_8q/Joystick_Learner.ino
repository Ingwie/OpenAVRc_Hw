#if (USE_ESP32 == ESP32S3)

#include <Preferences.h>
#include "Joystick_HID_S3.h"
#include "Joystick_Learner.h"
#include <ArduinoJson.h>

extern Preferences prefs;

static bool joyImportMode = false;
static String joyImportBuffer;
static const uint32_t JLY_MAGIC = 0x31594C4A; // 'JYL1' little-endian
static Preferences s_prefs;

#include <Wire.h>

static uint16_t crc16_ccitt(const uint8_t* data, size_t len, uint16_t crc=0xFFFF)
{
  while (len--) {
    crc ^= (uint16_t)(*data++) << 8;
    for (uint8_t i = 0; i < 8; i++) {
      crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021) : (uint16_t)(crc << 1);
    }
  }
  return crc;
}

static bool framWriteBytes(uint16_t memAddr, const uint8_t* data, size_t len)
{
  const size_t CHUNK = 24; // safe with Wire buffers
  size_t off = 0;
  while (off < len) {
    size_t n = min(CHUNK, len - off);
    Wire.beginTransmission(JOYPROF_FRAM_ADDR);
    Wire.write((uint8_t)(memAddr >> 8));
    Wire.write((uint8_t)(memAddr & 0xFF));
    Wire.write(data + off, n);
    if (Wire.endTransmission() != 0) return false;
    memAddr = (uint16_t)(memAddr + n);
    off += n;
  }
  return true;
}

static bool framReadBytes(uint16_t memAddr, uint8_t* data, size_t len)
{
  const size_t CHUNK = 24;
  size_t off = 0;
  while (off < len) {
    size_t n = min(CHUNK, len - off);
    Wire.beginTransmission(JOYPROF_FRAM_ADDR);
    Wire.write((uint8_t)(memAddr >> 8));
    Wire.write((uint8_t)(memAddr & 0xFF));
    if (Wire.endTransmission(false) != 0) return false; // repeated start
    size_t got = Wire.requestFrom(JOYPROF_FRAM_ADDR, (uint8_t)n);
    if (got != n) return false;
    for (size_t i = 0; i < n; i++) data[off + i] = (uint8_t)Wire.read();
    memAddr = (uint16_t)(memAddr + n);
    off += n;
  }
  return true;
}

static bool framReadHeader(JpfHeader& h)
{
  if (!framReadBytes(JPF_HDR_ADDR, (uint8_t*)&h, sizeof(h))) return false;
  uint16_t crc = crc16_ccitt((const uint8_t*)&h, sizeof(h) - 2);
  if (h.magic != 0x3146504AUL) return false; // 'JPF1' little-endian
  if (h.version != 1) return false;
  if (h.slots != JOYPROF_SLOTS) return false;
  if (h.recSize != sizeof(JpfRecord)) return false;
  if (h.crc != crc) return false;
  return true;
}

static bool framWriteHeader()
{
  JpfHeader h{};
  h.magic = 0x3146504AUL; // 'JPF1'
  h.version = 1;
  h.slots = JOYPROF_SLOTS;
  h.recSize = (uint16_t)sizeof(JpfRecord);
  h.reserved = 0;
  h.crc = crc16_ccitt((const uint8_t*)&h, sizeof(h) - 2);
  return framWriteBytes(JPF_HDR_ADDR, (const uint8_t*)&h, sizeof(h));
}

static bool framInitIfNeeded()
{
  JpfHeader h;
  if (framReadHeader(h)) return true;
  // initialize fresh header + clear slots
  if (!framWriteHeader()) return false;
  JpfRecord blank{};
  blank.recMagic = 0x3152504AUL; // 'JPR1'
  blank.valid = 0;
  blank.seq = 0;
  blank.name[0] = 0;
  blank.profCrc = 0;
  // recCrc computed over record excluding recCrc
  blank.recCrc = crc16_ccitt((const uint8_t*)&blank, sizeof(blank) - 2);
  for (uint8_t i = 0; i < JOYPROF_SLOTS; i++) {
    uint16_t addr = (uint16_t)(JPF_SLOT_ADDR + i * sizeof(JpfRecord));
    if (!framWriteBytes(addr, (const uint8_t*)&blank, sizeof(blank))) return false;
  }
  return true;
}

static bool framSlotRead(uint8_t slot1, JpfRecord& rec)
{
  if (slot1 < 1 || slot1 > JOYPROF_SLOTS) return false;
  if (!framInitIfNeeded()) return false;
  uint16_t addr = (uint16_t)(JPF_SLOT_ADDR + (slot1 - 1) * sizeof(JpfRecord));
  if (!framReadBytes(addr, (uint8_t*)&rec, sizeof(rec))) return false;
  // validate
  if (rec.recMagic != 0x3152504AUL) return false; // 'JPR1'
  uint16_t rcrc = crc16_ccitt((const uint8_t*)&rec, sizeof(rec) - 2);
  if (rec.recCrc != rcrc) return false;
  if (rec.valid != 1) return true; // empty but readable
  uint16_t pcrc = crc16_ccitt((const uint8_t*)&rec.prof, sizeof(rec.prof));
  if (rec.profCrc != pcrc) return false;
  return true;
}

static bool framSlotWrite(uint8_t slot1, const char* name, const JoyLearnProfile& prof)
{
  if (slot1 < 1 || slot1 > JOYPROF_SLOTS) return false;
  if (!framInitIfNeeded()) return false;

  JpfRecord rec{};
  JpfRecord old{};
  uint16_t addr = (uint16_t)(JPF_SLOT_ADDR + (slot1 - 1) * sizeof(JpfRecord));
  // read old seq if possible (ignore errors)
  if (framReadBytes(addr, (uint8_t*)&old, sizeof(old)) && old.recMagic == 0x3152504AUL) {
    rec.seq = (uint16_t)(old.seq + 1);
  } else rec.seq = 1;

  rec.recMagic = 0x3152504AUL; // 'JPR1'
  rec.valid = 1;
  rec.reserved0 = 0;
  memset(rec.name, 0, sizeof(rec.name));
  if (name && name[0]) {
    strncpy(rec.name, name, JOYPROF_NAME_LEN);
    rec.name[JOYPROF_NAME_LEN] = 0;
  }
  rec.prof = prof;
  rec.profCrc = crc16_ccitt((const uint8_t*)&rec.prof, sizeof(rec.prof));
  rec.recCrc = crc16_ccitt((const uint8_t*)&rec, sizeof(rec) - 2);
  return framWriteBytes(addr, (const uint8_t*)&rec, sizeof(rec));
}

static bool framSlotErase(uint8_t slot1)
{
  if (slot1 < 1 || slot1 > JOYPROF_SLOTS) return false;
  if (!framInitIfNeeded()) return false;
  JpfRecord blank{};
  blank.recMagic = 0x3152504AUL; // 'JPR1'
  blank.valid = 0;
  blank.seq = 0;
  blank.name[0] = 0;
  blank.profCrc = 0;
  blank.recCrc = crc16_ccitt((const uint8_t*)&blank, sizeof(blank) - 2);
  uint16_t addr = (uint16_t)(JPF_SLOT_ADDR + (slot1 - 1) * sizeof(JpfRecord));
  return framWriteBytes(addr, (const uint8_t*)&blank, sizeof(blank));
}


// ---------------- Wizard state ----------------
static bool     s_active = false;
static uint8_t  s_step = 0; // 0=idle, 1..4 learning CH1..CH4, 5=done
static uint32_t s_step_start_ms = 0;

static uint8_t  s_base[128];
static size_t   s_base_len = 0;

static JoyLearnProfile s_prof = {};

// For each step, we look for the strongest changing int16 value among unused offsets.
static bool findBestAxisOffset(const uint8_t* base, const uint8_t* cur, size_t n,
                               const uint8_t usedOff[4], uint8_t stepIndex,
                               uint8_t* bestOff, int16_t* bestCenter)
{
  int bestScore = 0;
  uint8_t best = 0xFF;
  int16_t center = 0;

  // simple threshold to avoid noise
  const int TH = 400; // raw int16 delta threshold

  auto isUsed = [&](uint8_t off) -> bool {
    for (int i = 0; i < 4; i++) {
      if (i == stepIndex) continue;
      if (usedOff[i] == off) return true;
    }
    return false;
  };

  for (uint8_t off = 0; off + 1 < n; off++) {
    if (isUsed(off)) continue;

    int16_t b = (int16_t)((uint16_t)base[off] | ((uint16_t)base[off+1] << 8));
    int16_t c = (int16_t)((uint16_t)cur [off] | ((uint16_t)cur [off+1] << 8));
    int d = (int)c - (int)b;
    int ad = (d < 0) ? -d : d;

    if (ad > bestScore) {
      bestScore = ad;
      best = off;
      center = b;
    }
  }

  if (best != 0xFF && bestScore >= TH) {
    *bestOff = best;
    *bestCenter = center;
    return true;
  }
  return false;
}

static void printStepPrompt(uint8_t step)
{
  switch (step) {
    case 1: Dbg.println(F("[JLY] Step 1/4: Move CH1 control (e.g. roll) continuously for 1-2s.")); break;
    case 2: Dbg.println(F("[JLY] Step 2/4: Move CH2 control (e.g. pitch) continuously for 1-2s.")); break;
    case 3: Dbg.println(F("[JLY] Step 3/4: Move CH3 control (e.g. throttle) continuously for 1-2s.")); break;
    case 4: Dbg.println(F("[JLY] Step 4/4: Move CH4 control (e.g. yaw) continuously for 1-2s.")); break;
    default: break;
  }
}

bool JoyLearnLoad(JoyLearnProfile* out)
{
  if (!out) return false;
  if (!s_prefs.begin("joylearn", true)) return false;
  size_t got = s_prefs.getBytesLength("prof");
  if (got != sizeof(JoyLearnProfile)) { s_prefs.end(); return false; }
  s_prefs.getBytes("prof", out, sizeof(JoyLearnProfile));
  s_prefs.end();
  if (out->magic != JLY_MAGIC || out->valid != 1) return false;
  return true;
}

bool JoyLearnSave(const JoyLearnProfile* in)
{
  if (!in) return false;
  if (!s_prefs.begin("joylearn", false)) return false;
  s_prefs.putBytes("prof", in, sizeof(JoyLearnProfile));
  s_prefs.end();
  return true;
}

static void nvsClear()
{
  if (!s_prefs.begin("joylearn", false)) return;
  s_prefs.remove("prof");
  s_prefs.end();
}

void JoyLearnBegin()
{
  s_active = true;
  s_step = 1;
  s_step_start_ms = millis();

  memset(&s_prof, 0, sizeof(s_prof));
  s_prof.magic = JLY_MAGIC;
  s_prof.valid = 0;

  // capture baseline report now (best-effort)
  s_base_len = 0;
  if (!JoystickHidGetLastReport(s_base, sizeof(s_base), &s_base_len) || s_base_len < 4) {
    Dbg.println(F("[JLY] No HID report yet. Move joystick a bit and retry joylearn 1."));
    s_active = false;
    s_step = 0;
    return;
  }
  s_prof.reportLen = (uint16_t)s_base_len;

  Dbg.println(F("[JLY] Learning started. Keep other controls still while moving requested one."));
  printStepPrompt(s_step);
}

void JoyLearnStop()
{
  if (s_active) Dbg.println(F("[JLY] Learning cancelled."));
  s_active = false;
  s_step = 0;
}

bool JoyLearnIsActive() { return s_active; }

void JoyLearnTick()
{
  if (!s_active) return;

  // Require some time to pass to let user move control
  const uint32_t now = millis();
  if ((uint32_t)(now - s_step_start_ms) < 400) return;

  uint8_t cur[128];
  size_t n = 0;
  if (!JoystickHidGetLastReport(cur, sizeof(cur), &n)) return;
  if (n != s_base_len || n < 4) return;

  uint8_t bestOff = 0xFF;
  int16_t bestCenter = 0;

  uint8_t used[4] = { s_prof.axisOff[0], s_prof.axisOff[1], s_prof.axisOff[2], s_prof.axisOff[3] };

  if (findBestAxisOffset(s_base, cur, n, used, (uint8_t)(s_step-1), &bestOff, &bestCenter)) {
    uint8_t idx = (uint8_t)(s_step - 1);
    s_prof.axisOff[idx] = bestOff;
    s_prof.center[idx] = bestCenter;

    Dbg.printf("[JLY] CH%u mapped to int16@%u (center=%d)\r\n", (unsigned)s_step, (unsigned)bestOff, (int)bestCenter);

    // advance
    s_step++;
    s_step_start_ms = now;

    // refresh baseline so next step sees fresh deltas
    memcpy(s_base, cur, n);

    if (s_step <= 4) {
      printStepPrompt(s_step);
      return;
    }

    // done
    s_prof.valid = 1;
    JoyLearnSave(&s_prof);
    Dbg.println(F("[JLY] Done. Profile saved to NVS (namespace 'joylearn', key 'prof')."));
    Dbg.println(F("[JLY] Next step (optional): extend learner for buttons/hat and apply profile in decoder."));
    s_active = false;
    s_step = 0;
  }
}

static void printStatus()
{
  Dbg.printf("[JLY] active=%u step=%u reportLen=%u valid=%u\r\n",
             (unsigned)s_active, (unsigned)s_step, (unsigned)s_prof.reportLen, (unsigned)s_prof.valid);
  if (s_prof.valid) {
    for (int i = 0; i < 4; i++) {
      Dbg.printf("  CH%d: off=%u center=%d\r\n", i+1, (unsigned)s_prof.axisOff[i], (int)s_prof.center[i]);
    }
  }
}

void JoyLearnHandleCmd(const String& rest)
{
  String a = rest;
  a.trim(); a.toLowerCase();

  if (a == "1" || a == "on" || a == "start") { JoyLearnBegin(); return; }
  if (a == "0" || a == "off" || a == "stop") { JoyLearnStop(); return; }
  if (a == "status" || a == "?") { printStatus(); return; }
  if (a == "clear") { nvsClear(); Dbg.println(F("[JLY] profile cleared.")); return; }
  if (a == "load") {
    JoyLearnProfile tmp;
    if (JoyLearnLoad(&tmp)) { s_prof = tmp; Dbg.println(F("[JLY] profile loaded.")); }
    else Dbg.println(F("[JLY] no valid profile."));
    printStatus();
    return;
  }
  if (a == "save") {
    if (s_prof.magic != JLY_MAGIC) s_prof.magic = JLY_MAGIC;
    if (s_prof.valid != 1) Dbg.println(F("[JLY] Warning: profile not complete, saving anyway."));
    JoyLearnSave(&s_prof);
    Dbg.println(F("[JLY] profile saved."));
    return;
  }

  //Dbg.println(F("[JLY] usage: joylearn 1|0|status|load|save|clear"));
  Dbg.println(F("[JOYLEARN] usage:"));
  Dbg.println(F("joylearn 1"));
  Dbg.println(F("joylearn 0"));
  Dbg.println(F("joylearn status"));
  Dbg.println(F("joylearn load"));
  Dbg.println(F("joylearn save"));
  Dbg.println(F("joylearn clear"));
}


// ---------------- JoyProf command handler (NVS + FRAM slots) ----------------
// Commands (main calls JoyProfHandleCmd(rest)):
//   joyprof list                -> list all profiles from Fram"
//   joyprof <n>                 -> load slot n (1..8)
//   joyprof load <n>            -> load profile n"));
//   joyprof save <n> <name>     -> save current NVS profile into slot n with name (no quotes needed if no spaces)
//   joyprof name <n> <name>     -> rename slot n
//   joyprof erase <n>|all       -> erase profile n or all
//   joyprof export              -> JSON export (NVS profile)
//   joyprof import              -> JSON import (writes NVS profile)
void JoyProfHandleCmd(const String& rest)
{
  String s = rest; s.trim();
  if (s.length() == 0) { 
    //Dbg.println(F("[JOYPROF] usage: joyprof list|load n|save n name|name n name|erase n|erase all|export|import")); 
    Dbg.println(F("[JOYPROF] usage:"));
    Dbg.println(F("joyprof list                -> list all profiles from Fram"));
    Dbg.println(F("joyprof <n>                 -> load slot n (1..8)"));
    Dbg.println(F("joyprof load <n>            -> load profile n"));
    Dbg.println(F("joyprof save <n> <name>     -> save current NVS profile into slot n with name (no quotes needed if no spaces)"));
    Dbg.println(F("joyprof name <n> <name>     -> rename slot n"));
    Dbg.println(F("joyprof erase <n>|all       -> erase profile n or all"));
    Dbg.println(F("joyprof export              -> JSON export (NVS profile)"));
    Dbg.println(F("joyprof import              -> JSON import (writes NVS profile)"));
    return; 
  }

  String sl = s; sl.toLowerCase();

  // keep existing JSON import/export
  if (sl == "export") { JoyProfExportAll(); return; }
  if (sl == "import") { JoyProfBeginImport(); return; }

  if (sl == "list") {
    if (!framInitIfNeeded()) { Dbg.println(F("[JOYPROF] FRAM init failed (check I2C addr/power).")); return; }
    Dbg.println(F("[JOYPROF] slots 1..8:"));
    for (uint8_t i = 1; i <= JOYPROF_SLOTS; i++) {
      JpfRecord rec;
      bool ok = framSlotRead(i, rec);
      if (!ok) {
        Dbg.printf("  #%u : <read error>\r\n", i);
        continue;
      }
      if (rec.valid != 1) {
        Dbg.printf("  #%u : <empty>\r\n", i);
        continue;
      }
      Dbg.printf("  #%u : %s\r\n", i, (rec.name[0] ? rec.name : "<noname>"));
    }
    return;
  }

  // tokenize first word
  int sp = sl.indexOf(' ');
  String a = (sp < 0) ? sl : sl.substring(0, sp);
  String b = (sp < 0) ? "" : s.substring(sp + 1); // keep original case for name
  b.trim();

  auto parseSlot = [](const String& t)->int {
    String tt=t; tt.trim();
    if (tt.length()==0) return -1;
    int n = tt.toInt();
    if (n < 1 || n > (int)JOYPROF_SLOTS) return -1;
    return n;
  };

  if (a == "load") {
    int n = parseSlot(b);
    if (n < 0) { Dbg.println(F("[JOYPROF] usage: joyprof load <1..8>")); return; }
    JpfRecord rec;
    if (!framSlotRead((uint8_t)n, rec) || rec.valid != 1) { Dbg.println(F("[JOYPROF] slot empty or invalid.")); return; }
    // Save to NVS using existing helper
    JoyLearnProfile p = rec.prof;
    if (p.magic != JLY_MAGIC) p.magic = JLY_MAGIC;
    p.valid = 1;
    if (!JoyLearnSave(&p)) { Dbg.println(F("[JOYPROF] failed to write NVS.")); return; }
    Dbg.printf("[JOYPROF] loaded slot %d (%s) -> NVS\r\n", n, (rec.name[0]?rec.name:"<noname>"));
    return;
  }

  if (a == "save") {
    // format: save <n> <name>
    int sp2 = b.indexOf(' ');
    String nstr = (sp2 < 0) ? b : b.substring(0, sp2);
    String name = (sp2 < 0) ? "" : b.substring(sp2 + 1);
    nstr.trim(); name.trim();
    int n = parseSlot(nstr);
    if (n < 0 || name.length() == 0) { Dbg.println(F("[JOYPROF] usage: joyprof save <1..8> <name>")); return; }
    // load current profile from NVS
    JoyLearnProfile p;
    if (!JoyLearnLoad(&p)) { Dbg.println(F("[JOYPROF] no profile in NVS (run joylearn then joylearn save).")); return; }
    if (!framSlotWrite((uint8_t)n, name.c_str(), p)) { Dbg.println(F("[JOYPROF] FRAM write failed.")); return; }
    Dbg.printf("[JOYPROF] saved NVS profile to slot %d name=%s\r\n", n, name.c_str());
    return;
  }

  if (a == "name") {
    int sp2 = b.indexOf(' ');
    String nstr = (sp2 < 0) ? b : b.substring(0, sp2);
    String name = (sp2 < 0) ? "" : b.substring(sp2 + 1);
    nstr.trim(); name.trim();
    int n = parseSlot(nstr);
    if (n < 0 || name.length() == 0) { Dbg.println(F("[JOYPROF] usage: joyprof name <1..8> <name>")); return; }
    JpfRecord rec;
    if (!framSlotRead((uint8_t)n, rec) || rec.valid != 1) { Dbg.println(F("[JOYPROF] slot empty or invalid.")); return; }
    // rewrite with same profile but new name
    if (!framSlotWrite((uint8_t)n, name.c_str(), rec.prof)) { Dbg.println(F("[JOYPROF] FRAM write failed.")); return; }
    Dbg.printf("[JOYPROF] renamed slot %d to %s\r\n", n, name.c_str());
    return;
  }

  if (a == "erase") {
    if (b.length() == 0) { Dbg.println(F("[JOYPROF] usage: joyprof erase <1..8>|all")); return; }
    String bl = b; bl.toLowerCase(); bl.trim();
    if (bl == "all") {
      bool okAll = true;
      for (uint8_t i = 1; i <= JOYPROF_SLOTS; i++) okAll &= framSlotErase(i);
      Dbg.println(okAll ? F("[JOYPROF] all slots erased.") : F("[JOYPROF] erase failed."));
      return;
    }
    int n = parseSlot(b);
    if (n < 0) { Dbg.println(F("[JOYPROF] usage: joyprof erase <1..8>|all")); return; }
    Dbg.println(framSlotErase((uint8_t)n) ? F("[JOYPROF] slot erased.") : F("[JOYPROF] erase failed."));
    return;
  }

  // Alias: if user typed just a number => load slot
  int maybe = s.toInt();
  if (maybe >= 1 && maybe <= (int)JOYPROF_SLOTS) {
    String tmp = String("load ") + String(maybe);
    JoyProfHandleCmd(tmp);
    return;
  }

  //Dbg.println(F("[JOYPROF] usage: joyprof list|load n|save n name|name n name|erase n|erase all|export|import"));
}
/* JSON IMPORT/EXPORT */
void JoyProfBeginImport()
{
  joyImportMode = true;
  joyImportBuffer = "";
Dbg.println("[JOYPROF] Paste JSON, finish with END");
}

// ================= JSON export/import =================

bool JoyProfIsImporting() { return joyImportMode; }
void JoyProfExportAll()
{
  // Export a single learned profile stored in NVS key "joylearn/prof".
  JoyLearnProfile p;
  if (!JoyLearnLoad(&p)) {
    Dbg.println(F("[JOYPROF] no profile in NVS (run joylearn then joylearn save)."));
    return;
  }

  // ArduinoJson 7.x: prefer JsonDocument (StaticJsonDocument is deprecated but still works)
  JsonDocument doc;
  doc["version"] = 1;

  // Keep format simple: one profile
  JsonObject obj = doc["profile"].to<JsonObject>();
  obj["reportLen"] = p.reportLen;
  obj["valid"] = p.valid;

  JsonArray a1 = obj["axisOff"].to<JsonArray>();
  for (int i = 0; i < 4; i++) a1.add(p.axisOff[i]);

  JsonArray a2 = obj["center"].to<JsonArray>();
  for (int i = 0; i < 4; i++) a2.add(p.center[i]);

  serializeJsonPretty(doc, Serial);
  Dbg.println();
}


void JoyProfHandleImportLine(const String& line)
{
  if (!joyImportMode) return;

  if (line == "END")
  {
    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, joyImportBuffer);

    if (err)
    {
      Dbg.print("[JOYPROF] JSON error: ");
      Dbg.println(err.c_str());
      joyImportMode = false;
    joyImportMode = false;
      return;
    }

    JoyLearnProfile p = {};
    p.magic = JLY_MAGIC;
    p.valid = 1;

    // Accept either {"profile":{...}} or legacy {"profiles":[{...}]}
    JsonVariant vprof = doc["profile"];
    if (vprof.is<JsonObject>()) {
      JsonObject obj = vprof.as<JsonObject>();

      p.reportLen = obj["reportLen"] | 0;
      JsonArray a1 = obj["axisOff"];
      for (int i = 0; i < 4; i++) p.axisOff[i] = (uint8_t)(a1[i] | 0);

      JsonArray a2 = obj["center"];
      for (int i = 0; i < 4; i++) p.center[i] = (int16_t)(a2[i] | 0);

    } else {
      JsonArray arr = doc["profiles"];
      if (!arr.isNull() && arr.size() > 0) {
        JsonObject obj = arr[0];

        p.reportLen = obj["reportLen"] | 0;
        JsonArray a1 = obj["axisOff"];
        for (int i = 0; i < 4; i++) p.axisOff[i] = (uint8_t)(a1[i] | 0);

        JsonArray a2 = obj["center"];
        for (int i = 0; i < 4; i++) p.center[i] = (int16_t)(a2[i] | 0);
      } else {
        Dbg.println(F("[JOYPROF] JSON missing 'profile' object."));
        joyImportMode = false;
    joyImportMode = false;
        return;
      }
    }

    if (JoyLearnSave(&p)) {
      Dbg.println(F("[JOYPROF] Import done (saved to NVS joylearn/prof)."));
    } else {
      Dbg.println(F("[JOYPROF] Import failed (NVS write error)."));
    }

    joyImportMode = false;
    joyImportMode = false;
    return;
  }

  // accumulate
  joyImportBuffer += line;
  joyImportBuffer += "\n";
}


#endif
