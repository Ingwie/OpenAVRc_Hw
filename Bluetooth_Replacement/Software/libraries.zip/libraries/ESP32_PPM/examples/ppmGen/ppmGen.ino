#include <ESP32_PPM.h>

// Channel values in microseconds (1000..2000)
static volatile uint16_t ppmUs[PPM_CH_COUNT] = {1500,1500,1500,1500,1500,1500,1500,1500};

void setup() {
  // External PPM generator (ESP32_PPM library).
  // cfg_ppm selects polarity: CPPM_GEN_POS_MOD (positive) or CPPM_GEN_NEG_MOD (negative).

    Cppm32.begin((cfg_ppm == CPPM_GEN_POS_MOD) ? CPPM_GEN_POS_MOD : CPPM_GEN_NEG_MOD,
                 8, 22500, 300, UART_TX);

  // Push current channels into the generator
  for (uint8_t i = 0; i < 8; i++) {
    Cppm32.width_us(i + 1, ppmUs[i]);
  }
}

void loop()
{
}