
/*
**************************************************************************
*                                                                        *
*                 ____                ___ _   _____                      *
*                / __ \___  ___ ___  / _ | | / / _ \____                 *
*               / /_/ / _ \/ -_) _ \/ __ | |/ / , _/ __/                 *
*               \____/ .__/\__/_//_/_/ |_|___/_/|_|\__/                  *
*                   /_/                                                  *
*                                                                        *
*              This file is part of the OpenAVRc project.                *
*                                                                        *
*                         Based on code(s) named :                       *
*             OpenTx - https://github.com/opentx/opentx                  *
*             Deviation - https://www.deviationtx.com/                   *
*                                                                        *
*                Only AVR code here for visibility ;-)                   *
*                                                                        *
*   OpenAVRc is free software: you can redistribute it and/or modify     *
*   it under the terms of the GNU General Public License as published by *
*   the Free Software Foundation, either version 2 of the License, or    *
*   (at your option) any later version.                                  *
*                                                                        *
*   OpenAVRc is distributed in the hope that it will be useful,          *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of       *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
*   GNU General Public License for more details.                         *
*                                                                        *
*       License GPLv2: http://www.gnu.org/licenses/gpl-2.0.html          *
*                                                                        *
************************************************************************** 
*/

/*
 Libraries used for this project:
 USB_Host_Shield_2.0: https://github.com/felis/USB_Host_Shield_2.0
 Rc-Navy libraries  : (Rcul, TinyPinChange, Cppm) https://github.com/RC-Navy/DigisparkArduinoIntegration/tree/master/libraries
 SoftwareSerial     : https://github.com/PaulStoffregen/SoftwareSerial
 */

/* Version History:
v1.0 Original version
v1.1 add OpenTx/EdgeTx BT option, add Sbus connection

*/

#define PROJECT_NAME    OpenAVRc JoysticReader
#define FW_VERSION      1
#define FW_REVISION     1

#include <usbhid.h>
#include <hiduniversal.h>
#include <usbhub.h>
#include "le3dp_rptparser2.0.h"
#include <SPI.h>

#include "RcModeConfig.h"

//#define DEBUG
// #define AT_INIT_HC05          1
// #define AT_INIT_HM10          1

#define BT_INIT               0
#define PPM                   1
#define SBUS                  2
#define BLUETOOTH_OPENAVRC    3
#define BLUETOOTH_EDGETX      4
#define INPUT_MODE BLUETOOTH_EDGETX //Select BT_INIT, PPM, SBUS or BLUETOOTH_OPENAVRC or BLUETOOTH_EDGETX(not tested)

#if (((AT_INIT_HC05 == 1) || (AT_INIT_HM10 == 1)) && (INPUT_MODE != BT_INIT))
#error "In mode AT_INIT_HC05 or AT_INIT_HM10, select INPUT_MODE->BT_INIT only !"
#endif

#define MODE1                 1
#define MODE2                 2
#define MODE3                 3
#define MODE4                 4
#define TRAINER_MODE          MODE1 //select MODE1 to MODE4

#define SSD_TYPE              0
#define LCD_TYPE              1
#define DISPLAY_TYPE SSD_TYPE

#if (INPUT_MODE == PPM)
#include <Cppm.h>
#define NUM_CHANNELS          8
#define PPM_HEADER_US         300
#define PPM_PERIOD_US         22500
#elif (INPUT_MODE == SBUS)
#define NUM_CHANNELS          16
#include <SoftSBusTxStda.h>
#define SOFT_SBUS_TX_PERIOD_MS  SOFT_SBUS_TX_NORMAL_FRAME_RATE_MS //SOFT_SBUS_TX_NORMAL_FRAME_RATE_MS = 14ms, SOFT_SBUS_TX_HIGH_SPEED_FRAME_RATE_MS = 7ms
#define SOFT_SBUS_TX_POLAR      SOFT_SBUS_TX_POLAR_FUTABA //Futaba need negative pulses
#elif (INPUT_MODE == BLUETOOTH_OPENAVRC) || (INPUT_MODE == BLUETOOTH_EDGETX) ||  (INPUT_MODE == BT_INIT)
#define NUM_CHANNELS          8
#endif

#if ((INPUT_MODE == BLUETOOTH_OPENAVRC) || (INPUT_MODE == BLUETOOTH_EDGETX) || (INPUT_MODE == BT_INIT))
uint16_t BLUETOOTH_OPENAVRC_BAUDS;
#if defined(__AVR_ATmega328P__)
#include <SoftwareSerial.h>
SoftwareSerial BT(7,8);// RX, TX use 57600 maxi
#elif defined(__AVR_ATmega32U4__) 
HardwareSerial & BT = Serial1;// Only with Leonardo board
#endif
#endif

bool Debug = false;

RCState rcs;

USB                        Usb;
USBHub                     Hub(&Usb);
HIDUniversal               Hid(&Usb);
JoystickEvents             JoyEvents;
JoystickReportParser       Joy(&JoyEvents, &rcs);

#if (DISPLAY_TYPE == LCD_TYPE)
#include "LCDDisplay.h"
LCDDisplay disp;
#elif (DISPLAY_TYPE == SSD_TYPE)
#include "SSD1306Display.h"
SSD1306Display disp;
#endif

int16_t channelOutputs[NUM_CHANNELS];
#define FULL_CHANNEL_OUTPUTS(ch) channelOutputs[ch]
uint16_t ppmOut[NUM_CHANNELS];

/**
* \file  misclib.h
* \fn    Macro: BIN_NBL_TO_HEX_DIGIT(BinNbl)
* \brief returns the ASCII Hexa digit corresponding to a nibble value (eg: BIN_NBL_TO_HEX_DIGIT(15) -> 'F'
* \param BinNbl:  The Nibble value (0 to 15)
*/
#define BIN_NBL_TO_HEX_DIGIT(BinNbl)      ((BinNbl) < 10) ? ((BinNbl) + '0'): ((BinNbl) - 10 + 'A')

#define STRING_(string)                 #string
#define PRJ_VER_REV(PrjName, Ver, Rev)  F(STRING_(PrjName) " V" STRING_(Ver) "." STRING_(Rev))

void setup()
{
  disp.setup();
  delay(1000);

  Serial.begin( 115200 );
  Serial.println(PRJ_VER_REV(PROJECT_NAME, FW_VERSION, FW_REVISION));
  
#if !defined(__MIPSEL__)
  while (!Serial); // Wait for serial port to connect - used on Leonardo, Teensy and other boards with built-in USB CDC serial connection
#endif

  Serial.println("Start");
  if (Usb.Init() == -1)
  {
    Serial.println("OSC did not start.");
    disp.display_oerr();    
  }
  delay(200);

  if (!Hid.SetReportParser(0, &Joy))
  {
    ErrorMessage<uint8_t>(PSTR("SetReportParser"), 1  );
    disp.display_herr();    
  }
  else
  {
    disp.display_joystick_connected();
  }
  delay(200);

  AileronNbChannel = (uint8_t)pgm_read_byte(&ChannelOrder[channelsOrder].Aileron);//AILERON + 1;
  ElevatorNbChannel   = (uint8_t)pgm_read_byte(&ChannelOrder[channelsOrder].Elevator);//THROTTLE + 1;
  RudderNbChannel  = (uint8_t)pgm_read_byte(&ChannelOrder[channelsOrder].Rudder);//RUDDER + 1;
  ThrottleNbChannel  = (uint8_t)pgm_read_byte(&ChannelOrder[channelsOrder].Throttle);//RUDDER + 1;


  // Serial.print("Ail:");Serial.print(AileronNbChannel);
  // Serial.print("\tEle:");Serial.print(ElevatorNbChannel);
  // Serial.print("\tRud:");Serial.print(RudderNbChannel);
  // Serial.print("\tThr:");Serial.println(ThrottleNbChannel);
  
  rcs.init();
  
#if (INPUT_MODE == PPM)
  CppmGen.begin(CPPM_GEN_NEG_MOD, NUM_CHANNELS, PPM_PERIOD_US, PPM_HEADER_US);/* Change CPPM_GEN_NEG_MOD (Futaba) to CPPM_GEN_POS_MOD for POSitive PPM modulation */
#endif

#if ((INPUT_MODE == BLUETOOTH_OPENAVRC) || (INPUT_MODE == BLUETOOTH_EDGETX) || (INPUT_MODE == BT_INIT))
#ifdef AT_INIT_HC05
  // #undef INPUT_MODE
  // #undef AT_INIT_HM10
  Serial.begin( 9600 );//need to be < BT speed in this mode
  BT.begin(38400);while (!BT);
  InitBtAuto_Hc05();
  delay(500);
  ReadBTSettings_Hc05();
#endif

#ifdef AT_INIT_HM10
  // #undef INPUT_MODE
  // #undef AT_INIT_HC05
  Serial.begin( 9600 );//need to be < BT speed in this mode
  BT.begin(9600);while (!BT);
  InitHM10Auto_Hm10();
  delay(500);
  ReadBTSettings_Hm10();
#endif
#endif

#if ((INPUT_MODE == BLUETOOTH_OPENAVRC) || (INPUT_MODE == BLUETOOTH_EDGETX) || (INPUT_MODE == BT_INIT))
#if defined(__AVR_ATmega328P__)  
  BT.begin(57600);  while (!BT);// wait for serial port to connect.
#endif
#if defined(__AVR_ATmega32U4__)  
  BT.begin(115200);  while (!BT);// wait for serial port to connect.
#endif
#endif

#if (INPUT_MODE == SBUS)
/* For use Pin 0 (PD1) as SBUS ouput, we need to define into SoftSBusTxStda.h SOFT_SBUS_TX_PIN_PORT_LETTER = D and SOFT_SBUS_TX_PIN_BIT_IN_PORT = 1 */
  SoftSBusTx.begin(SOFT_SBUS_TX_PERIOD_MS, SOFT_SBUS_TX_POLAR);
#endif
}


bool is_connected = true;
int update_now = 0;

void loop()
{
  ReadSerialCmd();

#if (INPUT_MODE == BT_INIT)//work with AT_INIT_HC05 or AT_INIT_HM10
  if (BT.available())  
  Serial.write(BT.read());

  if (Serial.available())  
  BT.write(Serial.read());
#else   
  update_now++;
  //
  int Xval;   // 0 - 1023
  int Yval;   // 0 - 1023
  int Hat;    // 0 - 15;
  int Twist;  // 0 - 255
  int Slider; // 0 - 255
  int Button; // 0 - 12 (0 = No button)
  
  Usb.Task();
  
  if (Usb.getUsbTaskState() == USB_STATE_RUNNING)
  {
    if (is_connected == true)
    {
      //already connected, do nothing
    }
    else
    {
      is_connected = true;
      rcs.is_connected = true;
      Serial.println("joystick connected");
      disp.display_joystick_connected();
      delay(200);
      disp.clear();
    }
  }
  else
  {

    if (is_connected == false)
    {
      //already disconnected, do nothing
    }
    else
    {
      is_connected = false;
      rcs.is_connected = false;
      Serial.println("joystick disconnected");
      disp.display_joystick_disconnected();
      delay(200);
    }
  }  
  
  if (update_now > 15)
  {
    if (is_connected)
    {
      disp.display(rcs.flight_mode, rcs.channel5_mode, (byte)rcs.camera_mode, rcs.auto_center);
      disp.print_all(&rcs);
      delay(100);
      disp.clear();
      //lcd_display.display_rx_rssi(frsky_accessor.link_down);
      //lcd_display.display_tx_rssi(frsky_accessor.link_up);
    }
    update_now = 0;
  }  

  //Use to read joystick input to contaileroner
  //JoyEvents.PrintValues();                                       //Returns joystick values to user
  //JoyEvents.GetValues(Xval, Yval, Hat, Twist, Slider, Button);   //Copies joystick values to user
  JoyEvents.GetValues(Hat, Button);
  
  rcs.data_updated();
  
  rcs.hat_changed((HAT_POSITION) Hat);

  rcs.hat_tick();
  
  rcs.button_changed(Button);
  rcs.OnButtonUp(Button);
  rcs.OnButtonDn(Button);

/*
ElevatorNbChannel;
RudderNbChannel;
AileronNbChannel;
ThrottleNbChannel;
*/
  
  ppmOut[AileronNbChannel] = rcs.aileron;
  ppmOut[ElevatorNbChannel] = rcs.elevator;
  ppmOut[ThrottleNbChannel] = rcs.throttle;
  ppmOut[RudderNbChannel] = rcs.rudder;
  ppmOut[4] = rcs.channel5_mode;
  ppmOut[5] = rcs.flight_mode;
  ppmOut[6] = rcs.camera_pitch;
  ppmOut[7] = rcs.camera_yaw;
#if (INPUT_MODE == SBUS)
  ppmOut[8] = 1500;
  ppmOut[9] = 1500;
  ppmOut[10] = 1500;
  ppmOut[11] = 1500;
  ppmOut[12] = 1500;
  ppmOut[13] = 1500;
  ppmOut[14] = 1500;
  ppmOut[15] = 1500;
#endif

#if (INPUT_MODE == PPM)
    for (uint8_t ch = 0; ch<8;ch++)
    {
      CppmGen.width_us(ch+1, ppmOut[ch]);
    }
#endif

#if (INPUT_MODE == SBUS)
  if(SoftSBusTx.process())
  {
    for(uint8_t ch = 0; ch<16;ch++)
    {
      SoftSBusTx.width_us(ch+1, ppmOut[ch]); /* Set the value to all the 16 SBUS channels */
    }
  }
#endif

#if (INPUT_MODE == BLUETOOTH_OPENAVRC) || (INPUT_MODE == BLUETOOTH_EDGETX)
  BT_Send_Channels();
#endif

#ifdef DEBUG
  Serial.print("Trottle:");
  Serial.print(rcs.throttle);
  Serial.print(" Aileron:");
  Serial.print(rcs.aileron);
  Serial.print(" Elevator:");
  Serial.print(rcs.elevator);
  Serial.print(" Rudder:");
  Serial.print(rcs.rudder);

  Serial.print(" CH5:");
  Serial.print(rcs.channel5_mode);
  Serial.print(" Fly Mode:");
  Serial.print(rcs.flight_mode);
  
  Serial.print(" Camera Mode:");
  Serial.print((uint8_t)rcs.camera_mode);
  Serial.print(" Cam elevator:");
  Serial.print(rcs.camera_pitch);
  Serial.print(" Cam rudder:");
  Serial.println(rcs.camera_yaw);
#endif
#endif

//  Serial.print(" Cam pitch:");
//  Serial.print(ppmOut[6]);
//  Serial.print(" Cam yaw:");
//  Serial.println(ppmOut[7]);  
}// end loop

#if ((INPUT_MODE == BLUETOOTH_OPENAVRC) || (INPUT_MODE == BLUETOOTH_EDGETX))
void BT_Send_Channels()
{
  char txt;
  uint8_t ComputedCheckSum = 0;
  String bt;
  BT.print(F("tf "));
  bt += "tf ";
 
  for(uint8_t Idx = 0; Idx < NUM_CHANNELS; Idx++)
  {

   BT.print('s');
   bt += "s";
   int16_t value = (FULL_CHANNEL_OUTPUTS(Idx))/2; // +-1280 to +-640
   value += ppmOut[Idx];//PPM_CENTER; // + 1500 offset
   ComputedCheckSum ^= 's';
   value <<= 4;
   for(uint8_t j = 12; j ; j-=4)
    {
     txt = BIN_NBL_TO_HEX_DIGIT((value>>j) & 0x0F);
     bt += (String)txt;
     ComputedCheckSum ^= txt;
     BT.print(txt);
    }
  }

  BT.print(':');
  bt += ":";
  txt = BIN_NBL_TO_HEX_DIGIT(ComputedCheckSum>>4 & 0x0F);
  bt += (String)txt;
  BT.print(txt);
  txt = BIN_NBL_TO_HEX_DIGIT(ComputedCheckSum & 0x0F);
  bt += (String)txt;
  BT.println(txt);
  if (Debug)
    Serial.println(txt);
}
#endif

#if (INPUT_MODE == BT_INIT)
#ifdef AT_INIT_HC05          // AT configuration of the HC05, to make once time
void InitBtAuto_Hc05()
{
  Serial.print("AT: ");                 // verify we are in AT mode
  BT.print("AT\r\n");
  if (!waitFor("OK\r\n")) Serial.println("time out error AT");

  Serial.print("UART: ");               // serial communication parameters
#if defined(__AVR_ATmega328P__)
  BT.print("AT+UART=57600,0,0\r\n");//57600
#endif
#if defined(__AVR_ATmega32U4__) 
  BT.print("AT+UART=115200,0,0\r\n");//115200
#endif
  if (!waitFor("OK\r\n")) Serial.println("time out error AT+UART");

  Serial.print("NAME: ");               // BLUETOOTH device name
  BT.print("AT+NAME=BT/SIM\r\n");
  if (!waitFor("OK\r\n")) Serial.println("time out error AT+NAME");

  Serial.print("PSWD: ");               // password for pairing
  BT.print("AT+PSWD=\"1234\"\r\n");
  if (!waitFor("OK\r\n")) Serial.println("time out error AT+PSWD");

  Serial.print("ROLE: ");               // device in slave mode
  BT.print("AT+ROLE=0\r\n");
  if (!waitFor("OK\r\n")) Serial.println("time out error AT+ROLE");

//  digitalWrite(MODULE_KEY, LOW);            // leave AT mode & switch back to communication mode
}
void ReadBTSettings_Hc05()
{
  BT.print("AT\r\n");
  BT.print("AT+UART\r\n");
  BT.print("AT+NAME\r\n");
  BT.print("AT+PSWD\r\n");
  BT.print("AT+ROLE\r\n");
}

//  The waitFor a string function with time out
bool waitFor(const char *rep)
{
  unsigned long t0 = millis(), t;
  int i=0, j=strlen(rep);
  char c;

  for (i = 0 ; i<j ; )
  {
    if (BT.available())
    {
      c=(char)BT.read();
      Serial.print(c);
      if (c==rep[i])i++;
    }

    t = millis();
    if (t-t0>2000)break;
  }
  return i==j ;
  delay(10);
}
#endif

#ifdef AT_INIT_HM10          // AT configuration of the HM10, to make once time
void InitHM10Auto_Hm10()
{
  Serial.print("AT: ");                 // verify we are in AT mode
  BT.print("AT\r\n");
  if (!waitFor("OK\r\n")) Serial.println("time out error AT");

  // Serial.print("BAUD: ");               // bluetooth device name
  // BT.print("AT+BAUD\r\n");
  // if (!waitFor("BAUD: +BAUD=1")) Serial.println("time out error AT+BAUD");

  Serial.print("BAUD: ");               // serial communication parameters
#if defined(__AVR_ATmega328P__)
  BT.print("AT+BAUD7\r\n");//1-1200,2-2400,3-4800,4-9600,5-19200,6-38400,7-57600,8-115200,9-230400,  !!! default4-9600 !!!
#endif
#if defined(__AVR_ATmega32U4__) 
  BT.print("AT+UART8\r\n");//115200
#endif

  delay(250);
  if (!waitFor("OK\r\n")) Serial.println("time out error AT+BAUD");

  Serial.print("NAME: ");               // bluetooth device name
  BT.print("AT+NAMEBT/SIM\r\n");
  if (!waitFor("OK\r\n")) Serial.println("time out error AT+NAME");

  Serial.print("PIN: ");               // password for pairing
  BT.print("AT+PIN123456\r\n");
  if (!waitFor("OK\r\n")) Serial.println("time out error AT+PSWD");

  Serial.print("ROLE: ");               // device in slave mode
  BT.print("AT+ROLE0\r\n");
  if (!waitFor("OK\r\n")) Serial.println("time out error AT+ROLE");

}

void ReadBTSettings_Hm10()
{
  BT.print("AT\r\n");
  BT.print("AT+BAUD\r\n");
  BT.print("AT+PIN\r\n");
  BT.print("AT+ROLE\r\n");

/*
  // The following commands are just to demonstrate the shield is working properly,
  // in actual application, only call those that are needed by your application.
  // Check HM-10 datasheet for the description of the commands.
  BLECmd(timeout,"AT+NAME?",buffer);
  BLECmd(timeout,"AT+BAUD?",buffer);
  BLECmd(timeout,"AT+MODE?",buffer);
  BLECmd(timeout,"AT+PASS?",buffer);
  BLECmd(timeout,"AT+VERS?",buffer);
  BLECmd(timeout,"AT+RADD?",buffer);
  BLECmd(timeout,"AT+ADDR?",buffer);
  BLECmd(timeout,"AT+TYPE?",buffer);
  BLECmd(timeout,"AT+POWE?",buffer);
  BLECmd(timeout,"AT+NOTI1",buffer);
  Serial.println("----------------------");
  Serial.println("Waiting for remote connection...");
  */
}

//  The waitFor a string function with time out
bool waitFor(const char *rep){
  unsigned long t0 = millis(), t;
  int i=0, j=strlen(rep);
  char c;

  for (i = 0 ; i<j ; )
  {
    if (BT.available())
    {
      c=(char)BT.read();
      Serial.print(c);
      if (c==rep[i])i++;
    }

    t = millis();
    if (t-t0>2000)break;
  }
  return i==j ;
  delay(10);
}
#endif
#endif
