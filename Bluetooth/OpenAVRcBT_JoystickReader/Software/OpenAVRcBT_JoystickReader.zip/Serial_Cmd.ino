void ReadSerialCmd()
{
  if(Serial.available())
  {
    switch (Serial.read())
    {
      case 'd':
      case 'D':
        RunDebug();
        break;
    }
  }
}

void RunDebug()
{
  Serial.println(Debug?"Start Debug !":"Stop Debug !");
  Debug = ! Debug;
}