#ifndef _LCDDISPLAY_h
#define _LCDDISPLAY_h

#include "RCState.h"
//#include <LiquidCrystal_I2C.h>
#include <LCDI2C_Multilingual.h> 

//Pins A4-SDA, A5-SCL
//LiquidCrystal_I2C	lcd(0x27, 2, 1, 0, 4, 5, 6, 7, 3, POSITIVE);
LCDI2C_Generic	lcd(0x27, 20, 4);
//LCDI2C_Latin	  lcd(0x27, 20, 4);

class LCDDisplay {
public:
	void setup() {
		//lcd.begin(20, 4);
    lcd.init();
    lcd.backlight();
		lcd.clear();
		lcd.setCursor(3, 0);
		lcd.print("Joystick  PPM");
		lcd.setCursor(1, 2);
		lcd.print("**OpenAVRc  Team**");
    delay(1000);
    //lcd.setBacklight(LOW);
    //lcd.noBacklight(); // turn off backlight.
    //delay(1000);
    //lcd.backlight(); // turn on backlight with full brightness   
	}

	void display_oerr() {
		lcd.clear();
		lcd.setCursor(0, 0);
		lcd.print("OSC not started");
	}

	void display_herr() {
		lcd.clear();
		lcd.setCursor(0, 0);
		lcd.print("HID set error");
	}

	void display_joystick_connected() {
		lcd.clear();
		lcd.setCursor(6, 1);
		lcd.print("Joystick");
		lcd.setCursor(6, 2);
		lcd.print("Connected");
	}

	void clear() {
		lcd.clear();
	}

	void display_joystick_disconnected() {
		lcd.clear();
		lcd.setCursor(6, 1);
		lcd.print("Joystick");
		lcd.setCursor(4, 2);
		lcd.print("Disconnected");
	}

	void display(int flight_mode, int channel5_mode, byte camera_mode, bool camera_auto_center) {
		//lcd.clear();
		lcd.setCursor(0, 0);
		
		lcd.print("Mode:");
		lcd.print(flight_mode);

    if (channel5_mode<1000)
    {
      lcd.setCursor(13, 0);
    }
    else
    {
      lcd.setCursor(12, 0);
    }
		lcd.print("CH5:");
		lcd.print(channel5_mode);

		lcd.setCursor(0, 1);
		lcd.print("CMode:");
		lcd.print(camera_mode);

		lcd.setCursor(17, 1);
		if (camera_auto_center) {
			lcd.print("CEN");
		}

		//display_rc(flight_mode, channel5, camera_mode, camera_auto_center);


	}

	void write_mode(RCState *rcs) {
		lcd.setCursor(0, 2);
		lcd.print("M");
		lcd.print(rcs->flight_mode);
	}

	void write_ch5_simple_mode(RCState *rcs) {
		lcd.setCursor(5, 2);
		if (rcs->channel5_mode == 1000) {
			lcd.print("+");
		}
		else {
			lcd.print("o");
		}
	}

	void write_camera_mode(RCState *rcs) {
		lcd.setCursor(7, 2);
		switch (rcs->camera_mode) {
		case CAMERA_MODES::exponent:
			lcd.print("Expo");
			break;
		case CAMERA_MODES::slow:
			lcd.print("Slow");
			break;
		case CAMERA_MODES::max_min:
			lcd.print("MnMx");
			break;
		}

		if (rcs->auto_center) {
			lcd.print(" +");
		}
		else {
			lcd.print(" .");
		}
	}

	void write_number_value(int value,RCState *rcs) {
		auto mapped_value = map(value, rcs->MIN_VALUE, rcs->MAX_VALUE, -99, +99);
		if (mapped_value >= 0) {
			lcd.print(" ");
		}
		if (mapped_value < 10 && mapped_value> -10) {
			lcd.print(" ");
		}
		lcd.print(mapped_value);
	}

	void write_unsigned_number_value(int value, RCState *rcs) {
		auto mapped_value = map(value, rcs->MIN_VALUE, rcs->MAX_VALUE, 0, +99);
		if (mapped_value >= 0) {
			lcd.print(" ");
		}
		if (mapped_value < 10 && mapped_value> -10) {
			lcd.print(" ");
		}
		lcd.print(mapped_value);
	}

	void write_camera_values(RCState *rcs) {
		lcd.setCursor(13, 2);
		write_number_value(rcs->camera_yaw, rcs);

		lcd.setCursor(17, 2);
		write_number_value(rcs->camera_pitch, rcs);
	}


	void print_all(RCState *rcs) {
		//lcd.clear();
		lcd.setCursor(0, 2);

		write_mode(rcs);

		write_ch5_simple_mode(rcs);

		write_camera_mode(rcs);
		write_camera_values(rcs);

		lcd.setCursor(0, 3);
    lcd.print("E");
		write_number_value(rcs->elevator, rcs);

		lcd.setCursor(4, 3);
    lcd.write(255);
    lcd.print("A");
		write_number_value(rcs->aileron,rcs);

		lcd.setCursor(9, 3);
    lcd.write(255);
    lcd.print("T");
		write_unsigned_number_value(rcs->throttle,rcs);

		lcd.setCursor(15, 3);
    lcd.write(255);
    lcd.print("R");
		write_number_value(rcs->rudder,rcs);

		
	}

	void loop() {

	}
/*
	void displayPercentage(uint8_t char_id, uint8_t value) {
		byte char_remainder[3] = {
			0b00100,
			0b01110,
			0b11111
		};

		const int options = 24;
		const int rows = 8;
		const int cols = 3;

		auto mapped_value = map(value, 0, 100, 0, 24);
		auto row = mapped_value / 3;
		auto col = mapped_value % 3;

		byte char_value[8] = {0};
		for (auto i = 8; i > row; i--) {
			char_value[i] = 0b11111;
		}
		char_value[row] = char_remainder[col];
		lcd.createChar(char_id, char_value);
	}

	void display_rx_rssi(uint8_t value) {
		lcd.setCursor(14, 1);

		if (value == 255) {
			lcd.print("x");
		}
		else {
			displayPercentage(0, value);
			lcd.print((char)0);
		}
	}

	void display_tx_rssi(uint8_t value) {
		lcd.setCursor(15, 1);

		if (value == 255) {
			lcd.print("x");
		}
		else {
			displayPercentage(1, value);
			lcd.print((char)1);
		}
	}
*/

};

#endif
