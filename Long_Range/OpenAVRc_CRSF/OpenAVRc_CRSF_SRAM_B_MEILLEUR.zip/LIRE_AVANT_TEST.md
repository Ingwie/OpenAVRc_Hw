# CRSF OpenAVRc — décodage progressif ELRS B (EXPÉRIMENTAL)

Base : variante A (optimisations PROGMEM et période Packet Rate déjà appliquées).
**NE PAS utiliser en navigation/vol : test sur table, moteurs déconnectés.**

## Changement supplémentaire

- Remplace le tableau d'assemblage permanent de 256 octets des paramètres 0x2B par un tampon de fragment (56 octets).
- Le callback UART ne fait qu'une copie bornée des octets après validation du CRC ; il publie l'état CRSF_PWR_FRAGMENT seulement APRÈS la copie.
- Le traitement des fragments (parent/type/nom/options/sélection) est fait uniquement dans CRSF_PowerMain() exécuté par perMain(), jamais dans l'ISR.
- Le parsing fonctionne quand un nom, la liste d'options ou la valeur sélectionnée traversent une frontière de fragment.
- Chaque octet est décodé au plus une fois, sur demande de configuration. Les voies RC et la télémétrie périodique sont inchangées.

## RAM

Buffer original 256 octets + 2 octets longueur = 258 octets.
Nouveau buffer 56 octets + 43 octets de petits états et fenêtres de recherche = ~99 octets.
**Gain théorique supplémentaire ≈ 159 octets de SRAM statique** par rapport à la variante A ; mesurer `Data` et `FreeSram` avant d'en déduire le gain réel.

## Vérification automatique

Les fonctions de parsing réelles extraites du fichier ont été compilées et testées en C++ hôte, avec plusieurs points de coupure entre fragments :
Max Power, Dynamic, Telem Ratio, Packet Rate, domaines 868/915/2.4, combinaison bi-bande.
Cela ne prouve PAS le fonctionnement de la communication UART sur ATmega2560.

## Test conseillé

1. D'abord valider A. Sauvegarder le binaire qui fonctionne.
2. Compiler B avec les mêmes options et noter Data / FreeSram.
3. Essayer la détection du TX 868 MHz, puis 2.4 GHz.
4. Vérifier lecture ET édition des paramètres, la télémétrie à 1:32, VFAS=7.3V, RSSI et stabilité du démarrage.
5. Au moindre défaut, restaurer A ou la version stable 85 octets.

Toolchain avr-g++ absente de l'environnement : compilation complète AVR et essais matériels non réalisés.
