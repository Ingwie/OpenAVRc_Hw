/*
**************************************************************************
*                                                                        *
*                 ____                ___ _   _____                      *
*                / __ \___  ___ ___  / _ | | / / _ \____                 *
*               / /_/ / _ \/ -_) _ \/ __ | |/ / , _/ __/                 *
*               \____/ .__/\__/_//_/_/ |_|___/_/|_|\__/                  *
*                   /_/                                                  *
*                                                                        *
*              This file is part of the OpenAVRc project.                *
*                                                                        *
*                         Based on code(s) named :                       *
*             OpenTx - https://github.com/opentx/opentx                  *
*             Deviation - https://www.deviationtx.com/                   *
*                                                                        *
*                Only AVR code here for visibility ;-)                   *
*                                                                        *
*   OpenAVRc is free software: you can redistribute it and/or modify     *
*   it under the terms of the GNU General Public License as published by *
*   the Free Software Foundation, either version 2 of the License, or    *
*   (at your option) any later version.                                  *
*                                                                        *
*   OpenAVRc is distributed in the hope that it will be useful,          *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of       *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
*   GNU General Public License for more details.                         *
*                                                                        *
*       License GPLv2: http://www.gnu.org/licenses/gpl-2.0.html          *
*                                                                        *
**************************************************************************
*/
/* Formatting octal codes available in TR_ strings:
*  \037\x           -sets LCD x-coord (x value in octal)
*  \036             -newline
*  \001 to \034     -extended spacing (value * FW/2)
*  \0               -ends current string
*/

/* NON ZERO TERMINATED STRINGS */
/* CRSF menu translations. Keep identifiers identical in every language. */
#define TR_CRSF_CH5_SWITCH        "Switch CH5"
#define TR_CRSF_PACKET_RATE       "Tasa Paq."
#define TR_CRSF_TLM_RATIO         "Ratio TLM"
#define TR_CRSF_POWER             "Potencia"
#define TR_CRSF_BAUDRATE          "Baudios"

#define LEN_OFFON              "\003"
#define TR_OFFON               "OFF""ON\0"
#define LEN_MMMINV             "\003"
#define TR_MMMINV              "---""INV"
#define LEN_NCHANNELS          "\004"
#define TR_NCHANNELS           "\0014CH\0016CH\0018CH10CH12CH14CH16CH"
#define LEN_VBEEPMODE          "\005"
#define TR_VBEEPMODE           "Mudo ""Alarm""NoKey""Todo "
#define LEN_VRENAVIG           "\003"
#define TR_VRENAVIG            "No REaREb"
#define LEN_VBLMODE            "\004"
#define TR_VBLMODE             "OFF ""Keys""Stks""Both""ON\0"
#define LEN_TRNMODE            "\003"
#define TR_TRNMODE             "OFF"" +="" :="
#define LEN_TRNCHN             "\003"
#define TR_TRNCHN              "CH1CH2CH3CH4"
#define LEN_VPERSISTENT        "\014"
#define TR_VPERSISTENT         "OFF\0        ""Flight\0     ""Manual Reset"
#define LEN_DSM_PROTOCOLS      "\004"
#define TR_DSM_PROTOCOLS       "LP45""DSM2""DSMX"
#define LEN_VTRIMINC           "\006"
#define TR_VTRIMINC            "Expo  ""ExFino""Fino  ""Medio ""Grueso"
#define LEN_CURVE_TYPES        "\010"
#define TR_CURVE_TYPES         "Standard""Custom\0"
#define LEN_RETA123            "\001"
#define TR_RETA123           "RETA123ab"

#if defined(PWM_BACKLIGHT)
  #define TR_BLONBRIGHTNESS      INDENT"MAS Brillo"
  #define TR_BLOFFBRIGHTNESS     INDENT"MENOS Brillo"
#endif
#if (SERIAL_PROTOCOL==DSM)
  #define TR_DSM2              "LP45\0 ""DSM2\0 ""DSMX\0 "
#else
  #define TR_DSM2
#endif

#define TR_SPIM              "SPIRfMod"
#define TR_RFPOWER INDENT    "RF Power"

#define TR_PERIOD              INDENT "Período"
#define TR_MODULE             "modulo"
#define TR_SUBPROTO            "Subproto."
#define TR_RFTUNEFINE         INDENT "Freq.fine"
#define TR_TELEMETRY             "Telemetry"
#define TR_MULTI_VIDFREQ               INDENT "Vid. freq."
#define TR_MULTI_RFPOWER               INDENT "RF Power"
#define TR_MULTI_OPTION                INDENT "Option"
#define TR_AUTOBIND              INDENT "Autobind"
#define TR_MULTI_DSM_AUTODTECT         INDENT "Autodetect"
#define TR_MULTI_LOWPOWER              INDENT "Low power"
#define TR_MULTI_SERVOFREQ             INDENT "Servo rate"
#define TR_MULTI_FIXEDID               "ID Fijo"
#define TR_MULTI_MAX_THROW             "Máx. Throw"
#define TR_MULTI_RFCHAN                "Canal RF"
#define TR_MULTI_OUTPUT                "salida"

#define LEN_VCURVEFUNC         "\003"
#define TR_VCURVEFUNC          "---""x>0""x<0""|x|""f>0""f<0""|f|"
#define LEN_VMLTPX             "\010"
#define TR_VMLTPX              "A\201adir\0 ""Multipl.""Cambiar\0"
#define LEN_VMLTPX2            "\002"
#define TR_VMLTPX2             "+=""*="":="
#define LEN_VMIXTRIMS          "\003"
#define TR_VMIXTRIMS           "OFF""ON\0""Dir""Ele""Ace""Ale"
#define TR_CSWTIMER          "Tim\0 "
#define TR_CSWSTICKY         "Glue\0"
#define TR_CSWRANGE
#define TR_CSWSTAY
#define LEN_VCSWFUNC           "\005"
#define TR_VCSWFUNC            "---\0 " "a=x\0 " "a\173x\0 ""a>x\0 ""a<x\0 " TR_CSWRANGE "|a|>x""|a|<x""AND\0 ""OR\0  ""XOR\0 " TR_CSWSTAY "a=b\0 ""a>b\0 ""a<b\0 ""^}x\0 ""|^|}x" TR_CSWTIMER TR_CSWSTICKY
#define LEN_VFSWFUNC           "\012"
#if defined(VARIO)
  #define TR_VVARIO            "Vario\0    "
#else
  #define TR_VVARIO            "[Vario]\0  "
#endif
#if defined(AUDIO)
  #define TR_SOUND             "Oir Sonido"
#else
  #define TR_SOUND             "Beep\0     "
#endif
#if defined(HAPTIC)
  #define TR_HAPTIC            "Tactil\0   "
#else
  #define TR_HAPTIC            "[Tactil]\0 "
#endif
#if defined(VOICE)
  #define TR_PLAY_TRACK      "Oir pista\0"
  #define TR_PLAY_BOTH         "Oir Ambos\0"
  #define TR_PLAY_VALUE        "Oir valor\0"
#else
  #define TR_PLAY_TRACK        "[OirPista]"
  #define TR_PLAY_BOTH         "[OirAmbos]"
  #define TR_PLAY_VALUE        "[OirValor]"
#endif
#if defined(SDCARD)
  #define TR_SDCLOGS           "SD Logs\0  "
#else
  #define TR_SDCLOGS           "[SD Logs]\0"
#endif
#if defined(GVARS)
  #define TR_ADJUST_GVAR       "Ajuste\0   "
#else
  #define TR_ADJUST_GVAR       "[AdjustGV]"
#endif

#if defined(OVERRIDE_CHANNEL_FUNCTION)
  #define TR_SF_SAFETY        "Seguro\0   "
#else
  #define TR_SF_SAFETY        "---\0      "
#endif

#define TR_VFSWFUNC          TR_SF_SAFETY "Aprendiz\0 ""Inst. Trim""Reset\0    " TR_ADJUST_GVAR TR_SOUND TR_PLAY_TRACK TR_PLAY_BOTH TR_PLAY_VALUE TR_VVARIO TR_HAPTIC TR_SDCLOGS "Luz fondo\0"
#define LEN_VFSWRESET          "\004"
#if defined(FRSKY)
  #define TR_FSW_RESET_TELEM   "Telm"
  #define TR_MODELISON         INDENT "Modelo is ON"
#else
  #define TR_FSW_RESET_TELEM
#endif
#define TR_FSW_RESET_TIMERS  "Tmr1""Tmr2"
#define TR_FSW_RESET_ROTENC  "REa\0""REb\0"
#define TR_VFSWRESET           TR_FSW_RESET_TIMERS "All\0" TR_FSW_RESET_TELEM TR_FSW_RESET_ROTENC
#define LEN_FUNCSOUNDS         "\004"
#define TR_FUNCSOUNDS          "Bp1\0""Bp2\0""Bp3\0""Avs1""Avs2""Chee""Rata""Tick""Sirn""Ring""SciF""Robt""Chrp""Tada""Crck""Alrm"
#define LEN_VTELEMCHNS         "\004"
#define TR_TELEM_RESERVE
#define TR_TELEM_TIME
#define TR_SWR
#define TR_RX_BATT           "RxBt"
#define TR_A3_A4
#define TR_A3_A4_MIN
#define TR_ASPD_MAX            "ASp+"
#define TR_TELEM_RSSI_RX     "Rx\0  "
#define TR_TELEM_TIMERS      "Tmr1""Tmr2"
#define TR_VTELEMCHNS        "---\0""Batt" TR_TELEM_TIME TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_TIMERS TR_SWR "Tx\0 " TR_TELEM_RSSI_RX "A1\0 ""A2\0 " TR_A3_A4 "Alt\0""Rpm\0""Fuel""T1\0 ""T2\0 ""Spd\0""Dist""GAlt""Cell""Cels""Vfas""Curr""Cnsp""Powr""AccX""AccY""AccZ""Hdg\0""VSpd""ASpd""dTE\0" TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_RESERVE "A1-\0""A2-\0" TR_A3_A4_MIN "Alt-""Alt+""Rpm+""T1+\0""T2+\0""Spd+""Dst+" TR_ASPD_MAX "Cel-""Cls-""Vfs-""Cur+""Pwr+" TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_RESERVE TR_TELEM_RESERVE "Acc\0""Time" TR_RX_BATT
#define LENGTH_UNIT_IMP        "ft\0"
#define SPEED_UNIT_IMP         "mph"
#define LENGTH_UNIT_METR       "m\0 "
#define SPEED_UNIT_METR        "kmh"
#if defined(IMPERIAL_UNITS)
  #define LENGTH_UNIT        LENGTH_UNIT_IMP
  #define SPEED_UNIT         SPEED_UNIT_IMP
#else
  #define LENGTH_UNIT        LENGTH_UNIT_METR
  #define SPEED_UNIT         SPEED_UNIT_METR
#endif
#define LEN_VTELEMUNIT       "\003"
#define TR_VTELEMUNIT        "V\0 ""A\0 ""m/s""-\0 " SPEED_UNIT LENGTH_UNIT "@\0 ""%\0 ""mA\0""mAh""W\0 "
#define STR_V                  (STR_VTELEMUNIT+1)
#define STR_A                  (STR_VTELEMUNIT+4)
#define LEN_VTELPROTO          "\007"
#define TR_VTELPROTO           "Nada\0  ""Hub\0   ""WSHHigh""S.Port\0""iBus\0  "
#define LEN_AMPSRC           "\003"
#define TR_AMPSRC            "---""A1\0""A2\0""FAS""Cel"
#define LEN_VARIOSRC           "\005"
#if defined(FRSKY_SPORT)
  #define TR_VARIOSRC          "Vario""A1\0  ""A2\0"
#else
  #define TR_VARIOSRC          "Alti\0""Alti+""Vario""A1\0  ""A2\0"
#endif
#define LEN_VTELEMSCREENTYPE   "\004"
#define TR_VTELEMSCREENTYPE    "Nums""Bars"
#define LEN_GPSFORMAT          "\004"
#define TR_GPSFORMAT           "HMS NMEA"
#define LEN2_VTEMPLATES        13
#define LEN_VTEMPLATES         "\015"
#define TR_VTEMPLATES          "Elim Mezcla\0\0""Simple 4-CH \0""Anular Motor\0""Cola en V   \0""Elevon\\Delta\0""eCCPM       \0""Heli Setup  \0""Servo Test  \0"
#define LEN_VSWASHTYPE         "\004"
#define TR_VSWASHTYPE          "---\0""120\0""120X""140\0""90\0"
#define LEN_VKEYS              "\005"
#define TR_VKEYS               "Menu\0""Salir""Abajo""Arrib""Dcha.""Izqd."
#define LEN_VRENCODERS         "\003"
#define TR_VRENCODERS          "REa""REb"
#define TR_POTS_VSRCRAW      "P1\0 ""P2\0 ""P3\0 "
#define TR_SW_VSRCRAW        "3POS"
#define TR_9X_3POS_SWITCHES  "ID0""ID1""ID2"
#define TR_LOGICALSW          "L1\0""L2\0""L3\0""L4\0""L5\0""L6\0""L7\0""L8\0""L9\0""L10""L11""L12""L13""L14""L15""L16""L17""L18""L19""L20"
#define TR_TRIMS_SWITCHES      "tRl""tRr""tEd""tEu""tTd""tTu""tAl""tAr"
#define TR_ROTARY_ENCODERS   "REa\0""REb\0"
#define TR_ROTENC_SWITCHES   "REA""REB""REN"
#define TR_PHYS_SWITCHES     "THR""RUD""ELE""AIL""GEA""TRN"
#define TR_ON_ONE_SWITCHES     "ON\0""One"
#define TR_EXTRA_3POS_SWITCHES  "XD0""XD1""XD2"
#define LEN_VSRCRAW            "\004"
#define LEN_VSWITCHES          "\003"
#define TR_VSWITCHES         "---" TR_9X_3POS_SWITCHES TR_PHYS_SWITCHES TR_TRIMS_SWITCHES TR_ROTENC_SWITCHES TR_EXTRA_3POS_SWITCHES TR_LOGICALSW TR_ON_ONE_SWITCHES
#if defined(HELI)
  #define TR_CYC_VSRCRAW       "CYC1""CYC2""CYC3"
#else
  #define TR_CYC_VSRCRAW       "[C1]""[C2]""[C3]"
#endif
#define TR_VSRCRAW             "---\0""Dir\0""Ele\0""Thr\0""Ale\0" TR_POTS_VSRCRAW TR_ROTARY_ENCODERS "MAX\0" TR_CYC_VSRCRAW "TrmR" "TrmE" "TrmT" "TrmA" TR_SW_VSRCRAW
#define LEN_VTMRMODES          "\003"
#define TR_VTMRMODES           "OFF""ABS""THs""TH%""THt"

/* ZERO TERMINATED STRINGS */
#define INDENT                 "\001"
#define LEN_INDENT             1
#define INDENT_WIDTH           (FW/2)
#define TR_ENTER             "[MENU]"
#define TR_EXIT                "[SALIR]"
#define TR_POPUPS            TR_ENTER "\010" TR_EXIT
#define OFS_EXIT             sizeof(TR_ENTER)
#define TR_MENUWHENDONE        CENTER "\007" TR_ENTER " AL ACABAR "
#define TR_FREE                "libre"
#define TR_DELETEMODEL         "BORRAR MODELO"
#define TR_COPYINGMODEL        "Copiando modelo.."
#define TR_MOVINGMODEL         "Mover modelo..."
#define TR_LOADINGMODEL        "Cargar modelo..."
#define TR_NAME                "Nom."

#define TR_TIMER               "Reloj"
#define TR_ELIMITS             "E.Limite"
#define TR_ETRIMS              "E.Trims"
#define TR_TRIMINC             "Paso Trim"
#define TR_TTRACE              "Fuente-A"
#define TR_TSWITCH             "A-Switch"
#define TR_TTRIM               "Trim-A"
#define TR_BEEPCTR             "Ctr Beep"
#define TR_PROTO               INDENT"Protocolo"
#define TR_PPMFRAME            "Trama PPM"
#define TR_MS                  "ms"
#define TR_SWITCH              "Interr"
#define TR_TRIMS               "Trims"
#define TR_FADEIN              "Inicio"
#define TR_FADEOUT             "Final"
#define TR_DEFAULT             "(defecto)"
#define TR_CHECKTRIMS          CENTER "\006Check\012Trims"
#define OFS_CHECKTRIMS         CENTER_OFS+(9*FW)
#define TR_SWASHTYPE           "Tipo ciclico"
#define TR_COLLECTIVE          "Colectivo"
#define TR_SWASHRING           "Ciclico"
#define TR_ELEDIRECTION        "ELE Direccion"
#define TR_AILDIRECTION        "AIL Direccion"
#define TR_COLDIRECTION        "PIT Direccion"
#define TR_MODE                INDENT"Modo"
#define TR_NOFREEEXPO          "No expo libre!"
#define TR_NOFREEMIXER         "No mezcla lib!"
#define TR_INSERTMIX           "INSERTAR MIX"
#define TR_EDITMIX             "EDITAR MIX "
#define TR_SOURCE              INDENT"Fuente"
#define TR_WEIGHT              "Cantidad"
#define TR_EXPO                "Expo"
#define TR_SIDE                "Lado"
#define TR_DIFFERENTIAL        "Diferenc"
#define TR_OFFSET              INDENT"Offset"
#define TR_TRIM                "Trim"
#define TR_DREX                "DRex"
#define DREX_CHBOX_OFFSET      30
#define TR_CURVE               "Curva"
#define TR_FLMODE              "Modo"
#define TR_MIXWARNING          "Aviso"
#define TR_OFF                 "OFF"
#define TR_MULTPX              "Multpx"
#define TR_DELAYDOWN           "Delay Dn"
#define TR_DELAYUP             "Delay Up"
#define TR_SLOWDOWN            "Slow  Dn"
#define TR_SLOWUP              "Slow  Up"
#define TR_MIXER               "Mezclas"
#define TR_CV                  "CV"
#define TR_GV                  "GV"
#define TR_ACHANNEL            "A\004canal"
#define TR_RANGE               INDENT"Alcance"
#define TR_ALARM               INDENT"Alarma"
#define TR_USRDATA             "UsrData"
#define TR_BLADES              INDENT"Palas"
#define TR_SCREEN              "Pantalla"
#define TR_SOUND_LABEL         "Sonido"
#define TR_LENGTH              INDENT"Longitud"
#define TR_BEEP_LENGTH         INDENT "Beep Length"
#define TR_SPKRPITCH           INDENT"Tono"
#define TR_HAPTIC_LABEL        "Tactil"
#define TR_HAPTICSTRENGTH      INDENT"Intensidad"
#define TR_CONTRAST            "Contraste"
#define TR_ALARMS_LABEL        "Alarmas"
#define TR_BATTERY_RANGE       "Rango bateria"
#define TR_BATTERYWARNING      INDENT"Bateria Baja"
#define TR_INACTIVITYALARM     INDENT"Inactividad"
#define TR_MEMORYWARNING       INDENT"Memoria Baja"
#define TR_ALARMWARNING        INDENT"Sin Sonido"
#define TR_RENAVIG             "RotEnc Navig"
#define TR_MINUTEBEEP          INDENT"Minuto"
#define TR_BEEPCOUNTDOWN       INDENT"Cuentaatras"
#define TR_PERSISTENT          INDENT"Persist."
#define TR_BACKLIGHT_LABEL     "Luz Fondo"
#define TR_BLDELAY             INDENT"Duracion"
#define TR_SPLASHSCREEN        "Ptalla.inicio"
#define TR_THROTTLEWARNING     "Aviso-A"
#define TR_SWITCHWARNING       "Aviso-I"
#define TR_TIMEZONE            "Zona Hora"
#define TR_ADJUST_RTC          "Adjust RTC"
#define TR_GPS                 "GPS"
#define TR_RXCHANNELORD        "Rx Orden canal"
#define TR_STICKS              "Sticks"
#define TR_POTS                "Pots"
#define TR_SLAVE               "Esclavo"
#define TR_MODESRC             "Modo\006% Fuente"
#define TR_MULTIPLIER          "Multiplicar"
#define TR_CAL                 "Cal"
#define TR_VTRIM               "Trim- +"
#define TR_MENUTOSTART         CENTER "\010" TR_ENTER " EMPEZAR"
#define TR_SETMIDPOINT         CENTER "\007STICKS AL CENTRO"
#define TR_MOVESTICKSPOTS      CENTER "\006MOVER STICKS/POTS"
#define TR_RXBATT              "Rx Batt:"
#define TR_TXnRX               "Tx:\0Rx:"
#define OFS_RX                 4
#define TR_ACCEL               "Acc:"
#define TR_NODATA              CENTER "SIN DATOS"
#define TR_TOTTM1TM2THRTHP     "\037\146SES\036TM1\037\146TM2\036THR\037\146TH%"
#define TR_US                 "us"
#define TR_MENUTORESET         CENTER TR_ENTER "Resetear"
#define TR_PPM_TRAINER         "TR"
#define TR_CH                  "CH"
#define TR_MODEL               "MODELO"
#define TR_FP                  "FM"
#define TR_MIX                 "MIX"
#define TR_EEPROMLOWMEM        "EEPROM mem.baja"
#define TR_ALERT               "\016ALERTA"
#define TR_PRESSANYKEYTOSKIP   "Pulsar tecla omitir"
#define TR_THROTTLENOTIDLE     "Aceler. Activado"
#define TR_ALARMSDISABLED      "Alarmas Desact."
#define TR_PRESSANYKEY         "\010Pulsa una Tecla"
#define TR_BADEEPROMDATA       "Datos EEprom mal"
#define TR_EEPROMFORMATTING    "Formateo EEPROM"
#define TR_EEPROMOVERFLOW      "Desborde EEPROM"
#define TR_MENURADIOSETUP      "CONFIGURACION"
#define TR_MENUTRAINER         "APRENDIZ"
#define TR_MENUVERSION         "VERSION"
#define TR_MENUDIAG            "INTERUPTS"
#define TR_MENUANA             "ANAS"
#define TR_MENUCALIBRATION     "CALIBRACION"
#define TR_TRIMS2OFFSETS       "\006Trims => Offsets"
#define TR_MENUMODELSEL        "MODELSEL"
#define TR_MENUSETUP           "CONF."
#define TR_MENUFLIGHTPHASE     "MODO VUELO"
#define TR_MENUFLIGHTPHASES    "MODOS VUELO"
#define TR_MENUHELISETUP       "CONF. HELI"
#if defined(PPM_CENTER_ADJUSTABLE) || defined(PPM_LIMITS_SYMETRICAL)
  #define TR_MENUINPUTS        "STICKS"
  #define TR_MENULIMITS        "SERVOS"
#else
  #define TR_MENUINPUTS        "DR/EXPO"
  #define TR_MENULIMITS        "LIMITES"
#endif
#define TR_MENUCURVES          "CURVAS"
#define TR_MENUCURVE           "CURVA"
#define TR_MENULOGICALSWITCHES  "AJTE.INTERUPTS."
#define TR_MENUCUSTOMFUNC      "AJTE. FUNCIONES"
#define TR_MENUTELEMETRY       "TELEMETRIA"
#define TR_MENUTEMPLATES       "PLANTILLAS"
#define TR_MENUSTAT            "STATS"
#define TR_MENUDEBUG           "DEBUG"
#define TR_RXNUM               "RxNum"
#define TR_LIMIT               INDENT"Limite"
#define TR_MINRSSI             "Min Rssi"
#define TR_LATITUDE            "Latitud"
#define TR_LONGITUDE           "Longitud"
#define TR_GPSCOORD            "GPS Coords"
#define TR_VARIO               "Vario"
#define TR_POWEROFF            "\006SHUT DOWN ?"
#define TR_SHUTDOWN            "APAGANDO"
#define TR_SAVEMODEL           "Saving model settings"
#define TR_BATT_CALIB          "Calib.bateria"
#define TR_VOLTAGE             INDENT"Voltaje"
#define TR_CURRENT             INDENT"Actual"
#define TR_SELECT_MODEL        "Selec Modelo"
#define TR_CREATE_MODEL        "Crear Modelo"
#define TR_COPY_MODEL          "Copiar Modelo"
#define TR_MOVE_MODEL          "Mover Modelo"
#define TR_BACKUP_MODEL        "Copia Sgdad Mod."
#define TR_DELETE_MODEL        "Borrar Modelo"
#define TR_RESTORE_MODEL       "Restaurar Modelo"
#define TR_SDCARD_ERROR        "SDCARD Error"
#define TR_NO_SDCARD           "No SDCARD"
#define TR_INCOMPATIBLE        "Incompatible"
#define TR_WARNING             "AVISO"
#define TR_EEPROMWARN          "EEPROM"
#define TR_THROTTLEWARN        "ACELERADOR"
#define TR_ALARMSWARN          "ALARMAS"
#define TR_SWITCHWARN          "INTERPTOR"
#define TR_INVERT_THR          "Invertir Acel?"
#define TR_SPEAKER_VOLUME      INDENT "Volumen"
#define TR_FUNC                "Func"
#define TR_DELAY               "Atraso"
#define TR_SD_CARD             "SD CARD"
#define TR_NO_MODELS_ON_SD     "Sin Modelos en SD"
#define TR_PLAY_FILE           "Play"
#define TR_DELETE_FILE         "Borrar"
#define TR_COPY_FILE           "Copiar"
#define TR_RENAME_FILE         "Renombrar"
#define TR_REMOVED             "Borrado"
#define TR_SD_INFO             "Informacion"
#define TR_NA                  "N/A"
#define TR_TIME                "Hora"
#if defined(IMPERIAL_UNITS)
  #define TR_TXTEMP              "Temp. TX\037\164@F"
#else
  #define TR_TXTEMP              "Temp. TX\037\164@C"
#endif
#define TR_SD_INFO_TITLE       "SD INFO"
#define TR_SD_TYPE             "Tipo:"
#define TR_SD_SIZE             "Tama\201o:"
#define TR_TYPE                INDENT "Tipo"
#define TR_GLOBAL_VARS         "Global Variables"
#define TR_GLOBAL_V            "GLOBAL V."
#define TR_GLOBAL_VAR          "Global Variable"
#define TR_OWN                 "Propio"
#define TR_DATE                "Fecha"
#define TR_ROTARY_ENCODER      "R.Encs"
#define TR_EDIT                "Editar"
#define TR_INSERT_BEFORE       "Insertar antes"
#define TR_INSERT_AFTER        "Insertar despues"
#define TR_COPY                "Copiar"
#define TR_MOVE                "Mover"
#define TR_PASTE               "Pegar"
#define TR_DELETE              "Borrar"
#define TR_INSERT              "Insertar"
#define TR_RESET_FLIGHT        "Reset Vuelo"
#define TR_RESET_TIMER1        "Reset Reloj1"
#define TR_RESET_TIMER2        "Reset Reloj2"
#define TR_RESET_TELEMETRY     "Reset Telemetria"
#define TR_STATISTICS          "Estadisticas"
#define TR_SAVE_TIMERS         "Guarda Timers"
#define TR_SPEAKER             INDENT"Altavoz"
#define TR_BUZZER              INDENT"Zumbador"
#define TR_MODULE_BIND         "[Bnd]"
#define TR_MODULE_RANGE        "[Prt]"
#define TR_RESET_BTN           "[Reset]"
#define TR_SET                 "[Ajuste]"
#define TR_NUMCH               INDENT "Num canales"
#define TR_UBIND               INDENT "Desatar"
#define TR_RESET               "Reset"
#define TR_FAS_OFFSET          INDENT "FAS Ofs"
#if defined(X_ANY) || defined(BLUETOOTH)
  #define TR_X_ANY                        "X ANY"
  #define TR_ACTIVED                      "Active"
  #define TR_NUMBER                       "Number"
  #define TR_CHANNEL                      "Channel "
  #define TR_NB_REPEAT                    "Nb repeat "
  #define LEN_SWITCHES_VALUES             "\005"
  #define TR_SWITCHES_VALUES              "Sw.--""L1-L4""L1-L8""Sw.4 ""Sw.8 ""Sw.16"
  #define TR_ANGLE_SENSOR                 "0:360"
  #define TR_PROP                         "Prop."
  #define LEN_XANY_EXPO                   "\005"
  #define TR_XANY_EXPO                    "0%\0  ""25%\0 ""37.5%""50%\0 "
#endif
#if defined(BLUETOOTH)
  #define TR_BLUETOOTH                     "BLUETOOTH"
  #define TR_NOBLUETOOTH                   "\3NO BLUETOOTH"
  #define TR_CONNECTED                     "\036\5CONECTEd"
  #define TR_BT_ROLE                       "Role"
  #define TR_BT_PIN                        "Pin"
  #define TR_BT_M_S                        "\006""Slave\0""Master"
  #define TR_BT_PAIR                       "Pair"
  #define TR_AUTOCON                       "Auto-con."
  #define TR_RESCANN                       "Re-Scan"
#endif

#if defined(SCC)
  #define TR_SCC                            "CAMBIADOR DE CANAL"
  #define TR_SCC_CURCHANNELLBL              "Canal actual"
  #define TR_SCC_NEWCHANNELLBL              "Canal solicitado"
  #define TR_SCC_SBUSSWEEPTESTLBL           "Barrido de SBus"
#endif
